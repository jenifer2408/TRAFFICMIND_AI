# TrafficMind AI — System Architecture

TrafficMind AI establishes an industry-aligned data science workflow combining **programmatic prompt compilation**, **constrained mathematical optimization**, and **deterministic validation with bounded self-correction**.

---

## 1. Architectural Overview

```mermaid
flowchart TD
    A["Raw Traffic Stream / Dataset<br>(Arrivals, Queues, Timestamps)"] --> B["Automated Data Profiler<br>(Schema, Outliers, Imbalance, Regimes)"]
    B --> C["Dynamic Prompt Compiler<br>(Programmatic Context & Objective Directive)"]
    C --> D["LLM / Offline Analytical Planner<br>(Method Selection & Objective Tuning)"]
    D --> E["Deterministic Traffic Optimizer<br>(SciPy SLSQP / Webster Allocation)"]
    E --> F["Micro-Simulation Engine<br>(Discrete-Time Queue Dynamics)"]
    F --> G{"Independent Validation Engine<br>(Constraints, Anti-Starvation, Degradation)"}
    G -- "Fail (Retry < 3)" --> H["Diagnostic Feedback & Remedial Re-tuning"]
    H --> E
    G -- "Pass" --> I["Verified Signal Timing Plan<br>& Evidence-Based Technical Report"]
```

---

## 2. Separation of Responsibilities

A key architectural tenet is the **strict decoupling of stochastic AI reasoning from safety-critical control calculations**:

| Pipeline Component | Role | Determinism |
| :--- | :--- | :--- |
| **Data Profiler** | Detects data quality issues, hourly demand, corridor imbalances, and regime patterns | 100% Deterministic |
| **Prompt Compiler** | Converts empirical observations into structured JSON analytical prompts | 100% Programmatic |
| **LLM Reasoning** | High-level strategy selection, tradeoff identification, and hyperparameter guidance | Guided AI Reasoning (Online API or Offline Deterministic Mode) |
| **Traffic Optimizer** | Computes exact cycle lengths and green allocations using SciPy SLSQP or Webster | 100% Mathematical |
| **Traffic Simulator** | Evaluates vehicle arrivals, queues, discharges, and individual wait times | Ground-Truth Micro-simulation |
| **Validation Engine** | Enforces safety constraints ($g_{\min}, g_{\max}, C$), queue limits, and baseline gains | 100% Deterministic Verification |
| **Correction Loop** | Bounded retry loop (max 3) with diagnostic feedback | Autonomous Remediation |

---

## 3. Detailed Component Architecture

### A. Data Profiler (`data_profiler.py`)
- Ingests tabular time-series traffic datasets.
- Computes arrival rates, flow variances, and 2.5×IQR outlier masks.
- Classifies traffic into 4 regimes:
  - `balanced_normal`: Symmetric demand across corridors.
  - `rush_hour_congested`: Total demand exceeds 2400 vph.
  - `extreme_asymmetric`: Demand ratio between dominant and minor corridors $\ge 2.2:1$.
  - `sudden_incident`: Transient spike detected exceeding $2.2\times$ rolling average.

### B. Dynamic Prompt Compiler (`prompt_compiler.py`)
- Generates context-aware, structured markdown and JSON prompt specifications dynamically.
- Eliminates fixed boilerplate templates.
- Enforces explicit mathematical safety rules in the prompt prompt directive.

### C. Traffic Optimizer (`traffic_optimizer.py`)
- Provides closed-form Webster allocation and non-linear constrained mathematical minimization using `scipy.optimize.minimize(method='SLSQP')`.
- Implements exact constraint projection to guarantee cycle equation conservation:
  $$g_{\text{NS}} + g_{\text{EW}} + L = C$$

### D. Micro-Simulator (`traffic_simulator.py`)
- Simulates true vehicle arrivals, queue accumulation, and saturation discharge per second.
- Tracks per-vehicle waiting times from entrance to exit.

### E. Independent Validation & Correction (`validation_engine.py`, `correction_loop.py`)
- Validates minimum green ($g \ge 10\,\text{s}$), maximum green ($g \le 80\,\text{s}$), cycle bounds, anti-starvation, and non-degradation vs fixed baseline.
- If a check fails, returns classified failure category, diagnostic message, and suggested corrective multipliers.
- Bounded to 3 attempts.
