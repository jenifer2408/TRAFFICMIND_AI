# TrafficMind AI — Mathematical Algorithm & Formulation Guide

## 1. Problem Setting & Intersection Geometry
TrafficMind AI optimizes traffic signal timing allocations at a canonical 4-way intersection comprising four directional approaches:
- **NB:** Northbound
- **SB:** Southbound
- **EB:** Eastbound
- **WB:** Westbound

The standard signal phasing operates as a dual-ring concurrent 2-phase controller:
- **Phase 1 (NS):** Concurrently serves Northbound and Southbound movements.
- **Phase 2 (EW):** Concurrently serves Eastbound and Westbound movements.

---

## 2. Signal Timing Parameters & Physical Constraints

Each signal cycle $C$ satisfies the fundamental conservation equation:
$$\sum_{p \in \mathcal{P}} g_p + L = C$$

Where:
- $g_p$: Green duration allocated to phase $p \in \{\text{NS}, \text{EW}\}$.
- $L$: Total lost time across phase transitions:
  $$L = \sum_{p \in \mathcal{P}} (Y_p + AR_p) = 2 \times (3.0\,\text{s} + 1.0\,\text{s}) = 8.0\,\text{s}$$
  where $Y_p$ is yellow clearance (3s) and $AR_p$ is all-red clearance (1s).
- $C$: Total cycle length bounded by safety standards:
  $$C_{\min} \le C \le C_{\max} \quad (40\,\text{s} \le C \le 150\,\text{s})$$
- Green times are strictly constrained by anti-starvation and capacity bounds:
  $$g_{\min} \le g_p \le g_{\max} \quad (10.0\,\text{s} \le g_p \le 80.0\,\text{s})$$

---

## 3. Discrete-Time Queue Dynamics

Time is discretized into uniform intervals $\Delta t = 1.0\,\text{s}$.  
For each approach $i \in \{\text{NB}, \text{SB}, \text{EB}, \text{WB}\}$:

### A. Stochastic Vehicle Arrivals
Vehicle arrivals $A_i(t)$ follow a Poisson process parameterized by time-varying arrival rate $\lambda_i(t)$:
$$A_i(t) \sim \text{Poisson}(\lambda_i(t) \cdot \Delta t)$$
where $\lambda_i(t) = \frac{q_i(t)}{3600}$ (vehicles per second).

### B. Discharge Capacity
When approach $i$ displays a green signal, vehicle departures $D_i(t)$ are limited by saturation flow rate $s_i$ (typically $1800\,\text{veh/hr} = 0.5\,\text{veh/s}$):
$$D_i(t) = \begin{cases} \min\left(Q_i(t) + A_i(t), \lfloor s_i \cdot \Delta t \rfloor\right) & \text{if phase } \phi(i) \text{ is GREEN} \\ 0 & \text{otherwise (Yellow / Red)} \end{cases}$$

### C. Queue Conservation Equation
$$Q_i(t+1) = \max\left(0, Q_i(t) + A_i(t) - D_i(t)\right)$$

### D. Vehicle Delay & Waiting Time Accumulation
The total aggregate waiting time incurred at time step $t$ is:
$$W(t) = \sum_{i} Q_i(t) \cdot \Delta t$$
The mean vehicle waiting time over simulation duration $T$ is:
$$\bar{W} = \frac{\sum_{t=0}^{T} W(t)}{\text{Total Arrivals}}$$

---

## 4. Signal Optimization Formulations

### Method 1: Traditional Fixed-Time Baseline
Allocates static, predetermined green splits regardless of demand fluctuations:
$$g_{\text{NS}} = \frac{C_{\text{base}} - L}{2}, \quad g_{\text{EW}} = \frac{C_{\text{base}} - L}{2}$$
For $C_{\text{base}} = 60\,\text{s}$ and $L = 8\,\text{s}$, $g_{\text{NS}} = 26\,\text{s}, g_{\text{EW}} = 26\,\text{s}$.

---

### Method 2: Demand-Weighted Webster Flow Ratio
Derived from Frank Webster's classic traffic flow theory:
1. Compute approach flow ratios:
   $$y_i = \frac{q_i}{s_i}$$
2. Determine phase critical flow ratios:
   $$Y_{\text{NS}} = \max(y_{\text{NB}}, y_{\text{SB}}), \quad Y_{\text{EW}} = \max(y_{\text{EB}}, y_{\text{WB}})$$
   $$Y = Y_{\text{NS}} + Y_{\text{EW}}$$
3. Optimal cycle length estimation:
   $$C^* = \text{clip}\left(\frac{1.5 L + 5}{1 - \min(Y, 0.92)}, C_{\min}, C_{\max}\right)$$
4. Green time allocation:
   $$g_{\text{NS}} = (C^* - L) \cdot \frac{Y_{\text{NS}}}{Y}, \quad g_{\text{EW}} = (C^* - L) \cdot \frac{Y_{\text{EW}}}{Y}$$
   subject to $[g_{\min}, g_{\max}]$ clamping and cycle conservation preservation.

---

### Method 3: Non-Linear Constrained SciPy SLSQP Delay Minimization
Formulated as a non-linear constrained mathematical program:
$$\min_{g_{\text{NS}}, g_{\text{EW}}, C} J(g_{\text{NS}}, g_{\text{EW}}, C)$$

**Objective Function:**
$$J = w_d \cdot \left[ d_{\text{NS}}(g_{\text{NS}}, C) + d_{\text{EW}}(g_{\text{EW}}, C) \right] + w_q \cdot \left[ Q_{\text{NS}} \left(\frac{C - g_{\text{NS}}}{C}\right) + Q_{\text{EW}} \left(\frac{C - g_{\text{EW}}}{C}\right) \right] + w_{\text{sat}} \cdot \sum_{p} \max(0, X_p - 0.85)^2$$

Where:
- $d_p(g_p, C)$ is Webster's uniform delay equation:
  $$d_p = \frac{C (1 - \lambda_p)^2}{2 (1 - \min(0.98, \lambda_p X_p))}$$
  with green ratio $\lambda_p = g_p / C$, and degree of saturation $X_p = \frac{q_p}{s_p \lambda_p}$.
- $Q_p$: Queue penalty weighting.
- $w_d, w_q, w_{\text{sat}}$: Dynamic hyperparameter weights set programmatically by the Dynamic Prompt Compiler and adjusted by the Bounded Correction Loop.

**Constraints:**
$$g_{\min} \le g_{\text{NS}} \le g_{\max}$$
$$g_{\min} \le g_{\text{EW}} \le g_{\max}$$
$$C_{\min} \le C \le C_{\max}$$
$$g_{\text{NS}} + g_{\text{EW}} + L - C = 0 \quad (\text{Equality})$$

Solved via Sequential Least Squares Programming (`SLSQP`) with exact projection onto the active constraint boundary.
