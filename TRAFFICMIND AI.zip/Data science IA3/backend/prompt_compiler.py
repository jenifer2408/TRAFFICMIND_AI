"""
TrafficMind AI - Dynamic Prompt Compiler
Automatically compiles task-specific, context-aware analytical prompts from data profiles,
traffic regimes, safety constraints, and analytical objectives.
Replaces static prompts with programmatic, evidence-based reasoning directives.
"""

import uuid
from typing import Dict, Any, Optional
from .schemas import (
    DataProfileResult,
    SignalTimingConstraints,
    DynamicPromptSpecification
)


class DynamicPromptCompiler:
    """
    Programmatic compiler that converts dataset profiles and traffic states
    into structured LLM prompts and analytical problem specifications.
    """

    def __init__(self, constraints: Optional[SignalTimingConstraints] = None):
        self.constraints = constraints or SignalTimingConstraints()

    def compile_prompt(
        self,
        profile: DataProfileResult,
        custom_objective: Optional[str] = None
    ) -> DynamicPromptSpecification:
        prompt_id = f"prompt_{uuid.uuid4().hex[:8]}"

        pattern = profile.detected_traffic_pattern
        imbalance = profile.imbalance_ratio
        dominant = profile.dominant_approach
        total_vph = profile.total_demand_vph

        # Formulate analytical question & objective based on detected regime
        if pattern == "extreme_asymmetric":
            analytical_question = (
                f"How should green-time splits be reallocated between the dominant corridor "
                f"({dominant} approach demand ~{imbalance:.1f}x higher than cross-streets) "
                f"to reduce severe queue accumulation without violating minimum green or causing side-street starvation?"
            )
            analytical_objective = (
                "Minimize total intersection vehicle delay by prioritizing high-volume approach "
                "while strictly enforcing minimum green bounds to prevent starvation on opposing approaches."
            )
            candidate_methods = [
                "scipy_slsqp_delay_minimization",
                "webster_flow_ratio"
            ]
            primary_tradeoff = "Asymmetric demand vs Anti-starvation constraint"

        elif pattern == "rush_hour_congested":
            analytical_question = (
                f"Given high overall intersection saturation ({total_vph:.0f} vph), what is the optimal "
                f"cycle length and green split that maximizes vehicle discharge throughput while keeping "
                f"the degree of saturation below 0.90?"
            )
            analytical_objective = (
                "Maximize vehicle throughput and dissipate peak queues by dynamically scaling cycle length "
                "toward upper allowable bounds and synchronizing phase splits with saturation flow limits."
            )
            candidate_methods = [
                "scipy_slsqp_delay_minimization",
                "webster_flow_ratio"
            ]
            primary_tradeoff = "Cycle length expansion vs Cycle delay accumulation"

        elif pattern == "sudden_incident":
            analytical_question = (
                f"A sudden transient demand spike was detected on approach {dominant}. "
                f"How quickly can green time be temporarily surged to clear the bottleneck queue "
                f"before restoring balanced cyclic operations?"
            )
            analytical_objective = (
                "Rapidly clear incident queue surge through bounded green-phase extension, "
                "ensuring transitions do not violate clearance intervals or destabilize cross-traffic."
            )
            candidate_methods = [
                "scipy_slsqp_delay_minimization",
                "webster_flow_ratio"
            ]
            primary_tradeoff = "Surge response responsiveness vs Transition safety"

        else:  # balanced_normal
            analytical_question = (
                "Under balanced flow conditions, what is the delay-minimizing cycle length "
                "and equitable phase allocation across all 4 intersection approaches?"
            )
            analytical_objective = (
                "Minimize average vehicle waiting time with balanced green distribution "
                "and standard lost-time compensation."
            )
            candidate_methods = [
                "webster_flow_ratio",
                "scipy_slsqp_delay_minimization"
            ]
            primary_tradeoff = "Delay minimization vs Fuel economy / stop reduction"

        OBJECTIVE_DESCRIPTIONS = {
            "minimize_waiting_time": (
                "Reduce Average Waiting Time: Minimize volume-weighted average waiting time across all 4 intersection approaches "
                "while maintaining safe clearance intervals and queue bounds."
            ),
            "prioritize_dominant": (
                "Help Busy Roads Without Ignoring Others: Allocate additional green time and priority to the dominant traffic corridor "
                "to clear heavy queues, while strictly enforcing minimum green bounds to prevent side-street starvation."
            ),
            "help_busy_roads": (
                "Help Busy Roads Without Ignoring Others: Allocate additional green time and priority to the dominant traffic corridor "
                "to clear heavy queues, while strictly enforcing minimum green bounds to prevent side-street starvation."
            ),
            "maximize_throughput": (
                "Move More Vehicles, Reduce Queues: Maximize overall vehicle discharge throughput by optimizing green time ratio "
                "and aggressively dissipating vehicle queues before saturation limits are reached."
            ),
            "move_more_vehicles": (
                "Move More Vehicles, Reduce Queues: Maximize overall vehicle discharge throughput by optimizing green time ratio "
                "and aggressively dissipating vehicle queues before saturation limits are reached."
            ),
            "prevent_starvation": (
                "Prevent Long Waits on Less-Busy Roads: Balance delay across all directions and penalize maximum approach delay, "
                "ensuring less-busy cross-streets receive adequate green time without long queues."
            ),
            "prevent_long_waits": (
                "Prevent Long Waits on Less-Busy Roads: Balance delay across all directions and penalize maximum approach delay, "
                "ensuring less-busy cross-streets receive adequate green time without long queues."
            )
        }

        if custom_objective:
            analytical_objective = OBJECTIVE_DESCRIPTIONS.get(custom_objective, custom_objective)
            candidate_methods = ["scipy_slsqp_delay_minimization", "webster_flow_ratio"]

        # Build data quality notes
        dq_notes = []
        if profile.issues:
            for issue in profile.issues:
                dq_notes.append(f"- [{issue.severity.upper()}] {issue.issue_type} in '{issue.column}': {issue.description}")
        else:
            dq_notes.append("- No critical data quality issues identified. Dataset is structurally sound.")

        # Verification tests required
        verification_checks = [
            f"Phase green duration >= {self.constraints.min_green_seconds}s (Anti-starvation)",
            f"Phase green duration <= {self.constraints.max_green_seconds}s (Max green cap)",
            f"Cycle length sum equals: sum(greens) + yellow + all_red ({self.constraints.yellow_seconds}s + {self.constraints.all_red_seconds}s)",
            f"Cycle length in [{self.constraints.min_cycle_seconds}s, {self.constraints.max_cycle_seconds}s]",
            "Simulated average waiting time must not degrade versus baseline fixed-time controller (Improvement >= 0.0%)",
            "Degree of saturation per critical phase must be < 1.00"
        ]

        expected_schema = {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string"},
                "chosen_method": {"type": "string", "enum": candidate_methods},
                "recommended_cycle_seconds": {"type": "number"},
                "recommended_greens": {
                    "type": "object",
                    "properties": {
                        "NS": {"type": "number"},
                        "EW": {"type": "number"}
                    },
                    "required": ["NS", "EW"]
                },
                "objective_formulation": {"type": "string"},
                "justification": {"type": "string"}
            },
            "required": ["plan_id", "chosen_method", "recommended_cycle_seconds", "recommended_greens", "justification"]
        }

        # Format compiled prompt text
        compiled_text = (
            f"# DYNAMIC TRAFFIC ANALYTICAL DIRECTIVE [{prompt_id}]\n\n"
            f"## 1. EMPIRICAL TRAFFIC OBSERVATION\n"
            f"- Dataset: {profile.dataset_name} ({profile.total_records} records)\n"
            f"- Classified Regime: {pattern.upper()}\n"
            f"- Total Intersection Demand: {total_vph:.1f} vph\n"
            f"- Directional Imbalance Ratio: {imbalance:.2f}:1 (Dominant Approach: {dominant})\n"
            f"- Data Quality Score: {profile.quality_score_pct:.1f}%\n"
            f"Data Quality Notes:\n" + "\n".join(dq_notes) + "\n\n"
            f"## 2. ANALYTICAL PROBLEM STATEMENT\n"
            f"{analytical_question}\n\n"
            f"## 3. CORE OPTIMIZATION OBJECTIVE\n"
            f"{analytical_objective}\n"
            f"- Key Tradeoff Identified: {primary_tradeoff}\n\n"
            f"## 4. MATHEMATICAL CONSTRAINTS\n"
            f"- Minimum Green Time (g_min): {self.constraints.min_green_seconds} seconds\n"
            f"- Maximum Green Time (g_max): {self.constraints.max_green_seconds} seconds\n"
            f"- Allowable Cycle Bounds: [{self.constraints.min_cycle_seconds}s, {self.constraints.max_cycle_seconds}s]\n"
            f"- Phase Clearance: Yellow = {self.constraints.yellow_seconds}s, All-Red = {self.constraints.all_red_seconds}s per phase transition\n"
            f"- Total Lost Time (2-phase dual ring): {2 * (self.constraints.yellow_seconds + self.constraints.all_red_seconds):.1f} seconds\n\n"
            f"## 5. APPROVED CANDIDATE METHODS\n"
            f"- {candidate_methods[0]}: High-precision non-linear delay and queue penalty minimization.\n"
            f"- {candidate_methods[1] if len(candidate_methods) > 1 else 'rule_based'}: Standard analytical Webster allocation.\n\n"
            f"## 6. INDEPENDENT VERIFICATION TESTS\n"
            + "\n".join([f"- {chk}" for chk in verification_checks]) + "\n\n"
            f"## 7. MANDATORY OUTPUT SPECIFICATION\n"
            f"You must return a strictly valid JSON document adhering to the schema. "
            f"No arbitrary signal timings without mathematical justification."
        )

        return DynamicPromptSpecification(
            prompt_id=prompt_id,
            scenario_summary=profile.summary_text,
            traffic_profile={
                "total_demand_vph": total_vph,
                "detected_pattern": pattern,
                "dominant_approach": dominant,
                "records_count": profile.total_records
            },
            detected_imbalance={
                "imbalance_ratio": imbalance,
                "dominant_approach": dominant,
                "quality_score_pct": profile.quality_score_pct
            },
            analytical_objective=analytical_objective,
            candidate_methods=candidate_methods,
            signal_constraints=self.constraints,
            expected_output_schema=expected_schema,
            verification_checks=verification_checks,
            compiled_prompt_text=compiled_text
        )
