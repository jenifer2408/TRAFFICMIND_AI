"""
TrafficMind AI - Analysis Planner
Orchestrates data profiling, dynamic prompt compilation, and analytical method selection.
"""

from typing import Dict, Any, Optional, Tuple
import pandas as pd
from .schemas import (
    DataProfileResult,
    SignalTimingConstraints,
    DynamicPromptSpecification,
    AnalysisPlan
)
from .data_profiler import DataProfiler
from .prompt_compiler import DynamicPromptCompiler
from .llm_service import LLMService


class AnalysisPlanner:
    """End-to-end analytical planning orchestrator."""

    def __init__(self, constraints: Optional[SignalTimingConstraints] = None):
        self.constraints = constraints or SignalTimingConstraints()
        self.profiler = DataProfiler()
        self.compiler = DynamicPromptCompiler(self.constraints)
        self.llm_service = LLMService()

    def create_plan_from_dataframe(
        self,
        df: pd.DataFrame,
        dataset_name: str = "intersection_data",
        custom_objective: Optional[str] = None,
        constraints: Optional[SignalTimingConstraints] = None
    ) -> Tuple[DataProfileResult, DynamicPromptSpecification, AnalysisPlan, int, str]:
        """
        1. Profiles dataframe for data quality, demand, and traffic regime.
        2. Programmatically compiles a dynamic prompt.
        3. Generates structured analysis plan with method & hyperparameters.
        Returns: (profile, prompt_spec, plan, tokens, mode)
        """
        self.profiler.dataset_name = dataset_name
        profile = self.profiler.profile_dataframe(df)

        active_constraints = constraints or self.constraints
        compiler = DynamicPromptCompiler(active_constraints)
        prompt_spec = compiler.compile_prompt(profile, custom_objective=custom_objective)

        plan, tokens, mode = self.llm_service.plan_analysis(prompt_spec)

        return profile, prompt_spec, plan, tokens, mode
