"""
TrafficMind AI - Independent Validation Engine
Performs rigorous deterministic verification on signal timings and simulation outcomes.
Enforces safety constraints, anti-starvation rules, and strict baseline improvement criteria.
The LLM cannot override failed validation checks.
"""

from typing import Optional, List, Dict, Any
from .schemas import (
    SignalTimingPlan,
    SignalTimingConstraints,
    SimulationResult,
    ValidationResult,
    ValidationCheck
)


class ValidationEngine:
    """Independent deterministic verification engine."""

    def __init__(
        self,
        constraints: Optional[SignalTimingConstraints] = None,
        degradation_tolerance_pct: float = 0.0
    ):
        self.constraints = constraints or SignalTimingConstraints()
        self.degradation_tolerance_pct = degradation_tolerance_pct

    def validate_timings_and_simulation(
        self,
        timing_plan: SignalTimingPlan,
        sim_result: SimulationResult,
        baseline_fixed_sim: Optional[SimulationResult] = None,
        degradation_tolerance_pct: Optional[float] = None
    ) -> ValidationResult:
        tol_pct = degradation_tolerance_pct if degradation_tolerance_pct is not None else self.degradation_tolerance_pct
        checks: List[ValidationCheck] = []
        is_valid = True
        status = "PASS"
        failure_category = None
        diagnostic_message = "All safety constraints and performance checks passed successfully."
        suggested_correction: Optional[Dict[str, Any]] = None

        # 1. Minimum green check (Safety constraint: g >= g_min)
        min_g_observed = min(timing_plan.phases.values())
        min_g_passed = min_g_observed >= (self.constraints.min_green_seconds - 1e-3)
        checks.append(ValidationCheck(
            name="Minimum Green Duration",
            passed=min_g_passed,
            threshold=f">= {self.constraints.min_green_seconds:.1f}s",
            actual_value=f"{min_g_observed:.1f}s",
            severity="critical"
        ))
        if not min_g_passed:
            is_valid = False
            status = "FAIL_RETRYABLE"
            failure_category = "CONSTRAINT_VIOLATION_MIN_GREEN"
            diagnostic_message = (
                f"Violation: Phase green time {min_g_observed:.1f}s is below safety minimum "
                f"of {self.constraints.min_green_seconds:.1f}s."
            )
            suggested_correction = {
                "enforce_min_green": self.constraints.min_green_seconds,
                "reallocate_from": "longest_phase"
            }
            return ValidationResult(
                is_valid=is_valid,
                status=status,
                failure_category=failure_category,
                checks=checks,
                diagnostic_message=diagnostic_message,
                suggested_correction=suggested_correction
            )

        # 2. Maximum green check (Safety constraint: g <= g_max)
        max_g_observed = max(timing_plan.phases.values())
        max_g_passed = max_g_observed <= (self.constraints.max_green_seconds + 1e-3)
        checks.append(ValidationCheck(
            name="Maximum Green Duration",
            passed=max_g_passed,
            threshold=f"<= {self.constraints.max_green_seconds:.1f}s",
            actual_value=f"{max_g_observed:.1f}s",
            severity="critical"
        ))
        if not max_g_passed:
            is_valid = False
            status = "FAIL_RETRYABLE"
            failure_category = "CONSTRAINT_VIOLATION_MAX_GREEN"
            diagnostic_message = (
                f"Violation: Phase green time {max_g_observed:.1f}s exceeds safety cap "
                f"of {self.constraints.max_green_seconds:.1f}s."
            )
            suggested_correction = {
                "clamp_max_green": self.constraints.max_green_seconds
            }
            return ValidationResult(
                is_valid=is_valid,
                status=status,
                failure_category=failure_category,
                checks=checks,
                diagnostic_message=diagnostic_message,
                suggested_correction=suggested_correction
            )

        # 3. Cycle conservation check (sum(phases) + lost_time = cycle)
        total_phases = sum(timing_plan.phases.values())
        expected_cycle = total_phases + timing_plan.lost_time_total_seconds
        cycle_diff = abs(timing_plan.cycle_length_seconds - expected_cycle)
        cycle_sum_passed = cycle_diff < 0.2
        checks.append(ValidationCheck(
            name="Cycle Conservation Equation",
            passed=cycle_sum_passed,
            threshold="abs(sum(phases) + lost_time - cycle) < 0.2s",
            actual_value=f"diff={cycle_diff:.2f}s (cycle={timing_plan.cycle_length_seconds:.1f}s, sum={expected_cycle:.1f}s)",
            severity="critical"
        ))
        if not cycle_sum_passed:
            is_valid = False
            status = "FAIL_RETRYABLE"
            failure_category = "CONSTRAINT_VIOLATION_CYCLE_SUM"
            diagnostic_message = (
                f"Violation: Cycle conservation equation failed. Cycle length {timing_plan.cycle_length_seconds}s "
                f"does not match sum of phases {total_phases:.1f}s + lost time {timing_plan.lost_time_total_seconds:.1f}s."
            )
            suggested_correction = {
                "recalculate_cycle": expected_cycle
            }
            return ValidationResult(
                is_valid=is_valid,
                status=status,
                failure_category=failure_category,
                checks=checks,
                diagnostic_message=diagnostic_message,
                suggested_correction=suggested_correction
            )

        # 4. Anti-starvation approach equity check
        starved_approaches = []
        for app_name, app_metrics in sim_result.approach_metrics.items():
            # True starvation occurs when an approach is unfairly neglected (> 3.5x intersection average wait)
            if (
                sim_result.avg_waiting_time_sec > 0 and
                (app_metrics.avg_waiting_time_sec / sim_result.avg_waiting_time_sec) > 3.5
            ) or (
                sim_result.avg_waiting_time_sec < 50.0 and app_metrics.avg_waiting_time_sec > 160.0
            ):
                starved_approaches.append(app_name)

        starvation_passed = len(starved_approaches) == 0
        checks.append(ValidationCheck(
            name="Anti-Starvation Approach Equity",
            passed=starvation_passed,
            threshold="No approach wait > 120s or > 3.8x intersection mean",
            actual_value=f"Starved: {starved_approaches if starved_approaches else 'None'}",
            severity="critical"
        ))
        if not starvation_passed:
            is_valid = False
            status = "FAIL_RETRYABLE"
            failure_category = "QUEUE_STARVATION_DETECTED"
            starved_app = starved_approaches[0]
            starved_corridor = "EW" if starved_app in ["EB", "WB"] else "NS"
            diagnostic_message = (
                f"Violation: Queue starvation detected on approach(es) {starved_approaches}. "
                f"Corridor {starved_corridor} received inadequate green duration."
            )
            suggested_correction = {
                "boost_phase": starved_corridor,
                "queue_weight_mult": 1.6,
                "delay_weight_mult": 1.2
            }
            return ValidationResult(
                is_valid=is_valid,
                status=status,
                failure_category=failure_category,
                checks=checks,
                diagnostic_message=diagnostic_message,
                suggested_correction=suggested_correction
            )

        # 5. Baseline performance comparison (Strict acceptance: no degradation > tolerance)
        if baseline_fixed_sim is not None:
            improvement_pct = (
                (baseline_fixed_sim.avg_waiting_time_sec - sim_result.avg_waiting_time_sec)
                / max(0.1, baseline_fixed_sim.avg_waiting_time_sec)
            ) * 100.0

            # Must satisfy: improvement_pct >= -tol_pct (e.g. >= 0.0%)
            performance_passed = improvement_pct >= (-tol_pct - 1e-4)

            checks.append(ValidationCheck(
                name="Baseline Performance Check",
                passed=performance_passed,
                threshold=f"Improvement >= {-tol_pct:.1f}% (No performance degradation)",
                actual_value=f"{sim_result.avg_waiting_time_sec:.2f}s vs {baseline_fixed_sim.avg_waiting_time_sec:.2f}s ({improvement_pct:+.2f}%)",
                severity="critical"
            ))

            if not performance_passed:
                is_valid = False
                status = "FAIL_RETRYABLE"
                failure_category = "DEGRADED_PERFORMANCE_VS_BASELINE"
                diagnostic_message = (
                    f"Violation: Adaptive strategy degraded performance versus fixed baseline. "
                    f"Waiting time increased from {baseline_fixed_sim.avg_waiting_time_sec:.2f}s to {sim_result.avg_waiting_time_sec:.2f}s "
                    f"({improvement_pct:+.2f}% change, which violates strict 0.0% degradation limit)."
                )
                suggested_correction = {
                    "switch_to_webster": True,
                    "queue_weight_mult": 1.6,
                    "delay_weight_mult": 1.3
                }
                return ValidationResult(
                    is_valid=is_valid,
                    status=status,
                    failure_category=failure_category,
                    checks=checks,
                    diagnostic_message=diagnostic_message,
                    suggested_correction=suggested_correction
                )

        return ValidationResult(
            is_valid=is_valid,
            status=status,
            failure_category=None,
            checks=checks,
            diagnostic_message=diagnostic_message,
            suggested_correction=None
        )
