"""
TrafficMind AI - Pydantic Data Schemas
Defines structured request/response models for all modules in the pipeline.
Upgraded to support the Data Science Experimentation Lab.
"""

from typing import Dict, List, Optional, Any, Literal
from pydantic import BaseModel, Field, model_validator


class ApproachConfig(BaseModel):
    name: str = Field(..., description="Approach name (e.g., NB, SB, EB, WB)")
    arrival_rate_vph: float = Field(..., ge=0, description="Arrival rate in vehicles per hour")
    arrival_rate_vpm: Optional[float] = Field(None, ge=0, description="Arrival rate in vehicles per minute (convenience field)")
    saturation_flow_vph: float = Field(1800.0, ge=600, le=3600, description="Saturation flow rate in vehicles per green hour")
    initial_queue: int = Field(0, ge=0, description="Initial queued vehicles at simulation start")

    @model_validator(mode="before")
    @classmethod
    def sync_vpm_and_vph(cls, data: Any):
        if isinstance(data, dict):
            if "arrival_rate_vpm" in data and data["arrival_rate_vpm"] is not None and "arrival_rate_vph" not in data:
                data["arrival_rate_vph"] = float(data["arrival_rate_vpm"]) * 60.0
            elif "arrival_rate_vph" in data and ("arrival_rate_vpm" not in data or data["arrival_rate_vpm"] is None):
                data["arrival_rate_vpm"] = round(float(data["arrival_rate_vph"]) / 60.0, 2)
        return data


class SignalTimingConstraints(BaseModel):
    min_green_seconds: float = Field(10.0, ge=5.0, description="Minimum green duration per phase")
    max_green_seconds: float = Field(80.0, le=120.0, description="Maximum green duration per phase")
    min_cycle_seconds: float = Field(40.0, ge=30.0, description="Minimum allowable cycle duration")
    max_cycle_seconds: float = Field(150.0, le=240.0, description="Maximum allowable cycle duration")
    yellow_seconds: float = Field(3.0, ge=2.0, le=6.0, description="Yellow interval per phase transition")
    all_red_seconds: float = Field(1.0, ge=0.0, le=4.0, description="All-red clearance interval per transition")


class OptimizationObjectiveConfig(BaseModel):
    primary_objective: str = "minimize_waiting_time"
    weight_waiting_time: float = Field(1.0, ge=0.0, le=10.0)
    weight_queue_length: float = Field(1.4, ge=0.0, le=10.0)
    weight_throughput: float = Field(0.5, ge=0.0, le=10.0)
    degradation_tolerance_pct: float = Field(0.0, ge=0.0, le=5.0, description="Allowable waiting time degradation vs baseline (strict 0.0%)")


class TrafficScenarioConfig(BaseModel):
    scenario_id: str = "scenario_custom"
    scenario_type: Literal["normal", "rush_hour", "asymmetric", "incident", "custom"] = "custom"
    duration_seconds: int = Field(300, ge=30, le=3600, description="Simulation duration in seconds")
    time_step_seconds: float = Field(1.0, ge=0.5, le=5.0, description="Simulation time step")
    seed: Optional[int] = Field(42, description="Random seed for reproducibility")
    # Default arrival rates specified in requirements: NB=75 vpm (4500 vph), SB=45 vpm (2700 vph), EB=30 vpm (1800 vph), WB=35 vpm (2100 vph)
    approaches: Dict[str, ApproachConfig] = Field(
        default_factory=lambda: {
            "NB": ApproachConfig(name="NB", arrival_rate_vph=4500.0, arrival_rate_vpm=75.0, saturation_flow_vph=1800.0, initial_queue=15),
            "SB": ApproachConfig(name="SB", arrival_rate_vph=2700.0, arrival_rate_vpm=45.0, saturation_flow_vph=1800.0, initial_queue=12),
            "EB": ApproachConfig(name="EB", arrival_rate_vph=1800.0, arrival_rate_vpm=30.0, saturation_flow_vph=1800.0, initial_queue=4),
            "WB": ApproachConfig(name="WB", arrival_rate_vph=2100.0, arrival_rate_vpm=35.0, saturation_flow_vph=1800.0, initial_queue=4),
        }
    )
    incident_approach: Optional[str] = None
    incident_surge_factor: float = Field(2.5, ge=1.0, le=5.0, description="Surge multiplier during incident")
    incident_start_sec: int = Field(60, ge=0)
    incident_duration_sec: int = Field(120, ge=10)
    constraints: SignalTimingConstraints = Field(default_factory=SignalTimingConstraints)
    objective_config: OptimizationObjectiveConfig = Field(default_factory=OptimizationObjectiveConfig)


class DataQualityIssue(BaseModel):
    column: str
    issue_type: Literal["missing_values", "outlier", "zero_variance", "invalid_range", "inconsistent_schema"]
    severity: Literal["low", "medium", "high"]
    description: str


class DataProfileResult(BaseModel):
    dataset_name: str
    total_records: int
    column_names: List[str]
    missing_value_counts: Dict[str, int]
    imbalance_ratio: float = Field(..., description="Ratio of maximum to minimum approach demand")
    dominant_approach: str
    total_demand_vph: float
    detected_traffic_pattern: Literal["balanced_normal", "rush_hour_congested", "extreme_asymmetric", "sudden_incident"]
    quality_score_pct: float = Field(..., ge=0.0, le=100.0)
    issues: List[DataQualityIssue] = []
    summary_text: str
    data_sample: List[Dict[str, Any]] = []
    column_types: Dict[str, str] = {}
    source_type: str = "synthetic_simulation"


class DynamicPromptSpecification(BaseModel):
    prompt_id: str
    scenario_summary: str
    traffic_profile: Dict[str, Any]
    detected_imbalance: Dict[str, Any]
    analytical_objective: str
    candidate_methods: List[str]
    signal_constraints: SignalTimingConstraints
    expected_output_schema: Dict[str, Any]
    verification_checks: List[str]
    compiled_prompt_text: str


class AnalysisPlan(BaseModel):
    plan_id: str
    chosen_method: Literal["webster_flow_ratio", "scipy_slsqp_delay_minimization", "queue_proportional_greedy", "fixed_baseline"]
    objective_formulation: str
    hyperparameters: Dict[str, Any]
    rationale: str
    llm_reasoning: Optional[str] = None


class SignalTimingPlan(BaseModel):
    cycle_length_seconds: float
    phases: Dict[str, float] = Field(..., description="Mapping of phase name (e.g. 'NS', 'EW') to green time seconds")
    yellow_seconds: float = 3.0
    all_red_seconds: float = 1.0
    lost_time_total_seconds: float
    degree_of_saturation: Dict[str, float] = Field(default_factory=dict)
    optimization_method: str = "custom"
    computation_time_ms: float = 0.0


class ApproachSimulationMetric(BaseModel):
    approach: str
    total_arrivals: int
    total_departures: int
    avg_queue: float
    max_queue: int
    avg_waiting_time_sec: float
    max_waiting_time_sec: float
    total_delay_sec: float


class SimulationTimeSeriesPoint(BaseModel):
    second: int
    active_phase: str
    queue_nb: int
    queue_sb: int
    queue_eb: int
    queue_wb: int
    waiting_vehicles_total: int


class SimulationResult(BaseModel):
    controller_type: str
    duration_seconds: int
    seed: Optional[int] = None
    total_vehicles_arrived: int
    total_vehicles_served: int
    throughput_vph: float
    avg_waiting_time_sec: float
    median_waiting_time_sec: float
    max_waiting_time_sec: float
    avg_queue_length: float
    max_queue_length: int
    total_delay_sec: float
    approach_metrics: Dict[str, ApproachSimulationMetric]
    time_series_sample: List[SimulationTimeSeriesPoint] = []


class ValidationCheck(BaseModel):
    name: str
    passed: bool
    threshold: str
    actual_value: str
    severity: Literal["critical", "warning", "info"]


class ValidationResult(BaseModel):
    is_valid: bool
    status: Literal["PASS", "FAIL_RETRYABLE", "FAIL_FATAL"]
    failure_category: Optional[Literal[
        "CONSTRAINT_VIOLATION_MIN_GREEN",
        "CONSTRAINT_VIOLATION_MAX_GREEN",
        "CONSTRAINT_VIOLATION_CYCLE_SUM",
        "DEGRADED_PERFORMANCE_VS_BASELINE",
        "QUEUE_STARVATION_DETECTED",
        "NUMERICAL_INSTABILITY",
        "INVALID_SCHEMA",
        "FAULT_INJECTED_FAILURE"
    ]] = None
    checks: List[ValidationCheck] = []
    diagnostic_message: str
    suggested_correction: Optional[Dict[str, Any]] = None


class CorrectionAttempt(BaseModel):
    attempt_index: int
    input_timings: SignalTimingPlan
    validation: ValidationResult
    remedial_actions_applied: List[str]
    revised_timings: Optional[SignalTimingPlan] = None


class PipelineExecutionTrace(BaseModel):
    run_id: str
    scenario_id: str
    scenario_type: str
    seed: int
    data_profile: DataProfileResult
    dynamic_prompt: DynamicPromptSpecification
    analysis_plan: AnalysisPlan
    initial_timings: SignalTimingPlan
    attempts: List[CorrectionAttempt] = []
    final_timings: SignalTimingPlan
    final_simulation_proposed: SimulationResult
    baseline_fixed_simulation: SimulationResult
    baseline_adaptive_simulation: SimulationResult
    waiting_time_improvement_pct: float
    queue_length_improvement_pct: float
    delay_improvement_pct: float
    throughput_gain_pct: float
    total_retries: int
    final_status: Literal["OPTIMAL_VERIFIED", "SUBOPTIMAL_VERIFIED", "FAILED_MAX_RETRIES", "DEGRADED_REJECTED"]
    execution_time_ms: float
    llm_tokens_used: int = 0
    llm_mode: str = "mock_deterministic"
    active_objective: Optional[str] = "minimize_waiting_time"
    active_objective_label: Optional[str] = "Reduce Average Waiting Time"
    active_dataset_or_scenario: Optional[str] = "Custom Scenario"


# EDA and Advanced Experimentation Schemas

class ApproachDescriptiveStats(BaseModel):
    approach: str
    arrival_count_total: int
    arrival_mean_per_sec: float
    arrival_std: float
    arrival_median: float
    arrival_max: int
    queue_mean: float
    queue_std: float
    queue_median: float
    queue_max: int
    queue_p95: float
    estimated_hourly_flow: float


class EDAResult(BaseModel):
    dataset_name: str
    total_records: int
    duration_seconds: float
    approach_stats: Dict[str, ApproachDescriptiveStats]
    correlation_matrix: Dict[str, Dict[str, float]]
    arrival_distributions: Dict[str, List[int]]
    outliers_detected: Dict[str, int]
    missing_values_detected: Dict[str, int]
    hourly_flow_distribution: Dict[str, float]
    data_sample: List[Dict[str, Any]] = []
    column_types: Dict[str, str] = {}
    source_type: str = "synthetic_simulation"
    time_interval_sec: float = 1.0
    quality_checks: Dict[str, Any] = {}


class AlgorithmComparisonItem(BaseModel):
    algorithm_name: str
    cycle_length_sec: float
    phases: Dict[str, float]
    avg_waiting_time_sec: float
    median_waiting_time_sec: float
    max_waiting_time_sec: float
    avg_queue_length: float
    max_queue_length: int
    throughput_vph: float
    total_delay_sec: float
    waiting_reduction_pct_vs_fixed: float
    queue_reduction_pct_vs_fixed: float
    throughput_gain_pct_vs_fixed: float
    is_safe: bool
    violations_count: int


class AlgorithmBenchmarkResponse(BaseModel):
    scenario_id: str
    seed: int
    duration_seconds: int
    algorithms_compared: List[AlgorithmComparisonItem]
    best_algorithm_by_waiting_time: str
    best_algorithm_by_queue: str
    best_algorithm_by_throughput: str


class WhatIfScenarioConfig(BaseModel):
    scenario_id: str = "what_if_incident"
    base_scenario: TrafficScenarioConfig
    disruption_type: Literal["accident_surge", "capacity_drop", "road_closure", "sensor_glitch"] = "accident_surge"
    affected_approach: str = "NB"
    disruption_start_sec: int = 60
    disruption_duration_sec: int = 120
    severity_multiplier: float = 3.0


class WhatIfResult(BaseModel):
    disruption_type: str
    affected_approach: str
    fixed_before_wait: float
    fixed_after_wait: float
    adaptive_before_wait: float
    adaptive_after_wait: float
    adaptive_mitigation_benefit_pct: float
    is_regression: bool = False
    outcome_label: str = "IMPROVEMENT"
    time_series_fixed: List[SimulationTimeSeriesPoint]
    time_series_adaptive: List[SimulationTimeSeriesPoint]
    observations: str


class FaultInjectionRequest(BaseModel):
    fault_type: Literal[
        "min_green_violation",
        "max_green_violation",
        "cycle_sum_mismatch",
        "degraded_timings_injection",
        "malformed_schema"
    ] = "min_green_violation"
    scenario: Optional[TrafficScenarioConfig] = None


class FaultInjectionResult(BaseModel):
    fault_type: str
    injected_plan: Dict[str, Any]
    detected_by_validator: bool
    caught_check_name: Optional[str]
    failure_category: Optional[str]
    diagnostic_message: str
    remedial_action_attempted: bool
    remedy_outcome: str
    safe_fallback_enforced: bool


class EvaluationBenchmarkScenarioSummary(BaseModel):
    scenario_name: str
    runs_count: int
    fixed_time_avg_waiting_sec: float
    adaptive_unassisted_avg_waiting_sec: float
    trafficmind_proposed_avg_waiting_sec: float
    waiting_reduction_pct: float
    fixed_time_avg_queue: float
    trafficmind_avg_queue: float
    queue_reduction_pct: float
    constraint_violation_rate_pct: float
    prompt_success_rate_pct: float
    correction_success_rate_pct: float
    avg_retries: float


class ApproachPlaybackState(BaseModel):
    approach: str
    signal_color: Literal["RED", "YELLOW", "GREEN"]
    queue_length: int
    arrived_this_step: int
    discharged_this_step: int
    cumulative_arrivals: int
    cumulative_departures: int
    is_incident: bool = False


class PlaybackTick(BaseModel):
    second: int
    active_phase: str
    phase_remaining_seconds: float
    approaches: Dict[str, ApproachPlaybackState]
    total_waiting: int
    cumulative_served: int
    current_avg_wait_sec: float


class ControllerPlaybackStream(BaseModel):
    controller_name: str
    timings: SignalTimingPlan
    summary: SimulationResult
    ticks: List[PlaybackTick]
    optimization_explanation: str
    constraint_violations: int = 0


class DualPlaybackResponse(BaseModel):
    duration_seconds: int
    seed: int
    scenario_type: str
    fixed_controller: ControllerPlaybackStream
    adaptive_controller: ControllerPlaybackStream
    crn_verified: bool = True
    waiting_time_delta_pct: float = 0.0
    is_regression: bool = False
    outcome_label: str = "IMPROVEMENT"


class PlaybackSimulationRequest(BaseModel):
    scenario: TrafficScenarioConfig
    adaptive_method: Literal["scipy_slsqp", "webster", "greedy", "prediction_informed"] = "scipy_slsqp"


class PreprocessingReport(BaseModel):
    raw_records_count: int
    cleaned_records_count: int
    missing_values_imputed: Dict[str, int]
    outliers_handled: Dict[str, int]
    duplicates_dropped_count: int = 0
    transformations_applied: List[str]
    cleaning_steps: List[str] = Field(default_factory=list)
    feature_engineering_steps: List[str] = Field(default_factory=list)
    quality_score_formula: str = "Quality Score = 100 - [35*(N_missing/N_cells) + 30*(N_invalid/N_records) + 20*(N_duplicates/N_records) + 15*(N_outliers/N_records)]"
    initial_quality_score: float
    post_cleaning_quality_score: float
    raw_sample: List[Dict[str, Any]] = []
    cleaned_sample: List[Dict[str, Any]] = []
    engineered_features: List[str] = []
    summary_text: str



class UploadAndPreprocessResponse(BaseModel):
    filename: str
    preprocessing_report: PreprocessingReport
    data_profile: DataProfileResult


class MetricCalculationDetail(BaseModel):
    metric_key: str
    metric_name: str
    formula: str
    input_values: Dict[str, Any]
    calculation_steps: List[str]
    final_value_display: str
    plain_english_explanation: str


class PromptExecutionRequest(BaseModel):
    objective: str = "minimize_waiting_time"
    scenario: Optional[TrafficScenarioConfig] = None
    use_active_dataset: bool = True


class PromptExecutionResponse(BaseModel):
    objective_selected: str
    compiled_prompt: DynamicPromptSpecification
    selected_method: str
    method_rationale: str
    pipeline_trace: PipelineExecutionTrace
    executive_narrative: str


class LinearRegressionResult(BaseModel):
    mae: float
    rmse: float
    r2: float
    coefficients: Dict[str, float]
    intercept: float
    prediction_interval_95_width: float = 0.0
    coverage_95_pct: float = 95.0
    sample_predictions: List[Dict[str, float]] = []


class DecisionTreeResult(BaseModel):
    accuracy: float
    precision_macro: float
    recall_macro: float
    f1_macro: float
    classes: List[str]
    confusion_matrix: List[List[int]]
    feature_importances: Dict[str, float]
    tree_depth: int


class KMeansResult(BaseModel):
    n_clusters: int
    silhouette_score: float
    inertia: float
    cluster_centers: List[Dict[str, float]]
    cluster_counts: Dict[str, int]
    cluster_sample_points: List[Dict[str, Any]] = []


class MLEvaluationResponse(BaseModel):
    evaluation_id: str = ""
    dataset_id: str = ""
    dataset_name: str
    timestamp: str = ""
    sample_count: int
    train_sample_count: int = 0
    test_sample_count: int = 0
    target_variable: str = "waiting_time_sec"
    features_used: List[str]
    linear_regression: LinearRegressionResult
    decision_tree: DecisionTreeResult
    kmeans: KMeansResult
    executive_summary: str
    model_mode: str = "trained_scikit_learn"


class GraphDataResponse(BaseModel):
    graphs: Dict[str, Dict[str, Any]]
    image_base64: Dict[str, str] = {}
    summary_insights: List[str] = []
    simulation_run_id: Optional[str] = None
    ml_evaluation_id: Optional[str] = None
    dataset_id: Optional[str] = None
    dataset_name: Optional[str] = None
    generated_at: str = ""


class GraphRequestPayload(BaseModel):
    simulation_run_id: Optional[str] = None
    scenario: Optional[TrafficScenarioConfig] = None
    ml_evaluation_id: Optional[str] = None
    dataset_id: Optional[str] = None


class AutoAnalysisResponse(BaseModel):
    dataset_name: str
    dataset_quality_score: float
    raw_quality_score: float = 100.0
    drift_detected: bool
    drift_summary: str
    drift_metrics: Dict[str, Any] = {}
    objective_selected: str
    compiled_prompt: DynamicPromptSpecification
    analysis_plan: AnalysisPlan
    selected_method: str
    method_rationale: str
    llm_mode: str
    pipeline_trace: PipelineExecutionTrace
    ml_evaluation: MLEvaluationResponse
    executive_narrative: str
    warnings_and_limitations: List[str] = []

