"""
TrafficMind AI - Autonomous Self-Correcting Analytical Pipeline
Implements bounded retries with deterministic feedback, constraint enforcement,
and common random numbers (identical arrival schedules) across all controllers.
"""

import time
import uuid
from typing import Dict, Any, Optional, List
from .schemas import (
    TrafficScenarioConfig,
    DataProfileResult,
    DynamicPromptSpecification,
    AnalysisPlan,
    SignalTimingPlan,
    SimulationResult,
    ValidationResult,
    CorrectionAttempt,
    PipelineExecutionTrace
)
from .traffic_optimizer import TrafficOptimizer
from .traffic_simulator import TrafficSimulator
from .validation_engine import ValidationEngine


class SelfCorrectingPipeline:
    """Orchestrates simulation, validation, and bounded self-correcting optimization."""

    def __init__(
        self,
        max_retries: int = 3,
        optimizer: Optional[TrafficOptimizer] = None,
        validator: Optional[ValidationEngine] = None
    ):
        self.max_retries = max_retries
        self.optimizer = optimizer or TrafficOptimizer()
        self.validator = validator or ValidationEngine()

    def execute_pipeline(
        self,
        scenario: TrafficScenarioConfig,
        data_profile: DataProfileResult,
        dynamic_prompt: DynamicPromptSpecification,
        analysis_plan: AnalysisPlan,
        tokens_used: int = 0,
        llm_mode: str = "mock_deterministic"
    ) -> PipelineExecutionTrace:
        start_time = time.perf_counter()
        run_id = f"run_{uuid.uuid4().hex[:10]}"

        # Sync constraints across optimizer and validator
        self.optimizer.constraints = scenario.constraints
        self.validator.constraints = scenario.constraints

        # Initialize simulator and PRE-GENERATE identical arrival sequence (Common Random Numbers)
        simulator = TrafficSimulator(scenario)
        arrival_schedule = simulator.generate_arrival_schedule()

        # 1. Run Baseline A: Fixed-time signal controller on the exact arrival sequence
        fixed_timings = self.optimizer.optimize_fixed_baseline(
            cycle_length=60.0,
            constraints=scenario.constraints
        )
        baseline_fixed_sim = simulator.run_simulation(
            fixed_timings,
            controller_name="Fixed-Time Baseline (A)",
            arrival_schedule=arrival_schedule
        )

        # 2. Run Baseline B: Unassisted Adaptive Webster on the exact arrival sequence
        approach_demands = {
            app_id: app_cfg.arrival_rate_vph for app_id, app_cfg in scenario.approaches.items()
        }
        unassisted_timings = self.optimizer.optimize_webster(
            approach_demands,
            constraints=scenario.constraints
        )
        baseline_adaptive_sim = simulator.run_simulation(
            unassisted_timings,
            controller_name="Adaptive Unassisted Baseline (B)",
            arrival_schedule=arrival_schedule
        )

        # 3. Proposed Approach: Guided by Dynamic Prompt Analysis Plan & Objective Config
        initial_queues = {app_id: app_cfg.initial_queue for app_id, app_cfg in scenario.approaches.items()}

        attempts: List[CorrectionAttempt] = []
        remedial_adjustments: Dict[str, Any] = {}
        current_method = analysis_plan.chosen_method

        # When a custom objective or custom scenario is requested, ensure numerical solver runs with objective formulation
        primary_obj = scenario.objective_config.primary_objective
        if primary_obj in ["prioritize_dominant", "help_busy_roads", "maximize_throughput", "move_more_vehicles", "prevent_starvation", "prevent_long_waits"] or scenario.scenario_type == "custom":
            if current_method == "webster_flow_ratio":
                current_method = "scipy_slsqp_delay_minimization"

        combined_hyperparams = {
            "objective_config": scenario.objective_config.model_dump(),
            "primary_objective": primary_obj,
            **analysis_plan.hyperparameters
        }

        final_timings: Optional[SignalTimingPlan] = None
        final_sim_result: Optional[SimulationResult] = None
        final_status = "FAILED_MAX_RETRIES"
        initial_timings_recorded = fixed_timings

        for attempt_idx in range(self.max_retries + 1):
            # Compute timings
            if current_method == "scipy_slsqp_delay_minimization":
                proposed_timings = self.optimizer.optimize_scipy_slsqp(
                    approach_demands_vph=approach_demands,
                    queues=initial_queues,
                    hyperparameters=combined_hyperparams,
                    remedial_adjustments=remedial_adjustments,
                    constraints=scenario.constraints
                )
            elif current_method == "queue_proportional_greedy":
                proposed_timings = self.optimizer.optimize_queue_proportional_greedy(
                    approach_demands_vph=approach_demands,
                    queues=initial_queues,
                    constraints=scenario.constraints
                )
            else:
                proposed_timings = self.optimizer.optimize_webster(
                    approach_demands_vph=approach_demands,
                    constraints=scenario.constraints
                )

            # Record initial proposed timings on attempt 0
            if attempt_idx == 0:
                initial_timings_recorded = proposed_timings

            # Simulate proposed timings ON THE EXACT SAME ARRIVAL SEQUENCE
            proposed_sim = simulator.run_simulation(
                proposed_timings,
                controller_name=f"TrafficMind Proposed ({current_method})",
                arrival_schedule=arrival_schedule
            )

            # Validate independently against safety bounds and baseline performance
            validation = self.validator.validate_timings_and_simulation(
                timing_plan=proposed_timings,
                sim_result=proposed_sim,
                baseline_fixed_sim=baseline_fixed_sim,
                degradation_tolerance_pct=scenario.objective_config.degradation_tolerance_pct
            )

            remedial_actions: List[str] = []

            if validation.is_valid:
                final_timings = proposed_timings
                final_sim_result = proposed_sim
                final_status = "OPTIMAL_VERIFIED" if attempt_idx == 0 else "SUBOPTIMAL_VERIFIED"
                attempts.append(CorrectionAttempt(
                    attempt_index=attempt_idx,
                    input_timings=proposed_timings,
                    validation=validation,
                    remedial_actions_applied=["Validation passed: strategy verified and accepted."],
                    revised_timings=proposed_timings
                ))
                break
            else:
                # Failure detected - initiate diagnostic self-correction
                fail_cat = validation.failure_category or "UNKNOWN_FAILURE"
                diag_msg = validation.diagnostic_message
                remedy = validation.suggested_correction or {}

                action_desc = f"Attempt {attempt_idx + 1} Failed [{fail_cat}]: {diag_msg}"
                remedial_actions.append(action_desc)

                # Apply remedial adjustments for next attempt
                if remedy.get("switch_to_webster"):
                    current_method = "webster_flow_ratio"
                    remedial_actions.append("Corrective action: Switched optimization method to robust analytical Webster.")

                if remedy.get("boost_phase"):
                    remedial_adjustments["boost_phase"] = remedy["boost_phase"]
                    remedial_actions.append(f"Corrective action: Applied 2.5x queue penalty weighting to starved phase '{remedy['boost_phase']}'.")

                if remedy.get("queue_weight_mult"):
                    remedial_adjustments["queue_weight_mult"] = (
                        remedial_adjustments.get("queue_weight_mult", 1.0) * remedy["queue_weight_mult"]
                    )
                    remedial_actions.append(f"Corrective action: Scaled queue penalty multiplier to {remedial_adjustments['queue_weight_mult']:.2f}x.")

                if remedy.get("delay_weight_mult"):
                    remedial_adjustments["delay_weight_mult"] = (
                        remedial_adjustments.get("delay_weight_mult", 1.0) * remedy["delay_weight_mult"]
                    )
                    remedial_actions.append(f"Corrective action: Scaled delay weight multiplier to {remedial_adjustments['delay_weight_mult']:.2f}x.")

                attempts.append(CorrectionAttempt(
                    attempt_index=attempt_idx,
                    input_timings=proposed_timings,
                    validation=validation,
                    remedial_actions_applied=remedial_actions,
                    revised_timings=None
                ))

        if final_status == "FAILED_MAX_RETRIES":
            # If all attempts exhausted without meeting acceptance criteria, enforce safe fallback
            final_status = "FAILED_MAX_RETRIES"
            final_timings = fixed_timings
            final_sim_result = baseline_fixed_sim

        # Strict invariant: Only a plan whose latest validation attempt passed can be verified
        if final_status in ["OPTIMAL_VERIFIED", "SUBOPTIMAL_VERIFIED"]:
            if not attempts or not attempts[-1].validation.is_valid:
                final_status = "FAILED_MAX_RETRIES"
                final_timings = fixed_timings
                final_sim_result = baseline_fixed_sim

        # Calculate genuine comparative metrics
        base_w = max(0.1, baseline_fixed_sim.avg_waiting_time_sec)
        prop_w = final_sim_result.avg_waiting_time_sec
        w_imp_pct = round(((base_w - prop_w) / base_w) * 100.0, 2)

        base_q = max(0.1, baseline_fixed_sim.avg_queue_length)
        prop_q = final_sim_result.avg_queue_length
        q_imp_pct = round(((base_q - prop_q) / base_q) * 100.0, 2)

        base_d = max(0.1, baseline_fixed_sim.total_delay_sec)
        prop_d = final_sim_result.total_delay_sec
        d_imp_pct = round(((base_d - prop_d) / base_d) * 100.0, 2)

        base_th = max(0.1, baseline_fixed_sim.throughput_vph)
        prop_th = final_sim_result.throughput_vph
        th_gain_pct = round(((prop_th - base_th) / base_th) * 100.0, 2)

        exec_ms = round((time.perf_counter() - start_time) * 1000.0, 2)

        return PipelineExecutionTrace(
            run_id=run_id,
            scenario_id=scenario.scenario_id,
            scenario_type=scenario.scenario_type,
            seed=scenario.seed or 42,
            data_profile=data_profile,
            dynamic_prompt=dynamic_prompt,
            analysis_plan=analysis_plan,
            initial_timings=initial_timings_recorded,
            attempts=attempts,
            final_timings=final_timings,
            final_simulation_proposed=final_sim_result,
            baseline_fixed_simulation=baseline_fixed_sim,
            baseline_adaptive_simulation=baseline_adaptive_sim,
            waiting_time_improvement_pct=w_imp_pct,
            queue_length_improvement_pct=q_imp_pct,
            delay_improvement_pct=d_imp_pct,
            throughput_gain_pct=th_gain_pct,
            total_retries=len(attempts) - 1 if final_status in ["OPTIMAL_VERIFIED", "SUBOPTIMAL_VERIFIED"] else len(attempts),
            final_status=final_status,
            execution_time_ms=exec_ms,
            llm_tokens_used=tokens_used,
            llm_mode=llm_mode,
            active_objective=primary_obj,
            active_objective_label={
                "minimize_waiting_time": "Reduce Average Waiting Time",
                "prioritize_dominant": "Help Busy Roads Without Ignoring Others",
                "help_busy_roads": "Help Busy Roads Without Ignoring Others",
                "maximize_throughput": "Move More Vehicles, Reduce Queues",
                "move_more_vehicles": "Move More Vehicles, Reduce Queues",
                "prevent_starvation": "Prevent Long Waits on Less-Busy Roads",
                "prevent_long_waits": "Prevent Long Waits on Less-Busy Roads",
            }.get(primary_obj, "Reduce Average Waiting Time"),
            active_dataset_or_scenario=(
                f"Custom ({scenario.duration_seconds}s, Seed {scenario.seed})"
                if scenario.scenario_type == "custom"
                else f"Preset: {scenario.scenario_type.title()}"
            )
        )
