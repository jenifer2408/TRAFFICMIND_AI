"""
TrafficMind AI - Discrete-Time Traffic Queue Simulator
Accurately models arrivals, queues, signal transitions, saturation flow discharges,
and individual vehicle waiting times for 4-way intersections.
Supports common random numbers (deterministic arrival schedules) for 100% fair comparisons.
"""

import numpy as np
from typing import Dict, List, Optional
from collections import deque
from .schemas import (
    TrafficScenarioConfig,
    SignalTimingPlan,
    SimulationResult,
    ApproachSimulationMetric,
    SimulationTimeSeriesPoint,
    ApproachPlaybackState,
    PlaybackTick,
    ControllerPlaybackStream
)


class TrafficSimulator:
    """Discrete-time micro-simulation engine for traffic signal control evaluation."""

    def __init__(self, scenario_config: TrafficScenarioConfig):
        self.scenario = scenario_config

    def generate_arrival_schedule(self) -> Dict[str, List[int]]:
        """
        Pre-generates deterministic vehicle arrival sequences for all approaches
        using Common Random Numbers (CRN) based on self.scenario.seed.
        Guarantees both Fixed-Time and Adaptive controllers face 100% identical traffic.
        """
        rng = np.random.default_rng(self.scenario.seed)
        dt = self.scenario.time_step_seconds
        total_steps = int(self.scenario.duration_seconds / dt)

        base_rates = {k: v.arrival_rate_vph / 3600.0 for k, v in self.scenario.approaches.items()}
        schedule: Dict[str, List[int]] = {app: [] for app in self.scenario.approaches.keys()}

        for step in range(total_steps):
            current_t = step * dt

            is_incident = (
                self.scenario.incident_approach is not None
                and self.scenario.incident_start_sec <= current_t < (self.scenario.incident_start_sec + self.scenario.incident_duration_sec)
            )

            for app_id in self.scenario.approaches.keys():
                rate = base_rates[app_id]

                if self.scenario.scenario_type == "rush_hour":
                    surge = 1.0 + 0.35 * np.sin(np.pi * current_t / self.scenario.duration_seconds)
                    rate *= surge
                elif self.scenario.scenario_type == "asymmetric":
                    if app_id in ["NB", "SB"]:
                        rate *= 1.2
                    else:
                        rate *= 0.6
                elif self.scenario.scenario_type == "incident" and is_incident:
                    if app_id == self.scenario.incident_approach:
                        rate *= self.scenario.incident_surge_factor

                num_arrivals = int(rng.poisson(rate * dt))
                schedule[app_id].append(num_arrivals)

        return schedule

    def run_simulation(
        self,
        timing_plan: SignalTimingPlan,
        controller_name: str = "Adaptive Controller",
        arrival_schedule: Optional[Dict[str, List[int]]] = None,
        capacity_multipliers: Optional[Dict[str, float]] = None
    ) -> SimulationResult:
        """
        Executes discrete-time simulation.
        If arrival_schedule is provided, replays identical vehicle arrival sequence.
        """
        if arrival_schedule is None:
            arrival_schedule = self.generate_arrival_schedule()

        dt = self.scenario.time_step_seconds
        total_steps = int(self.scenario.duration_seconds / dt)

        g_ns = timing_plan.phases.get("NS", 26.0)
        g_ew = timing_plan.phases.get("EW", 26.0)
        y = timing_plan.yellow_seconds
        ar = timing_plan.all_red_seconds

        # Cycle transition markers
        t_ns_green_end = g_ns
        t_ns_yellow_end = t_ns_green_end + y
        t_ns_clear_end = t_ns_yellow_end + ar
        t_ew_green_end = t_ns_clear_end + g_ew
        t_ew_yellow_end = t_ew_green_end + y
        cycle_length = t_ew_yellow_end + ar

        # Queues of arrival timestamps
        vehicle_queues: Dict[str, deque] = {
            app: deque() for app in self.scenario.approaches.keys()
        }

        # Seed initial queued vehicles
        for app_id, app_cfg in self.scenario.approaches.items():
            for _ in range(app_cfg.initial_queue):
                vehicle_queues[app_id].append(0.0)

        # Fractional accumulators for capacity discharge
        discharge_fraction: Dict[str, float] = {app: 0.0 for app in self.scenario.approaches.keys()}

        completed_waiting_times: Dict[str, List[float]] = {app: [] for app in self.scenario.approaches.keys()}
        total_arrivals: Dict[str, int] = {app: app_cfg.initial_queue for app, app_cfg in self.scenario.approaches.items()}
        total_departures: Dict[str, int] = {app: 0 for app in self.scenario.approaches.keys()}
        queue_history: Dict[str, List[int]] = {app: [] for app in self.scenario.approaches.keys()}
        total_delay_approach: Dict[str, float] = {app: 0.0 for app in self.scenario.approaches.keys()}

        time_series_samples: List[SimulationTimeSeriesPoint] = []

        cap_mult = capacity_multipliers or {}

        for step in range(total_steps):
            current_t = step * dt
            cycle_pos = current_t % cycle_length

            # Phase detection
            if cycle_pos < t_ns_green_end:
                active_phase = "NS_GREEN"
                green_apps = ["NB", "SB"]
            elif cycle_pos < t_ns_yellow_end:
                active_phase = "NS_YELLOW"
                green_apps = []
            elif cycle_pos < t_ns_clear_end:
                active_phase = "NS_ALL_RED"
                green_apps = []
            elif cycle_pos < t_ew_green_end:
                active_phase = "EW_GREEN"
                green_apps = ["EB", "WB"]
            elif cycle_pos < t_ew_yellow_end:
                active_phase = "EW_YELLOW"
                green_apps = []
            else:
                active_phase = "EW_ALL_RED"
                green_apps = []

            # Replay arrivals from pre-generated schedule
            for app_id, app_cfg in self.scenario.approaches.items():
                num_arrivals = arrival_schedule[app_id][step]
                total_arrivals[app_id] += num_arrivals
                for _ in range(num_arrivals):
                    vehicle_queues[app_id].append(current_t)

                # Process discharges if green
                if app_id in green_apps:
                    eff_sat = app_cfg.saturation_flow_vph * cap_mult.get(app_id, 1.0)
                    sat_rate = (eff_sat / 3600.0) * dt
                    discharge_fraction[app_id] += sat_rate

                    discharges_possible = int(discharge_fraction[app_id])
                    discharge_fraction[app_id] -= discharges_possible

                    num_discharged = min(len(vehicle_queues[app_id]), discharges_possible)
                    for _ in range(num_discharged):
                        arr_time = vehicle_queues[app_id].popleft()
                        wait_sec = max(0.0, current_t - arr_time)
                        completed_waiting_times[app_id].append(wait_sec)
                        total_departures[app_id] += 1
                else:
                    discharge_fraction[app_id] = 0.0

                current_q = len(vehicle_queues[app_id])
                queue_history[app_id].append(current_q)
                total_delay_approach[app_id] += current_q * dt

            # Sample every 5 seconds or step
            if step % int(max(1, 5.0 / dt)) == 0:
                time_series_samples.append(SimulationTimeSeriesPoint(
                    second=int(current_t),
                    active_phase=active_phase,
                    queue_nb=len(vehicle_queues.get("NB", [])),
                    queue_sb=len(vehicle_queues.get("SB", [])),
                    queue_eb=len(vehicle_queues.get("EB", [])),
                    queue_wb=len(vehicle_queues.get("WB", [])),
                    waiting_vehicles_total=sum(len(q) for q in vehicle_queues.values())
                ))

        # Collect wait times
        all_waits: List[float] = []
        for waits in completed_waiting_times.values():
            all_waits.extend(waits)

        for app_id, q in vehicle_queues.items():
            for arr_time in q:
                all_waits.append(self.scenario.duration_seconds - arr_time)

        total_vehicles_arrived = sum(total_arrivals.values())
        total_vehicles_served = sum(total_departures.values())

        duration_hours = self.scenario.duration_seconds / 3600.0
        throughput_vph = round(total_vehicles_served / max(0.01, duration_hours), 1)

        avg_wait = float(np.mean(all_waits)) if all_waits else 0.0
        median_wait = float(np.median(all_waits)) if all_waits else 0.0
        max_wait = float(np.max(all_waits)) if all_waits else 0.0

        all_queues = [q for history in queue_history.values() for q in history]
        avg_queue = float(np.mean(all_queues)) if all_queues else 0.0
        max_queue = int(np.max(all_queues)) if all_queues else 0

        total_delay = sum(total_delay_approach.values())

        approach_metrics: Dict[str, ApproachSimulationMetric] = {}
        for app_id in self.scenario.approaches.keys():
            app_all_waits = list(completed_waiting_times[app_id])
            for arr_time in vehicle_queues[app_id]:
                app_all_waits.append(self.scenario.duration_seconds - arr_time)

            approach_metrics[app_id] = ApproachSimulationMetric(
                approach=app_id,
                total_arrivals=total_arrivals[app_id],
                total_departures=total_departures[app_id],
                avg_queue=round(float(np.mean(queue_history[app_id])), 2),
                max_queue=int(np.max(queue_history[app_id])),
                avg_waiting_time_sec=round(float(np.mean(app_all_waits)), 2) if app_all_waits else 0.0,
                max_waiting_time_sec=round(float(np.max(app_all_waits)), 2) if app_all_waits else 0.0,
                total_delay_sec=round(total_delay_approach[app_id], 1)
            )


        return SimulationResult(
            controller_type=controller_name,
            duration_seconds=self.scenario.duration_seconds,
            seed=self.scenario.seed,
            total_vehicles_arrived=total_vehicles_arrived,
            total_vehicles_served=total_vehicles_served,
            throughput_vph=throughput_vph,
            avg_waiting_time_sec=round(avg_wait, 2),
            median_waiting_time_sec=round(median_wait, 2),
            max_waiting_time_sec=round(max_wait, 2),
            avg_queue_length=round(avg_queue, 2),
            max_queue_length=max_queue,
            total_delay_sec=round(total_delay, 1),
            approach_metrics=approach_metrics,
            time_series_sample=time_series_samples
        )

    def run_playback_simulation(
        self,
        timing_plan: SignalTimingPlan,
        controller_name: str = "Controller",
        arrival_schedule: Optional[Dict[str, List[int]]] = None,
        capacity_multipliers: Optional[Dict[str, float]] = None,
        optimization_explanation: str = ""
    ) -> ControllerPlaybackStream:
        """
        Executes discrete-time simulation and records full second-by-second
        state playback ticks for 2D animated intersection visualization.
        """
        if arrival_schedule is None:
            arrival_schedule = self.generate_arrival_schedule()

        dt = self.scenario.time_step_seconds
        total_steps = int(self.scenario.duration_seconds / dt)

        g_ns = timing_plan.phases.get("NS", 26.0)
        g_ew = timing_plan.phases.get("EW", 26.0)
        y = timing_plan.yellow_seconds
        ar = timing_plan.all_red_seconds

        t_ns_green_end = g_ns
        t_ns_yellow_end = t_ns_green_end + y
        t_ns_clear_end = t_ns_yellow_end + ar
        t_ew_green_end = t_ns_clear_end + g_ew
        t_ew_yellow_end = t_ew_green_end + y
        cycle_length = t_ew_yellow_end + ar

        vehicle_queues: Dict[str, deque] = {
            app: deque() for app in self.scenario.approaches.keys()
        }

        for app_id, app_cfg in self.scenario.approaches.items():
            for _ in range(app_cfg.initial_queue):
                vehicle_queues[app_id].append(0.0)

        discharge_fraction: Dict[str, float] = {app: 0.0 for app in self.scenario.approaches.keys()}
        completed_waiting_times: Dict[str, List[float]] = {app: [] for app in self.scenario.approaches.keys()}
        total_arrivals: Dict[str, int] = {app: app_cfg.initial_queue for app, app_cfg in self.scenario.approaches.items()}
        total_departures: Dict[str, int] = {app: 0 for app in self.scenario.approaches.keys()}
        queue_history: Dict[str, List[int]] = {app: [] for app in self.scenario.approaches.keys()}
        total_delay_approach: Dict[str, float] = {app: 0.0 for app in self.scenario.approaches.keys()}
        time_series_samples: List[SimulationTimeSeriesPoint] = []

        playback_ticks: List[PlaybackTick] = []
        cap_mult = capacity_multipliers or {}

        for step in range(total_steps):
            current_t = step * dt
            cycle_pos = current_t % cycle_length

            if cycle_pos < t_ns_green_end:
                active_phase = "NS_GREEN"
                green_apps = ["NB", "SB"]
                phase_remaining = t_ns_green_end - cycle_pos
            elif cycle_pos < t_ns_yellow_end:
                active_phase = "NS_YELLOW"
                green_apps = []
                phase_remaining = t_ns_yellow_end - cycle_pos
            elif cycle_pos < t_ns_clear_end:
                active_phase = "NS_ALL_RED"
                green_apps = []
                phase_remaining = t_ns_clear_end - cycle_pos
            elif cycle_pos < t_ew_green_end:
                active_phase = "EW_GREEN"
                green_apps = ["EB", "WB"]
                phase_remaining = t_ew_green_end - cycle_pos
            elif cycle_pos < t_ew_yellow_end:
                active_phase = "EW_YELLOW"
                green_apps = []
                phase_remaining = t_ew_yellow_end - cycle_pos
            else:
                active_phase = "EW_ALL_RED"
                green_apps = []
                phase_remaining = cycle_length - cycle_pos

            step_approaches: Dict[str, ApproachPlaybackState] = {}

            for app_id, app_cfg in self.scenario.approaches.items():
                num_arrivals = arrival_schedule[app_id][step]
                total_arrivals[app_id] += num_arrivals
                for _ in range(num_arrivals):
                    vehicle_queues[app_id].append(current_t)

                discharged_now = 0
                if app_id in green_apps:
                    eff_sat = app_cfg.saturation_flow_vph * cap_mult.get(app_id, 1.0)
                    sat_rate = (eff_sat / 3600.0) * dt
                    discharge_fraction[app_id] += sat_rate

                    discharges_possible = int(discharge_fraction[app_id])
                    discharge_fraction[app_id] -= discharges_possible

                    discharged_now = min(len(vehicle_queues[app_id]), discharges_possible)
                    for _ in range(discharged_now):
                        arr_time = vehicle_queues[app_id].popleft()
                        wait_sec = max(0.0, current_t - arr_time)
                        completed_waiting_times[app_id].append(wait_sec)
                        total_departures[app_id] += 1
                else:
                    discharge_fraction[app_id] = 0.0

                current_q = len(vehicle_queues[app_id])
                queue_history[app_id].append(current_q)
                total_delay_approach[app_id] += current_q * dt

                if app_id in ["NB", "SB"]:
                    if active_phase == "NS_GREEN":
                        sig_col = "GREEN"
                    elif active_phase == "NS_YELLOW":
                        sig_col = "YELLOW"
                    else:
                        sig_col = "RED"
                else:
                    if active_phase == "EW_GREEN":
                        sig_col = "GREEN"
                    elif active_phase == "EW_YELLOW":
                        sig_col = "YELLOW"
                    else:
                        sig_col = "RED"

                is_incident = (
                    self.scenario.incident_approach == app_id
                    and self.scenario.incident_start_sec <= current_t < (self.scenario.incident_start_sec + self.scenario.incident_duration_sec)
                )

                step_approaches[app_id] = ApproachPlaybackState(
                    approach=app_id,
                    signal_color=sig_col,
                    queue_length=current_q,
                    arrived_this_step=num_arrivals,
                    discharged_this_step=discharged_now,
                    cumulative_arrivals=total_arrivals[app_id],
                    cumulative_departures=total_departures[app_id],
                    is_incident=is_incident
                )

            all_comp = [w for w_list in completed_waiting_times.values() for w in w_list]
            running_avg_wait = float(np.mean(all_comp)) if all_comp else 0.0

            playback_ticks.append(PlaybackTick(
                second=int(current_t),
                active_phase=active_phase,
                phase_remaining_seconds=round(phase_remaining, 1),
                approaches=step_approaches,
                total_waiting=sum(len(q) for q in vehicle_queues.values()),
                cumulative_served=sum(total_departures.values()),
                current_avg_wait_sec=round(running_avg_wait, 1)
            ))

            if step % int(max(1, 5.0 / dt)) == 0:
                time_series_samples.append(SimulationTimeSeriesPoint(
                    second=int(current_t),
                    active_phase=active_phase,
                    queue_nb=len(vehicle_queues.get("NB", [])),
                    queue_sb=len(vehicle_queues.get("SB", [])),
                    queue_eb=len(vehicle_queues.get("EB", [])),
                    queue_wb=len(vehicle_queues.get("WB", [])),
                    waiting_vehicles_total=sum(len(q) for q in vehicle_queues.values())
                ))

        all_waits: List[float] = [w for waits in completed_waiting_times.values() for w in waits]
        for app_id, q in vehicle_queues.items():
            for arr_time in q:
                all_waits.append(self.scenario.duration_seconds - arr_time)

        total_vehicles_arrived = sum(total_arrivals.values())
        total_vehicles_served = sum(total_departures.values())
        duration_hours = self.scenario.duration_seconds / 3600.0
        throughput_vph = round(total_vehicles_served / max(0.01, duration_hours), 1)

        avg_wait = float(np.mean(all_waits)) if all_waits else 0.0
        median_wait = float(np.median(all_waits)) if all_waits else 0.0
        max_wait = float(np.max(all_waits)) if all_waits else 0.0

        all_queues = [q for history in queue_history.values() for q in history]
        avg_queue = float(np.mean(all_queues)) if all_queues else 0.0
        max_queue = int(np.max(all_queues)) if all_queues else 0

        total_delay = sum(total_delay_approach.values())

        approach_metrics: Dict[str, ApproachSimulationMetric] = {}
        for app_id in self.scenario.approaches.keys():
            app_waits = completed_waiting_times[app_id]
            approach_metrics[app_id] = ApproachSimulationMetric(
                approach=app_id,
                total_arrivals=total_arrivals[app_id],
                total_departures=total_departures[app_id],
                avg_queue=round(float(np.mean(queue_history[app_id])), 2),
                max_queue=int(np.max(queue_history[app_id])),
                avg_waiting_time_sec=round(float(np.mean(app_waits)), 2) if app_waits else 0.0,
                max_waiting_time_sec=round(float(np.max(app_waits)), 2) if app_waits else 0.0,
                total_delay_sec=round(total_delay_approach[app_id], 1)
            )

        sim_res = SimulationResult(
            controller_type=controller_name,
            duration_seconds=self.scenario.duration_seconds,
            seed=self.scenario.seed,
            total_vehicles_arrived=total_vehicles_arrived,
            total_vehicles_served=total_vehicles_served,
            throughput_vph=throughput_vph,
            avg_waiting_time_sec=round(avg_wait, 2),
            median_waiting_time_sec=round(median_wait, 2),
            max_waiting_time_sec=round(max_wait, 2),
            avg_queue_length=round(avg_queue, 2),
            max_queue_length=max_queue,
            total_delay_sec=round(total_delay, 1),
            approach_metrics=approach_metrics,
            time_series_sample=time_series_samples
        )

        return ControllerPlaybackStream(
            controller_name=controller_name,
            timings=timing_plan,
            summary=sim_res,
            ticks=playback_ticks,
            optimization_explanation=optimization_explanation,
            constraint_violations=0
        )

