"""
TrafficMind AI - FastAPI Backend Application
Exposes modular REST API endpoints for traffic data generation, profiling, dynamic prompt compilation,
signal timing optimization, micro-simulation, independent verification, and benchmark evaluation.
Upgraded with full Data Science Experimentation Lab capabilities (EDA, What-If, Fault Injection, Multi-Algorithm).
"""

import io
import os
import json
import uuid
import pandas as pd
from typing import Dict, Any, Optional, List
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel



from .schemas import (
    TrafficScenarioConfig,
    ApproachConfig,
    DataProfileResult,
    DynamicPromptSpecification,
    AnalysisPlan,
    SignalTimingPlan,
    SimulationResult,
    PipelineExecutionTrace,
    SignalTimingConstraints,
    EDAResult,
    AlgorithmBenchmarkResponse,
    AlgorithmComparisonItem,
    WhatIfScenarioConfig,
    WhatIfResult,
    FaultInjectionRequest,
    FaultInjectionResult,
    DualPlaybackResponse,
    PlaybackSimulationRequest,
    PreprocessingReport,
    UploadAndPreprocessResponse,
    MetricCalculationDetail,
    PromptExecutionRequest,
    PromptExecutionResponse,
    MLEvaluationResponse,
    GraphDataResponse,
    AutoAnalysisResponse
)
from .data_generator import (
    generate_synthetic_traffic_dataset,
    generate_benchmark_scenarios
)
from .data_profiler import DataProfiler
from .data_preprocessor import DataPreprocessor
from .metric_inspector import MetricInspector
from .prompt_compiler import DynamicPromptCompiler
from .analysis_planner import AnalysisPlanner
from .traffic_optimizer import TrafficOptimizer
from .traffic_simulator import TrafficSimulator
from .validation_engine import ValidationEngine
from .correction_loop import SelfCorrectingPipeline
from .evaluation import TrafficBenchmarkEvaluator
from .report_generator import ReportGenerator
from .ml_models import TrafficMLEngine
from .graph_service import TrafficGraphService

app = FastAPI(
    title="TrafficMind AI API",
    description="Intelligent Adaptive Traffic Management System with Dynamic Prompt Generation and Self-Correcting Analytics",
    version="2.0.0"
)

# Enable CORS for local development / frontend dashboard
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for execution traces and authoritative active dataset session
EXECUTION_TRACES: Dict[str, PipelineExecutionTrace] = {}

AVAILABLE_DATASETS: Dict[str, Dict[str, Any]] = {
    "clean_baseline": {
        "id": "clean_baseline",
        "name": "Clean Baseline Traffic (Benchmark)",
        "filename": "clean_baseline.csv",
        "description": "Standard Poisson arrivals, 0 missing cells, 0 invalid values, 0 duplicates. Ideal benchmark control.",
        "quality_score": 100.0,
        "anomaly_type": "None (Benchmark Standard)"
    },
    "missing_values": {
        "id": "missing_values",
        "name": "Missing Sensor Readings (MCAR)",
        "filename": "missing_values.csv",
        "description": "6% MCAR missing records in arrival counts and queue lengths requiring automated median/mode imputation.",
        "quality_score": 92.5,
        "anomaly_type": "Missing Values (MCAR)"
    },
    "sensor_anomalies": {
        "id": "sensor_anomalies",
        "name": "Hardware Polarity & Optical Spikes",
        "filename": "sensor_anomalies.csv",
        "description": "Negative arrival counts (-2 to -8) from polarity faults and optical detector bounce spikes (>50 veh/s).",
        "quality_score": 82.4,
        "anomaly_type": "Negative Readings & Extreme Spikes"
    },
    "duplicate_records": {
        "id": "duplicate_records",
        "name": "Repeated Transmission Bursts",
        "filename": "duplicate_records.csv",
        "description": "Repeated network telemetry bursts resulting in 42 duplicate timestamp/approach rows requiring deduplication.",
        "quality_score": 88.0,
        "anomaly_type": "Duplicated Telemetry Packets"
    },
    "mixed_quality": {
        "id": "mixed_quality",
        "name": "Mixed Empirical Dirty Traffic",
        "filename": "mixed_quality_traffic.csv",
        "description": "Real-world field traffic combining missing values (4%), negative sensor readings (3%), spikes (2%), and duplicates (30 rows).",
        "quality_score": 73.1,
        "anomaly_type": "Multi-Faceted Real-World Noise"
    }
}

ACTIVE_DATASET_ID: str = "clean_baseline"
ACTIVE_DATASET_NAME: str = "Clean Baseline Traffic (Benchmark)"
ACTIVE_DATASET_RUN_ID: str = "run_init"
ACTIVE_RAW_DF: Optional[pd.DataFrame] = None
ACTIVE_DATASET: Optional[pd.DataFrame] = None
ACTIVE_PREPROCESSING_REPORT: Optional[PreprocessingReport] = None
ACTIVE_ML_EVALUATION: Optional[MLEvaluationResponse] = None
ACTIVE_SIMULATION_TRACE: Optional[PipelineExecutionTrace] = None


def ensure_default_dataset_loaded():
    """Ensures authoritative active dataset is initialized with Clean Baseline on startup."""
    global ACTIVE_DATASET_ID, ACTIVE_DATASET_NAME, ACTIVE_RAW_DF, ACTIVE_DATASET, ACTIVE_PREPROCESSING_REPORT, ACTIVE_DATASET_RUN_ID, ACTIVE_ML_EVALUATION, ACTIVE_SIMULATION_TRACE
    if ACTIVE_DATASET is None:
        raw_file = os.path.join("data", "raw", "clean_baseline.csv")
        if not os.path.exists(raw_file):
            from .data_generator import generate_five_benchmark_datasets
            generate_five_benchmark_datasets("data/raw")
        if os.path.exists(raw_file):
            raw_df = pd.read_csv(raw_file)
        else:
            from .data_generator import generate_synthetic_traffic_dataset, generate_benchmark_scenarios
            raw_df = generate_synthetic_traffic_dataset(generate_benchmark_scenarios()["asymmetric"])
        clean_df, prep_report = DataPreprocessor.clean_and_preprocess(raw_df, dataset_name="Clean Baseline Traffic (Benchmark)")
        ACTIVE_DATASET_ID = "clean_baseline"
        ACTIVE_DATASET_NAME = "Clean Baseline Traffic (Benchmark)"
        ACTIVE_DATASET_RUN_ID = f"run_{uuid.uuid4().hex[:8]}"
        ACTIVE_RAW_DF = raw_df
        ACTIVE_DATASET = clean_df
        ACTIVE_PREPROCESSING_REPORT = prep_report
        ACTIVE_ML_EVALUATION = None
        ACTIVE_SIMULATION_TRACE = None
    elif ACTIVE_DATASET_RUN_ID == "run_init":
        ACTIVE_DATASET_RUN_ID = f"run_{uuid.uuid4().hex[:8]}"


# Reusable instances
optimizer = TrafficOptimizer()
validator = ValidationEngine()
planner = AnalysisPlanner()
pipeline = SelfCorrectingPipeline(max_retries=3, optimizer=optimizer, validator=validator)
benchmark_evaluator = TrafficBenchmarkEvaluator()


@app.get("/health")
def health_check():
    """Application health endpoint."""
    return {
        "status": "healthy",
        "service": "TrafficMind AI Experimentation Lab Backend",
        "version": "2.0.0",
        "llm_mode": planner.llm_service.mode
    }


@app.get("/llm/status")
def get_llm_status():
    """Returns live Ollama connection status, detected models, and current mode."""
    return planner.llm_service.check_status()


@app.post("/llm/generate_insights")
def generate_llm_insights(payload: Dict[str, Any]):
    """Generates natural language data science narrative via Ollama or deterministic fallback."""
    global ACTIVE_ML_EVALUATION
    context_data = payload.get("context_data", {})
    goal_type = payload.get("goal_type", "general")

    if goal_type == "ml":
        if not context_data.get("linear_regression") and ACTIVE_ML_EVALUATION is not None:
            context_data = ACTIVE_ML_EVALUATION.model_dump()
        elif not context_data.get("linear_regression") and ACTIVE_ML_EVALUATION is None:
            ensure_default_dataset_loaded()
            df = ACTIVE_DATASET.copy() if ACTIVE_DATASET is not None else None
            if df is not None:
                ACTIVE_ML_EVALUATION = TrafficMLEngine.train_and_evaluate(df, dataset_name=ACTIVE_DATASET_NAME, dataset_id=ACTIVE_DATASET_ID)
                context_data = ACTIVE_ML_EVALUATION.model_dump()

    narrative = planner.llm_service.generate_narrative_explanation(context_data, goal_type)
    status = planner.llm_service.check_status()
    eval_id = context_data.get("evaluation_id") or (ACTIVE_ML_EVALUATION.evaluation_id if ACTIVE_ML_EVALUATION else None)
    return {
        "narrative": narrative,
        "mode": status["mode"],
        "provider": status["provider"],
        "status_label": status["status_label"],
        "active_model": status["active_model"],
        "evaluation_id": eval_id
    }


@app.get("/scenarios/presets")
def get_scenario_presets():
    """Returns available benchmark scenario configurations."""
    presets = generate_benchmark_scenarios()
    return {k: v.model_dump() for k, v in presets.items()}


@app.get("/data/datasets")
def list_available_datasets():
    """Returns catalog of the 5 realistic raw synthetic traffic datasets with metadata."""
    ensure_default_dataset_loaded()
    result = []
    for d_id, info in AVAILABLE_DATASETS.items():
        item = dict(info)
        item["is_active"] = (d_id == ACTIVE_DATASET_ID)
        filepath = os.path.join("data", "raw", info["filename"])
        if os.path.exists(filepath):
            try:
                df = pd.read_csv(filepath)
                item["record_count"] = len(df)
            except Exception:
                item["record_count"] = 1200
        else:
            item["record_count"] = 1200
        result.append(item)
    return result


class SelectDatasetPayload(BaseModel):
    dataset_id: str


@app.post("/data/select_dataset")
def select_authoritative_dataset(payload: SelectDatasetPayload):
    """
    Selects one of the 5 distinct raw synthetic traffic datasets as the authoritative active session.
    Never overwrites raw data; executes cleaning, imputation, deduplication, and feature engineering,
    and returns comprehensive before-and-after audit report and profile.
    """
    global ACTIVE_DATASET_ID, ACTIVE_DATASET_NAME, ACTIVE_RAW_DF, ACTIVE_DATASET, ACTIVE_PREPROCESSING_REPORT, ACTIVE_DATASET_RUN_ID, ACTIVE_ML_EVALUATION, ACTIVE_SIMULATION_TRACE
    d_id = payload.dataset_id
    if d_id not in AVAILABLE_DATASETS:
        raise HTTPException(status_code=404, detail=f"Dataset '{d_id}' not found in catalog.")

    meta = AVAILABLE_DATASETS[d_id]
    filepath = os.path.join("data", "raw", meta["filename"])
    if not os.path.exists(filepath):
        from .data_generator import generate_five_benchmark_datasets
        generate_five_benchmark_datasets("data/raw")

    raw_df = pd.read_csv(filepath)
    clean_df, prep_report = DataPreprocessor.clean_and_preprocess(raw_df, dataset_name=meta["name"])

    ACTIVE_DATASET_ID = d_id
    ACTIVE_DATASET_NAME = meta["name"]
    ACTIVE_DATASET_RUN_ID = f"run_{uuid.uuid4().hex[:8]}"
    ACTIVE_RAW_DF = raw_df
    ACTIVE_DATASET = clean_df
    ACTIVE_PREPROCESSING_REPORT = prep_report
    ACTIVE_ML_EVALUATION = None
    ACTIVE_SIMULATION_TRACE = None

    profiler = DataProfiler(dataset_name=meta["name"])
    profile = profiler.profile_dataframe(clean_df)

    return {
        "status": "success",
        "dataset_id": d_id,
        "dataset_name": meta["name"],
        "dataset_run_id": ACTIVE_DATASET_RUN_ID,
        "filename": meta["filename"],
        "anomaly_type": meta["anomaly_type"],
        "preprocessing_report": prep_report,
        "data_profile": profile
    }


@app.post("/data/generate")
def generate_traffic_data(config: Optional[TrafficScenarioConfig] = None):
    """Generates synthetic traffic time-series dataset."""
    cfg = config or TrafficScenarioConfig()
    df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
    return {
        "scenario_id": cfg.scenario_id,
        "scenario_type": cfg.scenario_type,
        "total_records": len(df),
        "data_sample": df.head(100).to_dict(orient="records")
    }


@app.post("/data/upload_and_preprocess", response_model=UploadAndPreprocessResponse)
async def upload_and_preprocess_dataset(
    file: UploadFile = File(...)
):
    """
    Ingests, cleans, normalizes, and preprocesses an uploaded traffic dataset (CSV or Excel).
    Imputes missing values, caps physical outliers, enriches features, and updates active session.
    """
    global ACTIVE_DATASET_ID, ACTIVE_DATASET_NAME, ACTIVE_RAW_DF, ACTIVE_DATASET, ACTIVE_PREPROCESSING_REPORT, ACTIVE_DATASET_RUN_ID, ACTIVE_ML_EVALUATION, ACTIVE_SIMULATION_TRACE
    content = await file.read()
    filename = file.filename or "uploaded_traffic_data.csv"
    try:
        if filename.endswith((".xlsx", ".xls")):
            raw_df = pd.read_excel(io.BytesIO(content))
        else:
            raw_df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse tabular file: {str(e)}")

    clean_df, prep_report = DataPreprocessor.clean_and_preprocess(raw_df, dataset_name=filename)
    ACTIVE_DATASET_ID = "custom_upload"
    ACTIVE_DATASET_NAME = filename
    ACTIVE_DATASET_RUN_ID = f"run_{uuid.uuid4().hex[:8]}"
    ACTIVE_RAW_DF = raw_df
    ACTIVE_DATASET = clean_df
    ACTIVE_PREPROCESSING_REPORT = prep_report
    ACTIVE_ML_EVALUATION = None
    ACTIVE_SIMULATION_TRACE = None

    profiler = DataProfiler(dataset_name=filename)
    profile = profiler.profile_dataframe(clean_df)

    return UploadAndPreprocessResponse(
        filename=filename,
        preprocessing_report=prep_report,
        data_profile=profile
    )


@app.get("/data/active")
def get_active_dataset_info():
    """Returns metadata and preprocessing audit of the currently active dataset session."""
    global ACTIVE_DATASET, ACTIVE_RAW_DF, ACTIVE_DATASET_ID, ACTIVE_DATASET_NAME, ACTIVE_PREPROCESSING_REPORT, ACTIVE_DATASET_RUN_ID, ACTIVE_ML_EVALUATION, ACTIVE_SIMULATION_TRACE
    ensure_default_dataset_loaded()
    is_up = ACTIVE_DATASET is not None
    return {
        "dataset_id": ACTIVE_DATASET_ID,
        "dataset_name": ACTIVE_DATASET_NAME,
        "dataset_run_id": ACTIVE_DATASET_RUN_ID,
        "has_ml_evaluation": ACTIVE_ML_EVALUATION is not None,
        "has_simulation_trace": ACTIVE_SIMULATION_TRACE is not None,
        "is_uploaded": ACTIVE_DATASET_ID == "custom_upload",
        "total_records": len(ACTIVE_DATASET) if is_up else 0,
        "total_raw_records": len(ACTIVE_RAW_DF) if ACTIVE_RAW_DF is not None else 0,
        "columns": list(ACTIVE_DATASET.columns) if is_up else [],
        "anomaly_type": AVAILABLE_DATASETS.get(ACTIVE_DATASET_ID, {}).get("anomaly_type", "Custom Empirical"),
        "preprocessing_report": ACTIVE_PREPROCESSING_REPORT
    }


@app.post("/data/reset_to_synthetic")
def reset_active_dataset():
    """Resets active session back to default Clean Baseline benchmark dataset."""
    global ACTIVE_DATASET_ID, ACTIVE_DATASET_NAME, ACTIVE_RAW_DF, ACTIVE_DATASET, ACTIVE_PREPROCESSING_REPORT, ACTIVE_DATASET_RUN_ID, ACTIVE_ML_EVALUATION, ACTIVE_SIMULATION_TRACE
    raw_file = os.path.join("data", "raw", "clean_baseline.csv")
    if os.path.exists(raw_file):
        raw_df = pd.read_csv(raw_file)
    else:
        from .data_generator import generate_synthetic_traffic_dataset, generate_benchmark_scenarios
        raw_df = generate_synthetic_traffic_dataset(generate_benchmark_scenarios()["asymmetric"])
    clean_df, prep_report = DataPreprocessor.clean_and_preprocess(raw_df, dataset_name="Clean Baseline Traffic (Benchmark)")
    ACTIVE_DATASET_ID = "clean_baseline"
    ACTIVE_DATASET_NAME = "Clean Baseline Traffic (Benchmark)"
    ACTIVE_DATASET_RUN_ID = f"run_{uuid.uuid4().hex[:8]}"
    ACTIVE_RAW_DF = raw_df
    ACTIVE_DATASET = clean_df
    ACTIVE_PREPROCESSING_REPORT = prep_report
    ACTIVE_ML_EVALUATION = None
    ACTIVE_SIMULATION_TRACE = None
    return {
        "status": "success",
        "message": "Reset to Clean Baseline Traffic benchmark dataset.",
        "dataset_run_id": ACTIVE_DATASET_RUN_ID
    }



@app.get("/data/download_cleaned", response_class=PlainTextResponse)
def download_cleaned_dataset():
    """Downloads currently active cleaned dataset as CSV."""
    if ACTIVE_DATASET is not None:
        return ACTIVE_DATASET.to_csv(index=False)
    else:
        cfg = generate_benchmark_scenarios()["asymmetric"]
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        return df.to_csv(index=False)


@app.get("/data/download_template")
def download_synthetic_template():
    """Downloads synthetic template CSV with standard schema for testing user uploads."""
    cfg = generate_benchmark_scenarios()["asymmetric"]
    df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
    csv_text = df.head(150).to_csv(index=False)
    return Response(
        content=csv_text,
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="traffic_data_template.csv"'}
    )


@app.post("/data/profile", response_model=DataProfileResult)
async def profile_traffic_dataset(
    file: Optional[UploadFile] = File(None)
):
    """Profiles an uploaded CSV traffic dataset, the active dataset, or default scenario data."""
    if file:
        content = await file.read()
        raw_df = pd.read_csv(io.BytesIO(content))
        clean_df, _ = DataPreprocessor.clean_and_preprocess(raw_df, file.filename or "uploaded_traffic_data.csv")
        df = clean_df
        filename = file.filename or "uploaded_traffic_data.csv"
    elif ACTIVE_DATASET is not None:
        df = ACTIVE_DATASET.copy()
        filename = ACTIVE_DATASET_NAME
    else:
        # Default fallback to rush hour scenario data
        cfg = generate_benchmark_scenarios()["rush_hour"]
        df = generate_synthetic_traffic_dataset(cfg)
        filename = "synthetic_rush_hour.csv"

    profiler = DataProfiler(dataset_name=filename)
    profile = profiler.profile_dataframe(df)
    return profile


@app.post("/analysis/plan")
def compile_prompt_and_plan(profile: DataProfileResult):
    """Compiles dynamic prompt and generates analysis plan from data profile."""
    compiler = DynamicPromptCompiler()
    prompt_spec = compiler.compile_prompt(profile)
    plan, tokens, mode = planner.llm_service.plan_analysis(prompt_spec)
    return {
        "dynamic_prompt": prompt_spec,
        "analysis_plan": plan,
        "tokens_used": tokens,
        "llm_mode": mode
    }


@app.post("/traffic/optimize", response_model=SignalTimingPlan)
def optimize_signal_timings(
    method: str = "scipy_slsqp",
    approach_demands_vph: Optional[Dict[str, float]] = None,
    queues: Optional[Dict[str, int]] = None
):
    """Calculates feasible signal timings using selected method."""
    demands = approach_demands_vph or {"NB": 750.0, "SB": 700.0, "EB": 250.0, "WB": 200.0}
    if method == "fixed":
        return optimizer.optimize_fixed_baseline(60.0)
    elif method == "webster":
        return optimizer.optimize_webster(demands)
    elif method == "queue_greedy":
        return optimizer.optimize_queue_proportional_greedy(demands, queues=queues)
    else:
        return optimizer.optimize_scipy_slsqp(demands, queues=queues)


@app.post("/simulation/run", response_model=SimulationResult)
def run_simulation(
    scenario: TrafficScenarioConfig,
    timing_plan: SignalTimingPlan,
    controller_name: str = "Custom Controller"
):
    """Executes traffic simulation for a given scenario and timing plan."""
    sim = TrafficSimulator(scenario)
    return sim.run_simulation(timing_plan, controller_name=controller_name)


@app.post("/pipeline/run", response_model=PipelineExecutionTrace)
def run_full_pipeline(
    scenario: Optional[TrafficScenarioConfig] = None
):
    """
    Executes the entire automated TrafficMind AI pipeline:
    1. Generates/Ingests Scenario Data
    2. Data Profiling & Quality Assessment
    3. Dynamic Prompt Compilation
    4. Method Selection & Analytical Planning
    5. Baseline A & B Simulation (CRN)
    6. Adaptive Optimization
    7. Independent Verification & Self-Correction Loop
    8. Records trace and returns full comparative audit
    """
    cfg = scenario or generate_benchmark_scenarios()["rush_hour"]

    # 1. Ingest/Generate Observation DataFrame
    if scenario is not None and scenario.scenario_type == "custom":
        # Custom scenario configured in Experiment Builder: strictly preserve user approaches, rates, queues, constraints
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        dataset_name = f"custom_scenario_seed{cfg.seed}"
    elif ACTIVE_DATASET is not None and len(ACTIVE_DATASET) > 0:
        df = ACTIVE_DATASET.copy()
        dataset_name = ACTIVE_DATASET_NAME
        # Harmonize approach rates if columns exist ONLY when no explicit scenario was provided
        if scenario is None and "timestamp_sec" in df.columns and "approach" in df.columns and "arrival_count" in df.columns:
            dur_sec = max(30.0, float(df["timestamp_sec"].max() - df["timestamp_sec"].min()))
            dur_hr = max(0.01, dur_sec / 3600.0)
            for app_id in ["NB", "SB", "EB", "WB"]:
                app_df = df[df["approach"] == app_id]
                tot_arr = app_df["arrival_count"].sum() if len(app_df) > 0 else 0
                rate_vph = max(60.0, float(tot_arr / dur_hr))
                cfg.approaches[app_id] = ApproachConfig(
                    name=app_id,
                    arrival_rate_vph=round(rate_vph, 1),
                    arrival_rate_vpm=round(rate_vph / 60.0, 1),
                    saturation_flow_vph=1800.0,
                    initial_queue=int(app_df["queue_length"].iloc[0]) if "queue_length" in app_df.columns and len(app_df) > 0 else 5
                )
    else:
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        dataset_name = f"{cfg.scenario_type}_observation"

    # 2-4. Plan analysis with user's selected analytical objective and constraints
    profile, prompt_spec, plan, tokens, mode = planner.create_plan_from_dataframe(
        df,
        dataset_name=dataset_name,
        custom_objective=cfg.objective_config.primary_objective,
        constraints=cfg.constraints
    )

    # 5-8. Self-correcting pipeline
    trace = pipeline.execute_pipeline(
        scenario=cfg,
        data_profile=profile,
        dynamic_prompt=prompt_spec,
        analysis_plan=plan,
        tokens_used=tokens,
        llm_mode=mode
    )

    global ACTIVE_SIMULATION_TRACE
    EXECUTION_TRACES[trace.run_id] = trace
    ACTIVE_SIMULATION_TRACE = trace
    return trace


@app.post("/prompt/execute", response_model=PromptExecutionResponse)
def execute_prompt_driven_optimization(
    request: PromptExecutionRequest
):
    """
    Translates an analytical goal into a dynamic prompt specification,
    selects verified solver parameters, executes optimization, and generates an executive narrative.
    """
    global ACTIVE_SIMULATION_TRACE
    cfg = request.scenario or TrafficScenarioConfig()
    cfg.objective_config.primary_objective = request.objective

    # 1. Ingest data
    if request.scenario is not None and request.scenario.scenario_type == "custom":
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        name = f"custom_scenario_seed{cfg.seed}"
    elif request.use_active_dataset and ACTIVE_DATASET is not None:
        df = ACTIVE_DATASET.copy()
        name = ACTIVE_DATASET_NAME
    else:
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        name = f"scenario_{cfg.scenario_type}"

    # 2. Profile & compile custom prompt
    profiler = DataProfiler(dataset_name=name)
    profile = profiler.profile_dataframe(df)

    compiler = DynamicPromptCompiler(cfg.constraints)
    prompt_spec = compiler.compile_prompt(profile, custom_objective=request.objective)

    # 3. Method selection & execution
    plan, tokens, mode = planner.llm_service.plan_analysis(prompt_spec)
    trace = pipeline.execute_pipeline(
        scenario=cfg,
        data_profile=profile,
        dynamic_prompt=prompt_spec,
        analysis_plan=plan,
        tokens_used=tokens,
        llm_mode=mode
    )
    EXECUTION_TRACES[trace.run_id] = trace
    ACTIVE_SIMULATION_TRACE = trace

    # 4. Generate narrative with beginner-friendly wording
    OBJECTIVE_LABELS = {
        "minimize_waiting_time": "Reduce Average Waiting Time",
        "prioritize_dominant": "Help Busy Roads Without Ignoring Others",
        "help_busy_roads": "Help Busy Roads Without Ignoring Others",
        "maximize_throughput": "Move More Vehicles, Reduce Queues",
        "move_more_vehicles": "Move More Vehicles, Reduce Queues",
        "prevent_starvation": "Prevent Long Waits on Less-Busy Roads",
        "prevent_long_waits": "Prevent Long Waits on Less-Busy Roads",
    }
    friendly_goal = OBJECTIVE_LABELS.get(request.objective, request.objective.replace('_', ' ').title())

    prop = trace.final_simulation_proposed
    fixed = trace.baseline_fixed_simulation
    narrative = (
        f"Main Goal: '{friendly_goal}'. "
        f"AI Traffic Analysis selected solver '{plan.chosen_method}' ({plan.rationale}). "
        f"Optimized signal plan achieved average wait of {prop.avg_waiting_time_sec:.1f}s vs fixed baseline {fixed.avg_waiting_time_sec:.1f}s "
        f"({trace.waiting_time_improvement_pct:+.1f}% change). Verified 100% compliant with signal timing constraints."
    )

    return PromptExecutionResponse(
        objective_selected=friendly_goal,
        compiled_prompt=prompt_spec,
        selected_method=plan.chosen_method,
        method_rationale=plan.rationale,
        pipeline_trace=trace,
        executive_narrative=narrative
    )


@app.post("/data/auto_analyze", response_model=AutoAnalysisResponse)
def run_automatic_data_science_analysis():
    """
    Self-Driving Data Science Pipeline:
    1. Ingests and profiles the active dataset.
    2. Runs Kolmogorov-Smirnov & Wasserstein drift detection against baseline.
    3. Selects optimal analytical objective based on empirical traffic regime.
    4. Compiles dynamic prompt and generates analysis plan.
    5. Trains scikit-learn models (Ridge regression with 95% uncertainty intervals, Decision Tree, K-Means).
    6. Executes closed-loop optimization and micro-simulation with 10-point safety verification.
    7. Synthesizes full evidence-based executive narrative and limitations.
    """
    ensure_default_dataset_loaded()
    if ACTIVE_DATASET is not None and len(ACTIVE_DATASET) > 0:
        df = ACTIVE_DATASET.copy()
        name = ACTIVE_DATASET_NAME
    else:
        cfg = generate_benchmark_scenarios()["rush_hour"]
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        name = "Clean Baseline Traffic (Benchmark)"

    # 1. Profile Dataset
    profiler = DataProfiler(dataset_name=name)
    profile = profiler.profile_dataframe(df)

    # Calculate quality scores
    raw_quality = 100.0
    quality_score = 100.0
    if ACTIVE_PREPROCESSING_REPORT:
        raw_quality = ACTIVE_PREPROCESSING_REPORT.initial_quality_score
        quality_score = ACTIVE_PREPROCESSING_REPORT.post_cleaning_quality_score
    else:
        quality_score = max(50.0, round(100.0 - len(profile.quality_issues) * 5.0, 1))
        raw_quality = quality_score

    # 2. Detect Traffic Regime & Data Drift
    drift_res = DataProfiler.detect_data_drift(df)

    # 3. Determine Objective
    if profile.imbalance_ratio > 1.8:
        objective = "asymmetric_flow_balancing"
    elif drift_res["drift_detected"]:
        objective = "congestion_relief"
    else:
        objective = "minimize_average_delay"

    # 4. Compile dynamic prompt & analysis plan
    compiler = DynamicPromptCompiler()
    prompt_spec = compiler.compile_prompt(profile, custom_objective=objective)
    plan, tokens, mode = planner.llm_service.plan_analysis(prompt_spec)

    # 5. ML Models Training & Evaluation
    global ACTIVE_SIMULATION_TRACE, ACTIVE_ML_EVALUATION
    ml_eval = TrafficMLEngine.train_and_evaluate(df, dataset_name=name, dataset_id=ACTIVE_DATASET_ID)
    ACTIVE_ML_EVALUATION = ml_eval

    # 6. Build scenario from empirical flow rates
    sim_cfg = generate_benchmark_scenarios()["rush_hour"]
    if "timestamp_sec" in df.columns and "approach" in df.columns and "arrival_count" in df.columns:
        dur_sec = max(30.0, float(df["timestamp_sec"].max() - df["timestamp_sec"].min()))
        dur_hr = max(0.01, dur_sec / 3600.0)
        for app_id in ["NB", "SB", "EB", "WB"]:
            app_df = df[df["approach"] == app_id]
            tot_arr = app_df["arrival_count"].sum() if len(app_df) > 0 else 0
            rate_vph = max(60.0, float(tot_arr / dur_hr))
            sim_cfg.approaches[app_id] = ApproachConfig(
                name=app_id,
                arrival_rate_vph=round(rate_vph, 1),
                arrival_rate_vpm=round(rate_vph / 60.0, 1),
                saturation_flow_vph=1800.0,
                initial_queue=int(app_df["queue_length"].iloc[0]) if "queue_length" in app_df.columns and len(app_df) > 0 else 5
            )

    # 7. Closed-loop Optimization & Verification
    trace = pipeline.execute_pipeline(
        scenario=sim_cfg,
        data_profile=profile,
        dynamic_prompt=prompt_spec,
        analysis_plan=plan,
        tokens_used=tokens,
        llm_mode=mode
    )
    EXECUTION_TRACES[trace.run_id] = trace
    ACTIVE_SIMULATION_TRACE = trace

    # 8. Executive Narrative
    prop = trace.final_simulation_proposed
    fixed = trace.baseline_fixed_simulation
    narrative = (
        f"Automated Data Science Pipeline completed for '{name}'. "
        f"Data Quality: {quality_score:.1f}%. "
        f"{drift_res['summary']} "
        f"Dynamic prompt compiled objective '{objective.replace('_', ' ').title()}', executing '{plan.chosen_method}'. "
        f"Micro-simulation demonstrated waiting time of {prop.avg_waiting_time_sec:.1f}s vs baseline {fixed.avg_waiting_time_sec:.1f}s "
        f"({trace.waiting_time_improvement_pct:+.1f}% change, Status: {trace.final_status}). "
        f"ML Queue Model achieved R² = {ml_eval.linear_regression.r2:.3f} with 95% prediction interval ±{ml_eval.linear_regression.prediction_interval_95_width:.1f}s "
        f"(coverage: {ml_eval.linear_regression.coverage_95_pct:.1f}%)."
    )

    warnings = []
    if drift_res["drift_detected"]:
        warnings.append("Distribution drift detected against standard baseline; historical signal timing plans may cause queue overflow.")
    if len(df) < 500:
        warnings.append(f"Sample size ({len(df)} records) is relatively small; confidence intervals are wider.")
    if quality_score < 85.0:
        warnings.append("Initial sensor quality issues were present in raw telemetry; verified cleaning and imputation applied.")

    return AutoAnalysisResponse(
        dataset_name=name,
        dataset_quality_score=quality_score,
        raw_quality_score=raw_quality,
        drift_detected=drift_res["drift_detected"],
        drift_summary=drift_res["summary"],
        drift_metrics=drift_res,
        objective_selected=objective,
        compiled_prompt=prompt_spec,
        analysis_plan=plan,
        selected_method=plan.chosen_method,
        method_rationale=plan.rationale,
        llm_mode=mode,
        pipeline_trace=trace,
        ml_evaluation=ml_eval,
        executive_narrative=narrative,
        warnings_and_limitations=warnings
    )


@app.post("/metrics/inspect_calculation", response_model=MetricCalculationDetail)
def inspect_metric_calculation(
    metric_key: str,
    run_id: Optional[str] = None
):
    """Provides step-by-step mathematical audit trail for any traffic metric."""
    trace = None
    if run_id and run_id in EXECUTION_TRACES:
        trace = EXECUTION_TRACES[run_id]
    elif EXECUTION_TRACES:
        trace = list(EXECUTION_TRACES.values())[-1]
    return MetricInspector.inspect_metric(metric_key, trace)


@app.post("/evaluation/compare")
def run_benchmark_evaluation():
    """Runs controlled multi-scenario benchmark evaluation."""
    return benchmark_evaluator.run_benchmark()


@app.post("/eda/analyze", response_model=EDAResult)
async def analyze_traffic_eda(
    file: Optional[UploadFile] = File(None),
    scenario: Optional[str] = Form(None)
):
    """
    Performs comprehensive Exploratory Data Analysis (EDA) on uploaded traffic CSV,
    the active dataset session, or a generated scenario configuration.
    """
    if file:
        content = await file.read()
        name = file.filename or "uploaded_dataset"
        try:
            if name.endswith((".xlsx", ".xls")):
                raw_df = pd.read_excel(io.BytesIO(content))
            else:
                raw_df = pd.read_csv(io.BytesIO(content))
        except Exception:
            raw_df = pd.read_csv(io.BytesIO(content))
        clean_df, _ = DataPreprocessor.clean_and_preprocess(raw_df, dataset_name=name)
        df = clean_df
    elif ACTIVE_DATASET is not None:
        df = ACTIVE_DATASET.copy()
        name = ACTIVE_DATASET_NAME
    else:
        cfg = TrafficScenarioConfig()
        if scenario:
            try:
                cfg_data = json.loads(scenario)
                cfg = TrafficScenarioConfig(**cfg_data)
            except Exception:
                pass
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        name = f"scenario_{cfg.scenario_type}"

    profiler = DataProfiler(dataset_name=name)

    return profiler.perform_eda(df)


@app.post("/experiments/compare_algorithms", response_model=AlgorithmBenchmarkResponse)
def compare_traffic_algorithms(
    scenario: Optional[TrafficScenarioConfig] = None
):
    """
    Executes a multi-algorithm experiment on 100% IDENTICAL vehicle arrivals
    using Common Random Numbers. Compares:
    1. Fixed-Time Baseline
    2. Webster Flow-Ratio Adaptive
    3. Constrained SciPy SLSQP Delay Minimization
    4. Queue-Proportional Greedy Adaptive
    """
    cfg = scenario or TrafficScenarioConfig()
    sim = TrafficSimulator(cfg)
    arrival_schedule = sim.generate_arrival_schedule()

    demands = {app: cfg.approaches[app].arrival_rate_vph for app in cfg.approaches}
    queues = {app: cfg.approaches[app].initial_queue for app in cfg.approaches}

    # 1. Fixed Baseline
    fixed_timings = optimizer.optimize_fixed_baseline(cycle_length=60.0)
    fixed_sim = sim.run_simulation(fixed_timings, "Fixed-Time Baseline", arrival_schedule=arrival_schedule)

    # 2. Webster Adaptive
    webster_timings = optimizer.optimize_webster(demands)
    webster_sim = sim.run_simulation(webster_timings, "Webster Flow-Ratio", arrival_schedule=arrival_schedule)

    # 3. Constrained SciPy SLSQP (with objective weights)
    slsqp_timings = optimizer.optimize_scipy_slsqp(
        approach_demands_vph=demands,
        queues=queues,
        hyperparameters={"objective_config": cfg.objective_config.model_dump()}
    )
    slsqp_sim = sim.run_simulation(slsqp_timings, "SciPy SLSQP Delay Min", arrival_schedule=arrival_schedule)

    # 4. Queue-Proportional Greedy Adaptive
    greedy_timings = optimizer.optimize_queue_proportional_greedy(
        approach_demands_vph=demands,
        queues=queues
    )
    greedy_sim = sim.run_simulation(greedy_timings, "Queue-Proportional Greedy", arrival_schedule=arrival_schedule)

    # 5. Prediction-Informed Adaptive (Predictive forecast & saturation balancing)
    pred_timings = optimizer.optimize_prediction_informed(
        approach_demands_vph=demands,
        queues=queues
    )
    pred_sim = sim.run_simulation(pred_timings, "Prediction-Informed Adaptive", arrival_schedule=arrival_schedule)

    sims = [
        ("Fixed-Time Baseline", fixed_timings, fixed_sim),
        ("Webster Flow-Ratio", webster_timings, webster_sim),
        ("Constrained SciPy SLSQP", slsqp_timings, slsqp_sim),
        ("Queue-Proportional Greedy", greedy_timings, greedy_sim),
        ("Prediction-Informed Adaptive", pred_timings, pred_sim)
    ]

    base_w = max(0.1, fixed_sim.avg_waiting_time_sec)
    base_q = max(0.1, fixed_sim.avg_queue_length)
    base_th = max(0.1, fixed_sim.throughput_vph)

    items: List[AlgorithmComparisonItem] = []
    for name, plan, result in sims:
        val = validator.validate_timings_and_simulation(plan, result)
        w_red = round(((base_w - result.avg_waiting_time_sec) / base_w) * 100.0, 2)
        q_red = round(((base_q - result.avg_queue_length) / base_q) * 100.0, 2)
        th_gain = round(((result.throughput_vph - base_th) / base_th) * 100.0, 2)

        violations = len([c for c in val.checks if not c.passed])

        items.append(AlgorithmComparisonItem(
            algorithm_name=name,
            cycle_length_sec=plan.cycle_length_seconds,
            phases=plan.phases,
            avg_waiting_time_sec=result.avg_waiting_time_sec,
            median_waiting_time_sec=result.median_waiting_time_sec,
            max_waiting_time_sec=result.max_waiting_time_sec,
            avg_queue_length=result.avg_queue_length,
            max_queue_length=result.max_queue_length,
            throughput_vph=result.throughput_vph,
            total_delay_sec=result.total_delay_sec,
            waiting_reduction_pct_vs_fixed=w_red,
            queue_reduction_pct_vs_fixed=q_red,
            throughput_gain_pct_vs_fixed=th_gain,
            is_safe=val.is_valid,
            violations_count=violations
        ))

    best_w = min(items, key=lambda x: x.avg_waiting_time_sec).algorithm_name
    best_q = min(items, key=lambda x: x.avg_queue_length).algorithm_name
    best_th = max(items, key=lambda x: x.throughput_vph).algorithm_name

    return AlgorithmBenchmarkResponse(
        scenario_id=cfg.scenario_id,
        seed=cfg.seed or 42,
        duration_seconds=cfg.duration_seconds,
        algorithms_compared=items,
        best_algorithm_by_waiting_time=best_w,
        best_algorithm_by_queue=best_q,
        best_algorithm_by_throughput=best_th
    )


@app.post("/ml/train_and_evaluate", response_model=MLEvaluationResponse)
def train_and_evaluate_ml_models():
    """
    Trains genuine scikit-learn models (Ridge Regression, Decision Tree Classifier, K-Means Clustering)
    on the currently active cleaned dataset session or generated traffic scenario.
    Returns real train/test metrics, feature coefficients, confusion matrix, and silhouette scores.
    """
    global ACTIVE_ML_EVALUATION
    ensure_default_dataset_loaded()
    if ACTIVE_DATASET is not None and len(ACTIVE_DATASET) > 0:
        df = ACTIVE_DATASET.copy()
        name = ACTIVE_DATASET_NAME
    else:
        cfg = generate_benchmark_scenarios()["rush_hour"]
        df = generate_synthetic_traffic_dataset(cfg, inject_anomalies=False)
        name = "synthetic_rush_hour_dataset"

    eval_res = TrafficMLEngine.train_and_evaluate(df, dataset_name=name, dataset_id=ACTIVE_DATASET_ID)
    ACTIVE_ML_EVALUATION = eval_res
    return eval_res


@app.post("/analytics/graphs", response_model=GraphDataResponse)
def generate_analytics_graphs(request_data: Optional[Dict[str, Any]] = None):
    """
    Generates the 6 real data science visualizations rendered with Matplotlib (Agg backend)
    styled with the Dark Navy & Cyan theme (#0B1220, #151F32, #22D3EE, #60A5FA).
    Simulation graphs (1-4) track authoritative simulation run.
    ML graphs (5-6) track authoritative ML evaluation.
    """
    ensure_default_dataset_loaded()
    scenario = None
    force_new = False
    if request_data:
        if "scenario" in request_data:
            scen_val = request_data["scenario"]
            if scen_val:
                try:
                    scenario = TrafficScenarioConfig(**scen_val)
                except Exception:
                    scenario = None
            force_new = bool(request_data.get("force_new_simulation", False))
        elif "approaches" in request_data:
            try:
                scenario = TrafficScenarioConfig(**request_data)
            except Exception:
                scenario = None
        elif "force_new_simulation" in request_data:
            force_new = bool(request_data["force_new_simulation"])

    df = ACTIVE_DATASET.copy() if ACTIVE_DATASET is not None else None
    trace_to_use = None if force_new else ACTIVE_SIMULATION_TRACE

    return TrafficGraphService.generate_all_graphs(
        simulation_trace=trace_to_use,
        ml_eval=ACTIVE_ML_EVALUATION,
        scenario=scenario,
        dataframe=df,
        dataset_id=ACTIVE_DATASET_ID,
        dataset_name=ACTIVE_DATASET_NAME
    )


@app.get("/analytics/graphs", response_model=GraphDataResponse)
def get_analytics_graphs_default():
    """GET convenience route for analytics graphs."""
    ensure_default_dataset_loaded()
    df = ACTIVE_DATASET.copy() if ACTIVE_DATASET is not None else None
    return TrafficGraphService.generate_all_graphs(
        simulation_trace=ACTIVE_SIMULATION_TRACE,
        ml_eval=ACTIVE_ML_EVALUATION,
        scenario=None,
        dataframe=df,
        dataset_id=ACTIVE_DATASET_ID,
        dataset_name=ACTIVE_DATASET_NAME
    )


@app.post("/prompt/playground")
def prompt_playground(
    objective: str = "minimize_waiting_time",
    scenario: Optional[TrafficScenarioConfig] = None
):
    """
    Dynamic prompt playground: allows users to select custom analytical objectives
    and inspect how the Dynamic Prompt Compiler constructs the exact task directive.
    """
    cfg = scenario or TrafficScenarioConfig()
    df = generate_synthetic_traffic_dataset(cfg)
    profiler = DataProfiler(dataset_name="playground_dataset")
    profile = profiler.profile_dataframe(df)

    obj_mapping = {
        "minimize_waiting_time": "Reduce Average Waiting Time: Minimize volume-weighted average waiting time across all 4 intersection approaches.",
        "prioritize_dominant": f"Help Busy Roads Without Ignoring Others: Prioritize heavy volume on dominant approach {profile.dominant_approach} while enforcing minimum green on opposing cross-streets.",
        "help_busy_roads": f"Help Busy Roads Without Ignoring Others: Prioritize heavy volume on dominant approach {profile.dominant_approach} while enforcing minimum green on opposing cross-streets.",
        "maximize_throughput": "Move More Vehicles, Reduce Queues: Maximize intersection vehicle discharge throughput and mitigate bottleneck oversaturation.",
        "move_more_vehicles": "Move More Vehicles, Reduce Queues: Maximize intersection vehicle discharge throughput and mitigate bottleneck oversaturation.",
        "prevent_starvation": "Prevent Long Waits on Less-Busy Roads: Enforce strict anti-starvation bounds and equitable green-split ratios for minor approaches.",
        "prevent_long_waits": "Prevent Long Waits on Less-Busy Roads: Enforce strict anti-starvation bounds and equitable green-split ratios for minor approaches."
    }
    custom_obj = obj_mapping.get(objective, objective)

    compiler = DynamicPromptCompiler(cfg.constraints)
    prompt_spec = compiler.compile_prompt(profile, custom_objective=custom_obj)
    plan, tokens, mode = planner.llm_service.plan_analysis(prompt_spec)

    return {
        "selected_objective_key": objective,
        "analytical_objective_text": custom_obj,
        "compiled_prompt": prompt_spec,
        "analysis_plan": plan,
        "llm_mode": mode,
        "tokens_used": tokens,
        "data_profile_summary": profile
    }


@app.post("/simulation/what_if", response_model=WhatIfResult)
def run_what_if_experiment(request: WhatIfScenarioConfig):
    """
    What-If Simulation Studio: simulates specific disruptions (accident surge, capacity drop,
    road closures, sensor noise) and compares Fixed vs Adaptive response.
    """
    base_cfg = request.base_scenario
    sim = TrafficSimulator(base_cfg)

    cap_mult = {}
    if request.disruption_type == "capacity_drop":
        cap_mult[request.affected_approach] = 0.5
    elif request.disruption_type == "road_closure":
        cap_mult[request.affected_approach] = 0.05

    arrival_sched = sim.generate_arrival_schedule()

    fixed_timings = optimizer.optimize_fixed_baseline(60.0)
    fixed_sim = sim.run_simulation(
        fixed_timings,
        controller_name="Fixed Controller",
        arrival_schedule=arrival_sched,
        capacity_multipliers=cap_mult
    )

    demands = {app: base_cfg.approaches[app].arrival_rate_vph for app in base_cfg.approaches}
    if request.disruption_type == "accident_surge":
        demands[request.affected_approach] *= request.severity_multiplier

    adaptive_timings = optimizer.optimize_scipy_slsqp(demands)
    adaptive_sim = sim.run_simulation(
        adaptive_timings,
        controller_name="Adaptive Controller",
        arrival_schedule=arrival_sched,
        capacity_multipliers=cap_mult
    )

    diff_sec = fixed_sim.avg_waiting_time_sec - adaptive_sim.avg_waiting_time_sec
    is_regression = adaptive_sim.avg_waiting_time_sec > fixed_sim.avg_waiting_time_sec
    pct_magnitude = round((abs(diff_sec) / max(0.1, fixed_sim.avg_waiting_time_sec)) * 100.0, 2)

    if is_regression:
        benefit_pct = -pct_magnitude
        outcome_label = "REGRESSION"
        obs = (
            f"Disruption '{request.disruption_type}' on approach {request.affected_approach}. "
            f"Fixed-Time controller experienced {fixed_sim.avg_waiting_time_sec:.1f}s average wait. "
            f"Adaptive controller experienced {adaptive_sim.avg_waiting_time_sec:.1f}s average wait "
            f"(REGRESSION: +{pct_magnitude:.1f}% delay increase vs fixed baseline)."
        )
    else:
        benefit_pct = pct_magnitude
        outcome_label = "IMPROVEMENT"
        obs = (
            f"Disruption '{request.disruption_type}' on approach {request.affected_approach}. "
            f"Fixed-Time controller experienced {fixed_sim.avg_waiting_time_sec:.1f}s average wait. "
            f"Adaptive controller achieved {adaptive_sim.avg_waiting_time_sec:.1f}s average wait "
            f"(IMPROVEMENT: -{pct_magnitude:.1f}% delay reduction vs fixed baseline)."
        )

    return WhatIfResult(
        disruption_type=request.disruption_type,
        affected_approach=request.affected_approach,
        fixed_before_wait=fixed_sim.avg_waiting_time_sec,
        fixed_after_wait=fixed_sim.avg_waiting_time_sec,
        adaptive_before_wait=adaptive_sim.avg_waiting_time_sec,
        adaptive_after_wait=adaptive_sim.avg_waiting_time_sec,
        adaptive_mitigation_benefit_pct=benefit_pct,
        is_regression=is_regression,
        outcome_label=outcome_label,
        time_series_fixed=fixed_sim.time_series_sample,
        time_series_adaptive=adaptive_sim.time_series_sample,
        observations=obs
    )


@app.post("/simulation/playback_data", response_model=DualPlaybackResponse)
def get_playback_simulation_stream(request: PlaybackSimulationRequest):
    """
    Returns complete, synchronized second-by-second playback simulation streams
    for both Fixed-Time and Adaptive controllers running under Common Random Numbers (CRN).
    Enables true top-down 2D animated intersection visualization without frontend approximations.
    """
    scenario = request.scenario
    sim = TrafficSimulator(scenario)
    arrival_schedule = sim.generate_arrival_schedule()

    # 1. Fixed Baseline Simulation Stream
    fixed_timings = optimizer.optimize_fixed_baseline(60.0)
    fixed_stream = sim.run_playback_simulation(
        timing_plan=fixed_timings,
        controller_name="Fixed-Time Baseline (60s Equal Split)",
        arrival_schedule=arrival_schedule,
        optimization_explanation="Fixed controller operates on a rigid 60s cycle (26s NS, 26s EW, 8s lost time) regardless of queue buildup or demand fluctuations."
    )

    # 2. Adaptive Controller Stream
    demands = {app: scenario.approaches[app].arrival_rate_vph for app in scenario.approaches}
    queues = {app: scenario.approaches[app].initial_queue for app in scenario.approaches}

    if request.adaptive_method == "webster":
        adaptive_timings = optimizer.optimize_webster(demands)
        method_name = "Webster Flow-Ratio Adaptive"
    elif request.adaptive_method == "greedy":
        adaptive_timings = optimizer.optimize_queue_proportional_greedy(demands, queues)
        method_name = "Queue-Proportional Greedy Adaptive"
    elif request.adaptive_method == "prediction_informed":
        adaptive_timings = optimizer.optimize_prediction_informed(demands, queues)
        method_name = "Prediction-Informed Adaptive Controller"
    else:
        adaptive_timings = optimizer.optimize_scipy_slsqp(demands, queues)
        method_name = "Constrained SciPy SLSQP Adaptive"

    # Derive genuine explanation from optimizer output
    g_ns = adaptive_timings.phases.get("NS", 26.0)
    g_ew = adaptive_timings.phases.get("EW", 26.0)
    d_ns = demands.get("NB", 0) + demands.get("SB", 0)
    d_ew = demands.get("EB", 0) + demands.get("WB", 0)
    ratio = d_ns / max(1.0, d_ew)

    if ratio > 1.25:
        explanation = (
            f"{method_name} allocated {g_ns:.1f}s to NS vs {g_ew:.1f}s to EW because North-South demand "
            f"({d_ns:.0f} vph) is {ratio:.1f}x higher than East-West ({d_ew:.0f} vph), prioritizing dominant corridor clearance."
        )
    elif ratio < 0.8:
        inv_ratio = d_ew / max(1.0, d_ns)
        explanation = (
            f"{method_name} allocated {g_ew:.1f}s to EW vs {g_ns:.1f}s to NS because East-West demand "
            f"({d_ew:.0f} vph) is {inv_ratio:.1f}x higher than North-South ({d_ns:.0f} vph), relieving cross-street congestion."
        )
    else:
        explanation = (
            f"{method_name} computed balanced allocations ({g_ns:.1f}s NS, {g_ew:.1f}s EW) to match symmetric approach flow rates."
        )

    adaptive_stream = sim.run_playback_simulation(
        timing_plan=adaptive_timings,
        controller_name=method_name,
        arrival_schedule=arrival_schedule,
        optimization_explanation=explanation
    )

    # Compute comparative delta
    fixed_wait = fixed_stream.summary.avg_waiting_time_sec
    adapt_wait = adaptive_stream.summary.avg_waiting_time_sec
    diff = fixed_wait - adapt_wait
    is_regr = adapt_wait > fixed_wait
    pct = round((abs(diff) / max(0.1, fixed_wait)) * 100.0, 2)
    delta_pct = -pct if is_regr else pct
    outcome = "REGRESSION" if is_regr else "IMPROVEMENT"

    return DualPlaybackResponse(
        duration_seconds=scenario.duration_seconds,
        seed=scenario.seed,
        scenario_type=scenario.scenario_type,
        fixed_controller=fixed_stream,
        adaptive_controller=adaptive_stream,
        crn_verified=True,
        waiting_time_delta_pct=delta_pct,
        is_regression=is_regr,
        outcome_label=outcome
    )


@app.post("/correction/fault_injection", response_model=FaultInjectionResult)
def test_fault_injection(request: FaultInjectionRequest):
    """
    Self-Correction Debugger & Fault-Injection Lab:
    Deliberately injects safety and performance faults to verify that the
    independent validation engine detects, rejects, and corrects invalid strategies.
    """
    scenario = request.scenario or TrafficScenarioConfig()
    sim = TrafficSimulator(scenario)
    arrival_sched = sim.generate_arrival_schedule()
    fixed_timings = optimizer.optimize_fixed_baseline(60.0)
    fixed_sim = sim.run_simulation(fixed_timings, "Baseline", arrival_schedule=arrival_sched)

    fault_type = request.fault_type
    injected_plan = {}

    if fault_type == "min_green_violation":
        bad_plan = SignalTimingPlan(
            cycle_length_seconds=60.0,
            phases={"NS": 47.0, "EW": 5.0},
            lost_time_total_seconds=8.0,
            optimization_method="fault_injected_min_green"
        )
        injected_plan = bad_plan.model_dump()
    elif fault_type == "max_green_violation":
        bad_plan = SignalTimingPlan(
            cycle_length_seconds=120.0,
            phases={"NS": 95.0, "EW": 17.0},
            lost_time_total_seconds=8.0,
            optimization_method="fault_injected_max_green"
        )
        injected_plan = bad_plan.model_dump()
    elif fault_type == "cycle_sum_mismatch":
        bad_plan = SignalTimingPlan(
            cycle_length_seconds=110.0,
            phases={"NS": 30.0, "EW": 30.0},
            lost_time_total_seconds=8.0,
            optimization_method="fault_injected_cycle_mismatch"
        )
        injected_plan = bad_plan.model_dump()
    elif fault_type == "degraded_timings_injection":
        bad_plan = SignalTimingPlan(
            cycle_length_seconds=60.0,
            phases={"NS": 10.0, "EW": 42.0},
            lost_time_total_seconds=8.0,
            optimization_method="fault_injected_degraded"
        )
        injected_plan = bad_plan.model_dump()
    else:  # malformed_schema
        injected_plan = {"cycle_length_seconds": "invalid_type", "phases": {}}
        bad_plan = SignalTimingPlan(
            cycle_length_seconds=60.0,
            phases={"NS": 26.0, "EW": 26.0},
            lost_time_total_seconds=8.0
        )

    sim_res = sim.run_simulation(bad_plan, "Fault Injected Controller", arrival_schedule=arrival_sched)

    validation = validator.validate_timings_and_simulation(
        timing_plan=bad_plan,
        sim_result=sim_res,
        baseline_fixed_sim=fixed_sim
    )

    detected = not validation.is_valid
    caught_name = validation.checks[0].name if validation.checks else None
    for c in validation.checks:
        if not c.passed:
            caught_name = c.name
            break

    remedy_outcome = "No remedy needed"
    safe_fallback = False
    if detected:
        corrected = optimizer.optimize_webster({app: scenario.approaches[app].arrival_rate_vph for app in scenario.approaches})
        corrected_sim = sim.run_simulation(corrected, "Corrected Controller", arrival_schedule=arrival_sched)
        corrected_val = validator.validate_timings_and_simulation(corrected, corrected_sim, baseline_fixed_sim=None)
        if corrected_val.is_valid:
            remedy_outcome = f"Fault detected and autonomously corrected to valid Webster plan (Cycle={corrected.cycle_length_seconds}s)."
            safe_fallback = False
        else:
            remedy_outcome = "Correction failed; enforced safe deterministic fixed-time fallback."
            safe_fallback = True

    return FaultInjectionResult(
        fault_type=fault_type,
        injected_plan=injected_plan,
        detected_by_validator=detected,
        caught_check_name=caught_name,
        failure_category=validation.failure_category,
        diagnostic_message=validation.diagnostic_message,
        remedial_action_attempted=True,
        remedy_outcome=remedy_outcome,
        safe_fallback_enforced=safe_fallback
    )


@app.get("/analysis/{run_id}", response_model=PipelineExecutionTrace)
def get_analysis_trace(run_id: str):
    """Retrieves execution trace by run ID."""
    if run_id not in EXECUTION_TRACES:
        raise HTTPException(status_code=404, detail=f"Run ID '{run_id}' not found.")
    return EXECUTION_TRACES[run_id]


@app.get("/reports/{run_id}", response_class=PlainTextResponse)
def get_markdown_report(run_id: str):
    """Retrieves generated Markdown analytical report for a run ID."""
    if run_id not in EXECUTION_TRACES:
        raise HTTPException(status_code=404, detail=f"Run ID '{run_id}' not found.")
    trace = EXECUTION_TRACES[run_id]
    return ReportGenerator.generate_markdown_report(trace)


# Mount static frontend dashboard
frontend_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
if os.path.exists(frontend_dir):
    from fastapi.staticfiles import StaticFiles
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")
