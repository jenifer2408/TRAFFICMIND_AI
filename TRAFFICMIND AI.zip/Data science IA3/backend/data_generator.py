"""
TrafficMind AI - Synthetic Traffic Data Generator
Generates realistic, reproducible traffic intersection datasets for testing and benchmarking.
Supports normal conditions, rush hour peaks, asymmetric demand, and sudden traffic incidents.
"""

import numpy as np
import pandas as pd
from typing import Dict, Optional, Tuple
from .schemas import TrafficScenarioConfig, ApproachConfig


def generate_synthetic_traffic_dataset(
    config: Optional[TrafficScenarioConfig] = None,
    output_filepath: Optional[str] = None,
    inject_anomalies: bool = False
) -> pd.DataFrame:
    """
    Generates a time-series dataset of traffic arrivals, queues, and phases at a 4-way intersection.
    Approaches: NB (Northbound), SB (Southbound), EB (Eastbound), WB (Westbound).
    """
    if config is None:
        config = TrafficScenarioConfig()

    rng = np.random.default_rng(config.seed)
    time_steps = int(config.duration_seconds / config.time_step_seconds)
    timestamps = [i * config.time_step_seconds for i in range(time_steps)]

    records = []

    # Approach parameters
    approaches = config.approaches
    current_queues = {k: v.initial_queue for k, v in approaches.items()}

    # Base arrival rates in veh/sec
    base_rates = {k: v.arrival_rate_vph / 3600.0 for k, v in approaches.items()}

    # Phase schedule (standard 60s cycle for baseline ground-truth observation)
    # Phase 0: NS Green (26s), Yellow (3s), All-Red (1s) -> 30s
    # Phase 1: EW Green (26s), Yellow (3s), All-Red (1s) -> 30s
    cycle_length = 60.0

    for t_idx, t_sec in enumerate(timestamps):
        cycle_pos = t_sec % cycle_length
        if cycle_pos < 26.0:
            current_phase = "NS_GREEN"
            green_approaches = ["NB", "SB"]
        elif cycle_pos < 29.0:
            current_phase = "NS_YELLOW"
            green_approaches = []
        elif cycle_pos < 30.0:
            current_phase = "ALL_RED"
            green_approaches = []
        elif cycle_pos < 56.0:
            current_phase = "EW_GREEN"
            green_approaches = ["EB", "WB"]
        elif cycle_pos < 59.0:
            current_phase = "EW_YELLOW"
            green_approaches = []
        else:
            current_phase = "ALL_RED"
            green_approaches = []

        # Check if an incident surge is active
        is_incident_time = (
            config.incident_approach is not None
            and config.incident_start_sec <= t_sec < (config.incident_start_sec + config.incident_duration_sec)
        )

        for app_id, app_cfg in approaches.items():
            rate = base_rates[app_id]

            # Scenario adjustments
            if config.scenario_type == "rush_hour":
                # Sine wave surge simulating peak hour arrival
                surge = 1.0 + 0.35 * np.sin(np.pi * t_sec / config.duration_seconds)
                rate *= surge
            elif config.scenario_type == "asymmetric":
                # NB/SB have high demand, EB/WB have light demand
                if app_id in ["NB", "SB"]:
                    rate *= 1.2
                else:
                    rate *= 0.6
            elif config.scenario_type == "incident" and is_incident_time:
                if app_id == config.incident_approach:
                    rate *= config.incident_surge_factor

            # Arrivals: Poisson distributed
            arrivals = int(rng.poisson(rate * config.time_step_seconds))

            # Discharges
            sat_flow_sec = app_cfg.saturation_flow_vph / 3600.0
            max_discharge = sat_flow_sec * config.time_step_seconds

            if app_id in green_approaches:
                discharges = min(current_queues[app_id] + arrivals, int(max_discharge))
            else:
                discharges = 0

            # Update queue
            current_queues[app_id] = max(0, current_queues[app_id] + arrivals - discharges)

            # Waiting time approximation: queue * time_step
            avg_wait_sec = current_queues[app_id] * 2.5 + rng.normal(0, 0.5)
            avg_wait_sec = max(0.0, avg_wait_sec)

            records.append({
                "timestamp_sec": round(t_sec, 2),
                "intersection_id": "INT_001",
                "approach": app_id,
                "arrival_count": arrivals,
                "discharge_count": discharges,
                "queue_length": current_queues[app_id],
                "estimated_waiting_time_sec": round(avg_wait_sec, 2),
                "active_phase": current_phase,
                "saturation_flow_vph": app_cfg.saturation_flow_vph,
                "scenario_type": config.scenario_type
            })

    df = pd.DataFrame(records)

    if inject_anomalies:
        # Inject realistic data science issues: 2% missing values and few outlier sensor readings
        sample_indices = rng.choice(df.index, size=int(0.02 * len(df)), replace=False)
        df.loc[sample_indices, "queue_length"] = np.nan

        outlier_indices = rng.choice(df.index, size=5, replace=False)
        df.loc[outlier_indices, "arrival_count"] = df.loc[outlier_indices, "arrival_count"] * 10

    if output_filepath:
        df.to_csv(output_filepath, index=False)

    return df


def generate_benchmark_scenarios() -> Dict[str, TrafficScenarioConfig]:
    """Generates standard predefined scenarios for comparative evaluation."""
    return {
        "normal": TrafficScenarioConfig(
            scenario_id="scenario_normal_flow",
            scenario_type="normal",
            duration_seconds=300,
            seed=101,
            approaches={
                "NB": ApproachConfig(name="NB", arrival_rate_vph=450.0, saturation_flow_vph=1800.0, initial_queue=4),
                "SB": ApproachConfig(name="SB", arrival_rate_vph=420.0, saturation_flow_vph=1800.0, initial_queue=3),
                "EB": ApproachConfig(name="EB", arrival_rate_vph=380.0, saturation_flow_vph=1800.0, initial_queue=3),
                "WB": ApproachConfig(name="WB", arrival_rate_vph=360.0, saturation_flow_vph=1800.0, initial_queue=2),
            }
        ),
        "rush_hour": TrafficScenarioConfig(
            scenario_id="scenario_rush_hour",
            scenario_type="rush_hour",
            duration_seconds=300,
            seed=202,
            approaches={
                "NB": ApproachConfig(name="NB", arrival_rate_vph=850.0, saturation_flow_vph=1800.0, initial_queue=18),
                "SB": ApproachConfig(name="SB", arrival_rate_vph=800.0, saturation_flow_vph=1800.0, initial_queue=15),
                "EB": ApproachConfig(name="EB", arrival_rate_vph=550.0, saturation_flow_vph=1800.0, initial_queue=8),
                "WB": ApproachConfig(name="WB", arrival_rate_vph=500.0, saturation_flow_vph=1800.0, initial_queue=7),
            }
        ),
        "asymmetric": TrafficScenarioConfig(
            scenario_id="scenario_asymmetric",
            scenario_type="asymmetric",
            duration_seconds=300,
            seed=303,
            approaches={
                "NB": ApproachConfig(name="NB", arrival_rate_vph=950.0, saturation_flow_vph=1800.0, initial_queue=24),
                "SB": ApproachConfig(name="SB", arrival_rate_vph=900.0, saturation_flow_vph=1800.0, initial_queue=20),
                "EB": ApproachConfig(name="EB", arrival_rate_vph=180.0, saturation_flow_vph=1800.0, initial_queue=2),
                "WB": ApproachConfig(name="WB", arrival_rate_vph=150.0, saturation_flow_vph=1800.0, initial_queue=2),
            }
        ),
        "incident": TrafficScenarioConfig(
            scenario_id="scenario_incident_surge",
            scenario_type="incident",
            duration_seconds=300,
            seed=404,
            incident_approach="NB",
            incident_surge_factor=2.8,
            incident_start_sec=60,
            incident_duration_sec=120,
            approaches={
                "NB": ApproachConfig(name="NB", arrival_rate_vph=500.0, saturation_flow_vph=1800.0, initial_queue=5),
                "SB": ApproachConfig(name="SB", arrival_rate_vph=450.0, saturation_flow_vph=1800.0, initial_queue=4),
                "EB": ApproachConfig(name="EB", arrival_rate_vph=400.0, saturation_flow_vph=1800.0, initial_queue=3),
                "WB": ApproachConfig(name="WB", arrival_rate_vph=350.0, saturation_flow_vph=1800.0, initial_queue=3),
            }
        )
    }


def generate_five_benchmark_datasets(output_dir: Optional[str] = "data/raw") -> Dict[str, pd.DataFrame]:
    """
    Generates the 5 distinct, reproducible raw traffic CSV datasets for TrafficMind AI:
    1. clean_baseline: Clean baseline dataset (100% quality, 0 missing, 0 invalid, 0 duplicates).
    2. missing_values: Controlled 6% missing values (MCAR) in arrival_count and queue_length.
    3. sensor_anomalies: Hardware sensor anomalies with negative arrivals (-2 to -8) and optical spikes (50-95 veh/s).
    4. duplicate_records: Transmission packet bursts producing duplicate timestamp/approach rows.
    5. mixed_quality_traffic: Realistic dirty dataset combining missing values (5%), negative readings (3%), spikes (2%), and duplicates (4%).
    """
    import os
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    base_cfg = TrafficScenarioConfig(
        scenario_id="scenario_benchmark_base",
        scenario_type="asymmetric",
        duration_seconds=300,
        time_step_seconds=1.0,
        seed=101,
        approaches={
            "NB": ApproachConfig(name="NB", arrival_rate_vph=750.0, saturation_flow_vph=1800.0, initial_queue=10),
            "SB": ApproachConfig(name="SB", arrival_rate_vph=680.0, saturation_flow_vph=1800.0, initial_queue=8),
            "EB": ApproachConfig(name="EB", arrival_rate_vph=240.0, saturation_flow_vph=1800.0, initial_queue=3),
            "WB": ApproachConfig(name="WB", arrival_rate_vph=210.0, saturation_flow_vph=1800.0, initial_queue=2),
        }
    )

    # 1. Clean Baseline Dataset
    df_clean = generate_synthetic_traffic_dataset(base_cfg, inject_anomalies=False)
    if output_dir:
        df_clean.to_csv(os.path.join(output_dir, "clean_baseline.csv"), index=False)

    # 2. Missing Values Dataset (6% missing in arrival_count & queue_length)
    rng_missing = np.random.default_rng(202)
    df_missing = df_clean.copy()
    n_miss = int(len(df_missing) * 0.06)
    miss_arr_idx = rng_missing.choice(df_missing.index, size=n_miss, replace=False)
    miss_q_idx = rng_missing.choice(df_missing.index, size=n_miss, replace=False)
    # Using float representation for column to hold NaN cleanly
    df_missing["arrival_count"] = df_missing["arrival_count"].astype(float)
    df_missing["queue_length"] = df_missing["queue_length"].astype(float)
    df_missing.loc[miss_arr_idx, "arrival_count"] = np.nan
    df_missing.loc[miss_q_idx, "queue_length"] = np.nan
    if output_dir:
        df_missing.to_csv(os.path.join(output_dir, "missing_values.csv"), index=False)

    # 3. Sensor Anomalies Dataset (Negative counts + extreme spikes)
    rng_anom = np.random.default_rng(303)
    df_anom = df_clean.copy()
    neg_idx = rng_anom.choice(df_anom.index, size=int(len(df_anom) * 0.035), replace=False)
    spike_idx = rng_anom.choice(list(set(df_anom.index) - set(neg_idx)), size=int(len(df_anom) * 0.025), replace=False)
    df_anom.loc[neg_idx, "arrival_count"] = rng_anom.choice([-2, -4, -6, -8], size=len(neg_idx))
    df_anom.loc[spike_idx, "arrival_count"] = rng_anom.integers(50, 95, size=len(spike_idx))
    if output_dir:
        df_anom.to_csv(os.path.join(output_dir, "sensor_anomalies.csv"), index=False)

    # 4. Duplicate Records Dataset (Duplicate rows from packet burst)
    rng_dup = np.random.default_rng(404)
    dup_sample = df_clean.sample(n=42, random_state=404)
    df_dup = pd.concat([df_clean, dup_sample], ignore_index=True)
    df_dup.sort_values(by=["timestamp_sec", "approach"], inplace=True)
    df_dup.reset_index(drop=True, inplace=True)
    if output_dir:
        df_dup.to_csv(os.path.join(output_dir, "duplicate_records.csv"), index=False)

    # 5. Mixed Quality Traffic Dataset (Combination of missing, negative, spikes, duplicates)
    rng_mix = np.random.default_rng(505)
    df_mix = df_clean.copy()
    # Missing values (4%)
    m_idx = rng_mix.choice(df_mix.index, size=int(len(df_mix) * 0.04), replace=False)
    df_mix["arrival_count"] = df_mix["arrival_count"].astype(float)
    df_mix.loc[m_idx, "arrival_count"] = np.nan
    # Negative sensor values (3%)
    neg_mix_idx = rng_mix.choice(list(set(df_mix.index) - set(m_idx)), size=int(len(df_mix) * 0.03), replace=False)
    df_mix.loc[neg_mix_idx, "arrival_count"] = rng_mix.choice([-3, -5, -7], size=len(neg_mix_idx))
    # Extreme spikes (2%)
    spk_mix_idx = rng_mix.choice(list(set(df_mix.index) - set(m_idx) - set(neg_mix_idx)), size=int(len(df_mix) * 0.02), replace=False)
    df_mix.loc[spk_mix_idx, "arrival_count"] = rng_mix.integers(55, 90, size=len(spk_mix_idx))
    # Duplicates (30 rows)
    dup_mix_sample = df_mix.sample(n=30, random_state=505)
    df_mix = pd.concat([df_mix, dup_mix_sample], ignore_index=True)
    df_mix.sort_values(by=["timestamp_sec", "approach"], inplace=True)
    df_mix.reset_index(drop=True, inplace=True)
    if output_dir:
        df_mix.to_csv(os.path.join(output_dir, "mixed_quality_traffic.csv"), index=False)

    return {
        "clean_baseline": df_clean,
        "missing_values": df_missing,
        "sensor_anomalies": df_anom,
        "duplicate_records": df_dup,
        "mixed_quality": df_mix
    }

