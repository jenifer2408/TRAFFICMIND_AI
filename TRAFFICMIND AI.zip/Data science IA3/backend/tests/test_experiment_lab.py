"""
TrafficMind AI - Comprehensive Automated Tests for Data Science Experimentation Lab
Tests:
1. Four-approach arrival rate configuration (75, 45, 30, 35 vpm).
2. Common Random Numbers (CRN) identical arrival events across controllers.
3. Strict zero-degradation acceptance criteria.
4. Independent verification and fault injection rejection.
5. New API endpoints: /eda/analyze, /experiments/compare_algorithms, /prompt/playground, /simulation/what_if, /correction/fault_injection.
"""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.schemas import (
    TrafficScenarioConfig,
    ApproachConfig,
    SignalTimingConstraints,
    SignalTimingPlan,
    OptimizationObjectiveConfig,
    FaultInjectionRequest
)
from backend.traffic_simulator import TrafficSimulator
from backend.traffic_optimizer import TrafficOptimizer
from backend.validation_engine import ValidationEngine

client = TestClient(app)


def test_custom_arrival_rate_defaults():
    """Verifies the four arrival rates specified in requirements: 75, 45, 30, 35 vpm."""
    cfg = TrafficScenarioConfig()
    approaches = cfg.approaches

    assert approaches["NB"].arrival_rate_vpm == 75.0
    assert approaches["NB"].arrival_rate_vph == 4500.0

    assert approaches["SB"].arrival_rate_vpm == 45.0
    assert approaches["SB"].arrival_rate_vph == 2700.0

    assert approaches["EB"].arrival_rate_vpm == 30.0
    assert approaches["EB"].arrival_rate_vph == 1800.0

    assert approaches["WB"].arrival_rate_vpm == 35.0
    assert approaches["WB"].arrival_rate_vph == 2100.0


def test_common_random_numbers_identical_arrivals():
    """
    Verifies that Common Random Numbers ensure 100% identical arrivals across controllers.
    """
    cfg = TrafficScenarioConfig(seed=999, duration_seconds=60)
    sim = TrafficSimulator(cfg)
    sched = sim.generate_arrival_schedule()

    opt = TrafficOptimizer()
    fixed_timings = opt.optimize_fixed_baseline(60.0)
    webster_timings = opt.optimize_webster({k: v.arrival_rate_vph for k, v in cfg.approaches.items()})

    res_fixed = sim.run_simulation(fixed_timings, "Fixed", arrival_schedule=sched)
    res_adapt = sim.run_simulation(webster_timings, "Adaptive", arrival_schedule=sched)

    # Identical total arrivals across every single approach
    for app in ["NB", "SB", "EB", "WB"]:
        assert res_fixed.approach_metrics[app].total_arrivals == res_adapt.approach_metrics[app].total_arrivals
    assert res_fixed.total_vehicles_arrived == res_adapt.total_vehicles_arrived


def test_fixed_controller_is_genuinely_fixed():
    """
    Verifies the fixed-time controller maintains constant green duration
    regardless of severe asymmetric queue buildups.
    """
    opt = TrafficOptimizer()
    plan1 = opt.optimize_fixed_baseline(cycle_length=60.0)
    plan2 = opt.optimize_fixed_baseline(cycle_length=60.0)

    assert plan1.phases["NS"] == 26.0
    assert plan1.phases["EW"] == 26.0
    assert plan1.phases == plan2.phases


def test_strict_zero_degradation_acceptance():
    """
    Verifies that any strategy that increases waiting time vs fixed baseline
    is strictly rejected (no 5% degradation pass loophole).
    """
    validator = ValidationEngine(degradation_tolerance_pct=0.0)
    opt = TrafficOptimizer()
    plan = opt.optimize_fixed_baseline(60.0)

    cfg = TrafficScenarioConfig(duration_seconds=60)
    sim = TrafficSimulator(cfg)
    fixed_res = sim.run_simulation(plan)

    # Simulated degraded result with 4.93% higher waiting time
    degraded_res = fixed_res.model_copy(deep=True)
    degraded_res.avg_waiting_time_sec = fixed_res.avg_waiting_time_sec * 1.0493

    val = validator.validate_timings_and_simulation(
        timing_plan=plan,
        sim_result=degraded_res,
        baseline_fixed_sim=fixed_res,
        degradation_tolerance_pct=0.0
    )

    # Must be marked as failure and failure category must be DEGRADED_PERFORMANCE_VS_BASELINE
    assert not val.is_valid
    assert val.failure_category == "DEGRADED_PERFORMANCE_VS_BASELINE"
    assert "violates strict 0.0% degradation limit" in val.diagnostic_message


def test_api_eda_analyze():
    """Tests /eda/analyze endpoint."""
    resp = client.post("/eda/analyze")
    assert resp.status_code == 200
    data = resp.json()
    assert "approach_stats" in data
    assert "NB" in data["approach_stats"]
    assert "correlation_matrix" in data
    assert "arrival_distributions" in data


def test_api_compare_algorithms():
    """Tests /experiments/compare_algorithms endpoint."""
    resp = client.post("/experiments/compare_algorithms")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["algorithms_compared"]) == 5
    names = [a["algorithm_name"] for a in data["algorithms_compared"]]
    assert "Fixed-Time Baseline" in names
    assert "Webster Flow-Ratio" in names
    assert "Constrained SciPy SLSQP" in names
    assert "Queue-Proportional Greedy" in names
    assert "Prediction-Informed Adaptive" in names


def test_api_prompt_playground():
    """Tests /prompt/playground endpoint with analytical objectives."""
    resp = client.post("/prompt/playground?objective=prioritize_dominant")
    assert resp.status_code == 200
    data = resp.json()
    assert "compiled_prompt" in data
    assert data["llm_mode"].startswith("ollama_") or "mock" in data["llm_mode"] or data["llm_mode"] == "live_api"




def test_api_what_if_disruption():
    """Tests /simulation/what_if endpoint."""
    cfg = TrafficScenarioConfig(duration_seconds=90)
    payload = {
        "scenario_id": "what_if_test",
        "base_scenario": cfg.model_dump(),
        "disruption_type": "accident_surge",
        "affected_approach": "NB",
        "severity_multiplier": 2.5
    }
    resp = client.post("/simulation/what_if", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert data["disruption_type"] == "accident_surge"
    assert "adaptive_mitigation_benefit_pct" in data
    assert len(data["time_series_fixed"]) > 0


def test_api_fault_injection_debugger():
    """Tests /correction/fault_injection endpoint."""
    payload = {"fault_type": "min_green_violation"}
    resp = client.post("/correction/fault_injection", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert data["detected_by_validator"] is True
    assert data["failure_category"] == "CONSTRAINT_VIOLATION_MIN_GREEN"
    assert "autonomously corrected" in data["remedy_outcome"]


def test_what_if_regression_detection():
    """
    Verifies that when adaptive control experiences a longer wait than baseline
    (e.g. 121.0s vs 120.1s), it is accurately flagged as a REGRESSION, not an improvement.
    """
    cfg = TrafficScenarioConfig(duration_seconds=60)
    payload = {
        "scenario_id": "regression_test",
        "base_scenario": cfg.model_dump(),
        "disruption_type": "road_closure",
        "affected_approach": "NB",
        "severity_multiplier": 1.0
    }
    resp = client.post("/simulation/what_if", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "is_regression" in data
    assert "outcome_label" in data
    if data["is_regression"]:
        assert data["outcome_label"] == "REGRESSION"
        assert data["adaptive_mitigation_benefit_pct"] < 0
        assert "REGRESSION:" in data["observations"]
    else:
        assert data["outcome_label"] == "IMPROVEMENT"
        assert data["adaptive_mitigation_benefit_pct"] >= 0


def test_failed_candidate_cannot_be_optimal_verified():
    """
    Verifies that any candidate that violates constraints or degrades performance
    CANNOT receive OPTIMAL_VERIFIED status and triggers safe fallback.
    """
    from backend.correction_loop import SelfCorrectingPipeline
    from backend.schemas import SignalTimingConstraints, DataProfileResult, DynamicPromptSpecification, AnalysisPlan

    class DegradedOptimizer(TrafficOptimizer):
        def optimize_scipy_slsqp(self, *args, **kwargs):
            # Deliberately produces an illegal plan violating min_green
            plan = super().optimize_fixed_baseline(60.0)
            plan.phases["NS"] = 4.0  # Illegal: below 10.0s min green
            plan.phases["EW"] = 48.0
            return plan

    pipeline = SelfCorrectingPipeline(max_retries=1, optimizer=DegradedOptimizer())
    cfg = TrafficScenarioConfig(duration_seconds=60)
    profile = DataProfileResult(
        dataset_name="test",
        total_records=100,
        column_names=["timestamp_sec", "approach", "arrival_count"],
        missing_value_counts={},
        imbalance_ratio=1.0,
        dominant_approach="NB",
        total_demand_vph=2000.0,
        detected_traffic_pattern="balanced_normal",
        quality_score_pct=100.0,
        summary_text="test"
    )
    prompt_spec = DynamicPromptSpecification(
        prompt_id="test",
        scenario_summary="test",
        traffic_profile={},
        detected_imbalance={},
        analytical_objective="test",
        candidate_methods=[],
        signal_constraints=SignalTimingConstraints(),
        expected_output_schema={},
        verification_checks=[],
        compiled_prompt_text="test"
    )
    plan = AnalysisPlan(
        plan_id="test",
        chosen_method="scipy_slsqp_delay_minimization",
        objective_formulation="test",
        hyperparameters={},
        rationale="test"
    )

    trace = pipeline.execute_pipeline(cfg, profile, prompt_spec, plan)
    # The failed candidate MUST NOT receive OPTIMAL_VERIFIED
    assert trace.final_status != "OPTIMAL_VERIFIED"
    assert trace.final_status in ["FAILED_MAX_RETRIES", "SUBOPTIMAL_VERIFIED"]


def test_api_simulation_playback_data():
    """
    Verifies that /simulation/playback_data returns synchronized tick streams
    for top-down 2D animated intersection visualization under Common Random Numbers.
    """
    cfg = TrafficScenarioConfig(duration_seconds=30)
    payload = {
        "scenario": cfg.model_dump(),
        "adaptive_method": "scipy_slsqp"
    }
    resp = client.post("/simulation/playback_data", json=payload)
    assert resp.status_code == 200
    data = resp.json()

    assert data["crn_verified"] is True
    assert len(data["fixed_controller"]["ticks"]) == 30
    assert len(data["adaptive_controller"]["ticks"]) == 30

    # Verify approach states and phases exist in tick 0
    tick0 = data["adaptive_controller"]["ticks"][0]
    assert "active_phase" in tick0
    assert "NB" in tick0["approaches"]
    assert tick0["approaches"]["NB"]["signal_color"] in ["RED", "YELLOW", "GREEN"]
    assert "optimization_explanation" in data["adaptive_controller"]
    assert len(data["adaptive_controller"]["optimization_explanation"]) > 10


def test_all_algorithms_satisfy_safety_constraints():
    """
    Verifies that all 4 optimization methods satisfy minimum green, maximum green,
    and cycle conservation equations.
    """
    opt = TrafficOptimizer()
    demands = {"NB": 3500.0, "SB": 2800.0, "EB": 600.0, "WB": 500.0}
    queues = {"NB": 25, "SB": 18, "EB": 3, "WB": 2}

    plans = [
        opt.optimize_fixed_baseline(60.0),
        opt.optimize_webster(demands),
        opt.optimize_scipy_slsqp(demands, queues),
        opt.optimize_queue_proportional_greedy(demands, queues),
        opt.optimize_prediction_informed(demands, queues)
    ]

    for p in plans:
        # Minimum green (>= 10.0s)
        assert min(p.phases.values()) >= 9.99
        # Maximum green (<= 90.0s)
        assert max(p.phases.values()) <= 90.01
        # Cycle conservation: sum(phases) + lost_time == cycle_length
        total_p = sum(p.phases.values())
        assert abs((total_p + p.lost_time_total_seconds) - p.cycle_length_seconds) < 0.1


def test_api_download_synthetic_template():
    """Verifies that the synthetic template endpoint returns a 200 CSV with headers."""
    resp = client.get("/data/download_template")
    assert resp.status_code == 200
    assert "text/csv" in resp.headers["content-type"]
    assert "traffic_data_template.csv" in resp.headers["content-disposition"]
    text = resp.text
    assert "timestamp_sec" in text
    assert "approach" in text
    assert "arrival_count" in text


def test_api_ml_train_and_evaluate():
    """Verifies that the scikit-learn ML engine trains and returns genuine metrics."""
    resp = client.post("/ml/train_and_evaluate")
    assert resp.status_code == 200
    data = resp.json()
    assert data["model_mode"] == "trained_scikit_learn"
    assert "linear_regression" in data
    assert "r2" in data["linear_regression"]
    assert "decision_tree" in data
    assert "accuracy" in data["decision_tree"]
    assert "kmeans" in data
    assert "silhouette_score" in data["kmeans"]


def test_api_analytics_graphs():
    """Verifies that the 6 required graphs are generated with Matplotlib base64 PNGs."""
    resp = client.post("/analytics/graphs")
    assert resp.status_code == 200
    data = resp.json()
    assert "image_base64" in data
    images = data["image_base64"]
    required_charts = [
        "fixed_vs_adaptive",
        "queue_over_time",
        "waiting_distribution",
        "waiting_by_direction",
        "actual_vs_predicted",
        "traffic_clusters"
    ]
    for chart in required_charts:
        assert chart in images
        assert images[chart].startswith("data:image/png;base64,")


def test_api_llm_status_and_insights():
    """Verifies Ollama LLM status and narrative insights endpoint."""
    resp = client.get("/llm/status")
    assert resp.status_code == 200
    data = resp.json()
    assert "mode" in data
    assert "running" in data

    resp_ins = client.post("/llm/generate_insights", json={
        "context_data": {"total_rows": 100, "dominant_approach": "NB", "imbalance_ratio": 2.5},
        "goal_type": "eda"
    })
    assert resp_ins.status_code == 200
    ins_data = resp_ins.json()
    assert len(ins_data["narrative"]) > 20


def test_pipeline_run_custom_scenario_preserves_inputs():
    """
    Verifies that /pipeline/run preserves custom scenario inputs (arrival rates, queues, objective)
    and does NOT overwrite them with the active dataset.
    """
    custom_scenario = {
        "scenario_id": "test_custom_exp",
        "scenario_type": "custom",
        "duration_seconds": 120,
        "time_step_seconds": 1.0,
        "seed": 777,
        "approaches": {
            "NB": {"name": "NB", "arrival_rate_vph": 5700.0, "arrival_rate_vpm": 95.0, "saturation_flow_vph": 1800.0, "initial_queue": 25},
            "SB": {"name": "SB", "arrival_rate_vph": 3000.0, "arrival_rate_vpm": 50.0, "saturation_flow_vph": 1800.0, "initial_queue": 25},
            "EB": {"name": "EB", "arrival_rate_vph": 900.0, "arrival_rate_vpm": 15.0, "saturation_flow_vph": 1800.0, "initial_queue": 2},
            "WB": {"name": "WB", "arrival_rate_vph": 600.0, "arrival_rate_vpm": 10.0, "saturation_flow_vph": 1800.0, "initial_queue": 2}
        },
        "constraints": {
            "min_green_seconds": 12.0,
            "max_green_seconds": 85.0,
            "yellow_seconds": 3.5,
            "all_red_seconds": 1.5
        },
        "objective_config": {
            "primary_objective": "prioritize_dominant",
            "weight_waiting_time": 1.0,
            "weight_queue_length": 1.5,
            "weight_throughput": 0.5
        }
    }

    resp = client.post("/pipeline/run", json=custom_scenario)
    assert resp.status_code == 200
    trace = resp.json()

    assert trace["scenario_type"] == "custom"
    assert trace["active_objective"] == "prioritize_dominant"
    assert trace["active_objective_label"] == "Help Busy Roads Without Ignoring Others"
    assert "Custom" in trace["active_dataset_or_scenario"]

    timings = trace["final_timings"]
    # NS corridor has 5700 vph vs EW 900 vph, so NS green must be significantly higher
    assert timings["phases"]["NS"] > timings["phases"]["EW"] + 15.0
    # Yellow and all-red must match custom constraints (3.5s and 1.5s)
    assert timings["yellow_seconds"] == 3.5
    assert timings["all_red_seconds"] == 1.5
    assert timings["lost_time_total_seconds"] == 10.0  # 2 * (3.5 + 1.5)


def test_prompt_execute_all_four_objectives():
    """Verifies that /prompt/execute works for all 4 beginner-friendly goals and returns friendly narratives."""
    goals = [
        ("minimize_waiting_time", "Reduce Average Waiting Time"),
        ("prioritize_dominant", "Help Busy Roads Without Ignoring Others"),
        ("maximize_throughput", "Move More Vehicles, Reduce Queues"),
        ("prevent_starvation", "Prevent Long Waits on Less-Busy Roads")
    ]

    fast_scen = {
        "scenario_type": "custom",
        "duration_seconds": 45,
        "seed": 101
    }

    for key, expected_label in goals:
        resp = client.post("/prompt/execute", json={
            "objective": key,
            "scenario": fast_scen,
            "use_active_dataset": False
        })
        assert resp.status_code == 200
        data = resp.json()

        assert data["objective_selected"] == expected_label
        assert expected_label in data["executive_narrative"]
        assert data["pipeline_trace"]["active_objective"] == key
        assert data["pipeline_trace"]["active_objective_label"] == expected_label


