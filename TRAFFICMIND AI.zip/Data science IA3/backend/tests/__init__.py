"""Tests package for TrafficMind AI backend"""
