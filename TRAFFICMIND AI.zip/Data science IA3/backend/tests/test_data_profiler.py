"""
Automated tests for DataProfiler and DynamicPromptCompiler
"""

import pandas as pd
from backend.data_generator import generate_benchmark_scenarios, generate_synthetic_traffic_dataset
from backend.data_profiler import DataProfiler
from backend.prompt_compiler import DynamicPromptCompiler
from backend.schemas import SignalTimingConstraints


def test_data_profiler_normal_dataset():
    presets = generate_benchmark_scenarios()
    df = generate_synthetic_traffic_dataset(presets["normal"])
    profiler = DataProfiler(dataset_name="normal_test")
    profile = profiler.profile_dataframe(df)

    assert profile.total_records == len(df)
    assert profile.imbalance_ratio >= 1.0
    assert profile.quality_score_pct == 100.0
    assert profile.detected_traffic_pattern in ["balanced_normal", "rush_hour_congested"]


def test_data_profiler_asymmetric_dataset():
    presets = generate_benchmark_scenarios()
    df = generate_synthetic_traffic_dataset(presets["asymmetric"])
    profiler = DataProfiler(dataset_name="asymm_test")
    profile = profiler.profile_dataframe(df)

    # NB/SB demand should be significantly higher than EB/WB
    assert profile.imbalance_ratio > 2.0
    assert profile.detected_traffic_pattern == "extreme_asymmetric"
    assert profile.dominant_approach in ["NB", "SB"]


def test_data_profiler_noisy_dataset():
    presets = generate_benchmark_scenarios()
    df = generate_synthetic_traffic_dataset(presets["rush_hour"], inject_anomalies=True)
    profiler = DataProfiler(dataset_name="noisy_test")
    profile = profiler.profile_dataframe(df)

    # Should detect missing values / outliers and lower quality score
    assert len(profile.issues) > 0
    assert profile.quality_score_pct < 100.0


def test_prompt_compiler_structure():
    presets = generate_benchmark_scenarios()
    df = generate_synthetic_traffic_dataset(presets["asymmetric"])
    profiler = DataProfiler(dataset_name="asymm_test")
    profile = profiler.profile_dataframe(df)

    constraints = SignalTimingConstraints(min_green_seconds=10.0, max_green_seconds=80.0)
    compiler = DynamicPromptCompiler(constraints)
    prompt_spec = compiler.compile_prompt(profile)

    assert prompt_spec.prompt_id.startswith("prompt_")
    assert "extreme_asymmetric" in prompt_spec.compiled_prompt_text.lower()
    assert len(prompt_spec.candidate_methods) >= 1
    assert "Minimum Green Time" in prompt_spec.compiled_prompt_text
    assert len(prompt_spec.verification_checks) >= 4
