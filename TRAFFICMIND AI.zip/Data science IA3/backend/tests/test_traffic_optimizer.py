"""
Automated tests for TrafficOptimizer algorithms
"""

import pytest
from backend.traffic_optimizer import TrafficOptimizer
from backend.schemas import SignalTimingConstraints


def test_fixed_baseline_optimizer():
    optimizer = TrafficOptimizer()
    plan = optimizer.optimize_fixed_baseline(cycle_length=60.0)

    assert plan.cycle_length_seconds == 60.0
    assert plan.phases["NS"] == plan.phases["EW"]
    assert abs(plan.phases["NS"] + plan.phases["EW"] + plan.lost_time_total_seconds - plan.cycle_length_seconds) < 1e-4


def test_webster_optimizer():
    constraints = SignalTimingConstraints(min_green_seconds=10.0, max_green_seconds=80.0)
    optimizer = TrafficOptimizer(constraints)
    demands = {"NB": 800.0, "SB": 750.0, "EB": 250.0, "WB": 200.0}

    plan = optimizer.optimize_webster(demands)

    assert plan.phases["NS"] > plan.phases["EW"]  # Higher demand corridor receives more green
    assert plan.phases["EW"] >= constraints.min_green_seconds
    assert plan.phases["NS"] <= constraints.max_green_seconds
    # Cycle conservation
    assert abs(plan.phases["NS"] + plan.phases["EW"] + plan.lost_time_total_seconds - plan.cycle_length_seconds) < 0.2


def test_scipy_slsqp_optimizer():
    constraints = SignalTimingConstraints(min_green_seconds=10.0, max_green_seconds=80.0)
    optimizer = TrafficOptimizer(constraints)
    demands = {"NB": 900.0, "SB": 850.0, "EB": 200.0, "WB": 150.0}

    plan = optimizer.optimize_scipy_slsqp(demands, queues={"NB": 15, "SB": 12, "EB": 3, "WB": 2})

    assert plan.phases["NS"] > plan.phases["EW"]
    assert plan.phases["EW"] >= constraints.min_green_seconds
    assert plan.phases["NS"] <= constraints.max_green_seconds
    assert abs(plan.phases["NS"] + plan.phases["EW"] + plan.lost_time_total_seconds - plan.cycle_length_seconds) < 0.2


def test_four_analytical_objectives():
    """Verifies that all 4 analytical goals execute properly and respect bounds."""
    optimizer = TrafficOptimizer()
    demands = {"NB": 900.0, "SB": 800.0, "EB": 200.0, "WB": 150.0}
    queues = {"NB": 16, "SB": 14, "EB": 4, "WB": 3}

    goals = [
        "minimize_waiting_time",
        "prioritize_dominant",
        "maximize_throughput",
        "prevent_starvation"
    ]
    plans = {}
    for goal in goals:
        plan = optimizer.optimize_scipy_slsqp(
            demands,
            queues=queues,
            hyperparameters={"objective_config": {"primary_objective": goal}}
        )
        assert plan.phases["NS"] >= 10.0
        assert plan.phases["EW"] >= 10.0
        assert abs(plan.phases["NS"] + plan.phases["EW"] + plan.lost_time_total_seconds - plan.cycle_length_seconds) < 0.2
        plans[goal] = plan

    # Prioritize dominant gives strong green to NS corridor
    assert plans["prioritize_dominant"].phases["NS"] > plans["prevent_starvation"].phases["NS"]
    # Prevent starvation allocates more green to minor EW corridor than prioritize_dominant
    assert plans["prevent_starvation"].phases["EW"] > plans["prioritize_dominant"].phases["EW"]
    # Maximize throughput pushes for a larger cycle length to maximize green ratio
    assert plans["maximize_throughput"].cycle_length_seconds >= plans["minimize_waiting_time"].cycle_length_seconds


def test_parameter_reactivity_changes_timings():
    """Verifies that changing approach arrival rates noticeably alters the signal plan."""
    optimizer = TrafficOptimizer()
    low_demands = {"NB": 200.0, "SB": 200.0, "EB": 200.0, "WB": 200.0}
    high_ns_demands = {"NB": 1200.0, "SB": 1000.0, "EB": 150.0, "WB": 150.0}

    plan_balanced = optimizer.optimize_scipy_slsqp(low_demands)
    plan_heavy_ns = optimizer.optimize_scipy_slsqp(high_ns_demands)

    # In balanced traffic, NS and EW splits are near equal
    assert abs(plan_balanced.phases["NS"] - plan_balanced.phases["EW"]) < 6.0
    # In heavy NS traffic, NS split is significantly larger than EW split
    assert plan_heavy_ns.phases["NS"] > plan_heavy_ns.phases["EW"] + 15.0


def test_custom_constraints_enforcement():
    """Verifies that custom min green, max green, yellow, and all-red constraints are strictly enforced."""
    custom_constraints = SignalTimingConstraints(
        min_green_seconds=18.0,
        max_green_seconds=50.0,
        yellow_seconds=4.0,
        all_red_seconds=2.0
    )
    optimizer = TrafficOptimizer()
    demands = {"NB": 1400.0, "SB": 1200.0, "EB": 100.0, "WB": 100.0}

    plan = optimizer.optimize_scipy_slsqp(
        demands,
        constraints=custom_constraints
    )

    expected_lost = 2.0 * (custom_constraints.yellow_seconds + custom_constraints.all_red_seconds)  # 12.0s
    assert plan.yellow_seconds == 4.0
    assert plan.all_red_seconds == 2.0
    assert plan.lost_time_total_seconds == expected_lost
    assert plan.phases["EW"] >= 18.0
    assert plan.phases["NS"] <= 50.0
    assert abs(plan.phases["NS"] + plan.phases["EW"] + expected_lost - plan.cycle_length_seconds) < 0.2
