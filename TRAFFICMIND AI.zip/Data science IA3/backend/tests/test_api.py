"""
Automated tests for FastAPI endpoints
"""

from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "version" in data


def test_scenario_presets_endpoint():
    response = client.get("/scenarios/presets")
    assert response.status_code == 200
    data = response.json()
    assert "rush_hour" in data
    assert "asymmetric" in data


def test_generate_data_endpoint():
    response = client.post("/data/generate")
    assert response.status_code == 200
    data = response.json()
    assert data["total_records"] > 0
    assert len(data["data_sample"]) > 0


def test_data_profile_endpoint():
    response = client.post("/data/profile")
    assert response.status_code == 200
    data = response.json()
    assert "total_records" in data
    assert "imbalance_ratio" in data
    assert "quality_score_pct" in data


def test_pipeline_run_endpoint():
    # Run full automated pipeline on default scenario
    response = client.post("/pipeline/run")
    assert response.status_code == 200
    trace = response.json()
    assert "run_id" in trace
    assert trace["final_status"] in ["OPTIMAL_VERIFIED", "SUBOPTIMAL_VERIFIED"]
    assert "waiting_time_improvement_pct" in trace

    run_id = trace["run_id"]

    # Test retrieval endpoints
    trace_resp = client.get(f"/analysis/{run_id}")
    assert trace_resp.status_code == 200
    assert trace_resp.json()["run_id"] == run_id

    report_resp = client.get(f"/reports/{run_id}")
    assert report_resp.status_code == 200
    assert "TrafficMind AI" in report_resp.text
