"""
TrafficMind AI - Automated Tests for Automated Data Science Platform
Tests:
1. Automated data cleaning & preprocessing (DataPreprocessor).
2. Missing value imputation and sensor spike winsorizing/capping.
3. Feature engineering (rolling flow, saturation ratio, cumulative arrivals).
4. Metric calculation inspector (exact formulas and arithmetic).
5. API endpoints: /data/upload_and_preprocess, /data/active, /data/reset_to_synthetic, /prompt/execute, /metrics/inspect_calculation.
"""

import io
import pandas as pd
import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.data_preprocessor import DataPreprocessor
from backend.metric_inspector import MetricInspector
from backend.schemas import TrafficScenarioConfig

client = TestClient(app)


def test_data_preprocessor_cleans_dirty_data():
    """Verifies that DataPreprocessor handles missing values, sensor spikes, and non-standard schema."""
    raw_df = pd.DataFrame({
        "time": [0, 1, 2, 3, 4, 5],
        "direction": ["north", "south", "east", "west", "N", "S"],
        "volume": [3, None, -2, 50, 4, 2],  # Contains None, negative, and extreme spike (50)
        "other_metric": [10.5, None, 12.0, 11.0, 9.8, 10.0]
    })

    clean_df, report = DataPreprocessor.clean_and_preprocess(raw_df, dataset_name="dirty_sensor_log.csv")

    assert report.raw_records_count == 6
    assert report.cleaned_records_count == 6
    assert "timestamp_sec" in clean_df.columns
    assert "approach" in clean_df.columns
    assert "arrival_count" in clean_df.columns

    # Check that approaches are normalized
    assert set(clean_df["approach"].unique()).issubset({"NB", "SB", "EB", "WB"})

    # Check missing values imputed
    assert clean_df["arrival_count"].isna().sum() == 0

    # Check non-negative arrivals
    assert (clean_df["arrival_count"] >= 0).all()

    # Check extreme spike capped
    assert (clean_df["arrival_count"] <= 15).all()

    # Check engineered features
    assert "rolling_arrivals_5s" in clean_df.columns
    assert "flow_ratio_y" in clean_df.columns
    assert "cumulative_arrivals" in clean_df.columns
    assert report.post_cleaning_quality_score == 100.0


def test_metric_inspector_calculations():
    """Verifies that MetricInspector returns exact formulas and non-empty arithmetic steps."""
    metrics_to_test = [
        "avg_waiting_time",
        "avg_queue_length",
        "throughput_vph",
        "webster_optimum_cycle",
        "waiting_reduction_pct",
        "data_quality_score"
    ]

    for m in metrics_to_test:
        detail = MetricInspector.inspect_metric(m, trace=None)
        assert detail.metric_key == m
        assert len(detail.formula) > 5
        assert len(detail.calculation_steps) >= 3
        assert len(detail.plain_english_explanation) > 10


def test_api_upload_and_preprocess_endpoint():
    """Tests the /data/upload_and_preprocess API endpoint with a synthetic CSV."""
    csv_content = (
        "sec,leg,vehicles\n"
        "0,north,5\n"
        "0,south,4\n"
        "0,east,2\n"
        "0,west,1\n"
        "1,north,\n"  # missing
        "1,south,3\n"
        "1,east,1\n"
        "1,west,25\n"  # spike
    )
    file_bytes = io.BytesIO(csv_content.encode("utf-8"))

    res = client.post(
        "/data/upload_and_preprocess",
        files={"file": ("empirical_traffic.csv", file_bytes, "text/csv")}
    )
    assert res.status_code == 200
    data = res.json()
    assert data["filename"] == "empirical_traffic.csv"
    assert "preprocessing_report" in data
    assert data["preprocessing_report"]["cleaned_records_count"] == 8
    assert data["data_profile"]["quality_score_pct"] == 100.0

    # Verify /data/active reports uploaded dataset
    res_active = client.get("/data/active")
    assert res_active.status_code == 200
    active_data = res_active.json()
    assert active_data["is_uploaded"] is True
    assert active_data["dataset_name"] == "empirical_traffic.csv"

    # Reset back to synthetic
    res_reset = client.post("/data/reset_to_synthetic")
    assert res_reset.status_code == 200
    assert res_reset.json()["status"] == "success"


def test_api_prompt_execute_endpoint():
    """Tests that /prompt/execute translates goal into prompt, plan, simulation, and narrative."""
    payload = {
        "objective": "prioritize_dominant",
        "scenario": {
            "scenario_id": "test_prompt_exec",
            "scenario_type": "asymmetric",
            "duration_seconds": 60,
            "seed": 42
        },
        "use_active_dataset": False
    }

    res = client.post("/prompt/execute", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert data["objective_selected"] == "prioritize_dominant"
    assert "compiled_prompt" in data
    assert "selected_method" in data
    assert "pipeline_trace" in data
    assert len(data["executive_narrative"]) > 20
    assert data["pipeline_trace"]["final_status"] in ["OPTIMAL_VERIFIED", "SUBOPTIMAL_VERIFIED"]


def test_api_metrics_inspect_calculation_endpoint():
    """Tests the /metrics/inspect_calculation endpoint."""
    res = client.post("/metrics/inspect_calculation?metric_key=avg_waiting_time")
    assert res.status_code == 200
    data = res.json()
    assert data["metric_key"] == "avg_waiting_time"
    assert "Total Cumulative Delay" in data["formula"]
    assert len(data["calculation_steps"]) >= 3


def test_api_datasets_and_selection_reactivity():
    """Tests /data/datasets and /data/select_dataset endpoints and reactive updates."""
    # 1. List catalog
    res_list = client.get("/data/datasets")
    assert res_list.status_code == 200
    catalog = res_list.json()
    assert len(catalog) >= 5
    ids = [d["id"] for d in catalog]
    assert "clean_baseline" in ids
    assert "missing_values" in ids
    assert "sensor_anomalies" in ids
    assert "duplicate_records" in ids
    assert "mixed_quality" in ids

    # 2. Select missing_values dataset
    res_sel = client.post("/data/select_dataset", json={"dataset_id": "missing_values"})
    assert res_sel.status_code == 200
    sel_data = res_sel.json()
    assert sel_data["status"] == "success"
    assert sel_data["dataset_id"] == "missing_values"
    prep = sel_data["preprocessing_report"]
    assert prep["initial_quality_score"] < 100.0
    assert prep["post_cleaning_quality_score"] >= prep["initial_quality_score"]
    assert sum(prep["missing_values_imputed"].values()) > 0

    # 3. Check /data/active
    res_act = client.get("/data/active")
    assert res_act.status_code == 200
    act = res_act.json()
    assert act["dataset_id"] == "missing_values"
    assert act["total_records"] > 0

    # 4. Select sensor_anomalies
    res_anom = client.post("/data/select_dataset", json={"dataset_id": "sensor_anomalies"})
    assert res_anom.status_code == 200
    anom_prep = res_anom.json()["preprocessing_report"]
    assert sum(anom_prep["outliers_handled"].values()) > 0

    # 5. Reset back to clean baseline
    res_reset = client.post("/data/reset_to_synthetic")
    assert res_reset.status_code == 200


def test_data_drift_detection():
    """Verifies KS test and Wasserstein distance regime drift detection."""
    from backend.data_profiler import DataProfiler

    # Identical data should show no drift
    df1 = pd.DataFrame({
        "timestamp_sec": list(range(100)),
        "approach": ["NB"] * 50 + ["SB"] * 50,
        "arrival_count": [1] * 100
    })
    res_stable = DataProfiler.detect_data_drift(df1, baseline_df=df1)
    assert res_stable["drift_detected"] is False
    assert res_stable["ks_statistic"] == 0.0
    assert res_stable["p_value"] == 1.0

    # Drastically shifted data should flag drift
    df_shifted = pd.DataFrame({
        "timestamp_sec": list(range(100)),
        "approach": ["NB"] * 50 + ["SB"] * 50,
        "arrival_count": [10] * 100
    })
    res_drift = DataProfiler.detect_data_drift(df_shifted, baseline_df=df1)
    assert res_drift["drift_detected"] is True
    assert res_drift["p_value"] < 0.05
    assert res_drift["wasserstein_distance"] > 1.0


def test_api_auto_analyze_endpoint():
    """Tests POST /data/auto_analyze Self-Driving Data Science Pipeline."""
    res = client.post("/data/auto_analyze")
    assert res.status_code == 200
    data = res.json()
    assert "dataset_name" in data
    assert "dataset_quality_score" in data
    assert "drift_detected" in data
    assert "compiled_prompt" in data
    assert "analysis_plan" in data
    assert "pipeline_trace" in data
    assert "ml_evaluation" in data
    assert len(data["executive_narrative"]) > 20
    assert data["pipeline_trace"]["final_status"] in ["OPTIMAL_VERIFIED", "SUBOPTIMAL_VERIFIED"]
    assert data["ml_evaluation"]["linear_regression"]["r2"] >= -1.0
    assert data["ml_evaluation"]["linear_regression"]["prediction_interval_95_width"] > 0


def test_clean_baseline_reports_zero_cleaning():
    """Verifies that clean baseline data reports 0 cleaning needed and 100% quality."""
    clean_df = pd.DataFrame({
        "timestamp_sec": [0, 0, 0, 0, 1, 1, 1, 1],
        "approach": ["NB", "SB", "EB", "WB", "NB", "SB", "EB", "WB"],
        "arrival_count": [1, 2, 0, 1, 1, 0, 1, 2],
        "queue_length": [3, 2, 1, 1, 2, 2, 1, 1],
        "saturation_flow_vph": [1800.0] * 8,
        "active_phase": ["NS_GREEN", "NS_GREEN", "EW_RED", "EW_RED", "NS_GREEN", "NS_GREEN", "EW_RED", "EW_RED"]
    })
    processed, rep = DataPreprocessor.clean_and_preprocess(clean_df, dataset_name="Clean Baseline Test")
    assert rep.initial_quality_score == 100.0
    assert rep.post_cleaning_quality_score == 100.0
    assert rep.duplicates_dropped_count == 0
    assert sum(rep.missing_values_imputed.values()) == 0
    assert sum(rep.outliers_handled.values()) == 0
    assert "No data cleaning operations were required" in rep.cleaning_steps[0]


def test_ml_uncertainty_prediction_intervals():
    """Verifies that Ridge regression calculates 95% uncertainty interval and coverage."""
    from backend.ml_models import TrafficMLEngine
    df = pd.DataFrame({
        "timestamp_sec": list(range(200)),
        "approach": (["NB", "SB", "EB", "WB"] * 50),
        "arrival_count": [1, 2, 0, 1] * 50,
        "queue_length": [2, 3, 1, 1] * 50,
        "waiting_time_sec": [12.0, 15.0, 8.0, 7.0] * 50
    })
    res = TrafficMLEngine.train_and_evaluate(df, dataset_name="Uncertainty Test")
    lr = res.linear_regression
    assert lr.prediction_interval_95_width > 0.0
    assert 0.0 <= lr.coverage_95_pct <= 100.0
    assert len(lr.sample_predictions) > 0
    assert "ci_lower_95" in lr.sample_predictions[0]
    assert "ci_upper_95" in lr.sample_predictions[0]


def test_graph_synchronization_and_refresh_across_datasets():
    """
    Phase 5 Test: Verifies that changing datasets causes real data science graphs
    to recompute and reflect the active dataset's empirical properties.
    Ensures Graphs 1-4 track authoritative simulation run and Graphs 5-6 track ML evaluation.
    """
    # 1. Select clean baseline
    res_b = client.post("/data/select_dataset", json={"dataset_id": "clean_baseline"})
    assert res_b.status_code == 200
    res_graph_b = client.post("/analytics/graphs", json={"force_new_simulation": True})
    assert res_graph_b.status_code == 200
    graph_b = res_graph_b.json()

    # Verify attribution IDs exist
    assert "simulation_run_id" in graph_b
    assert "ml_evaluation_id" in graph_b
    assert graph_b["dataset_id"] == "clean_baseline"

    wait_b = graph_b["graphs"]["fixed_vs_adaptive"]["values"]
    sim_id_b = graph_b["simulation_run_id"]
    ml_id_b = graph_b["ml_evaluation_id"]

    # 2. Select mixed quality dataset (anomalies, different flow rates)
    res_m = client.post("/data/select_dataset", json={"dataset_id": "mixed_quality"})
    assert res_m.status_code == 200
    res_graph_m = client.post("/analytics/graphs", json={"force_new_simulation": True})
    assert res_graph_m.status_code == 200
    graph_m = res_graph_m.json()

    assert graph_m["dataset_id"] == "mixed_quality"
    sim_id_m = graph_m["simulation_run_id"]
    ml_id_m = graph_m["ml_evaluation_id"]

    # IDs must be fresh and traceable
    assert sim_id_b != sim_id_m
    assert ml_id_b != ml_id_m

    # Graph 1 waiting values must reflect the different dataset flow demands
    wait_m = graph_m["graphs"]["fixed_vs_adaptive"]["values"]
    assert wait_b != wait_m, f"Expected graph values to differ between clean_baseline and mixed_quality, got {wait_b} vs {wait_m}"

    # Verify internal graph structures have their source attributes
    assert graph_m["graphs"]["fixed_vs_adaptive"]["simulation_run_id"] == sim_id_m
    assert graph_m["graphs"]["actual_vs_predicted"]["ml_evaluation_id"] == ml_id_m


def test_ml_metric_single_source_of_truth_consistency():
    """
    Phase 5 Test: Verifies that ML cards, tables, graphs, and executive narrative
    all report bit-for-bit identical metrics derived from the same authoritative evaluation object.
    Guarantees hardcoded defaults (0.850, 3.20s) never contradict genuine card metrics.
    """
    # 1. Trigger ML evaluation on active session
    res_eval = client.post("/ml/train_and_evaluate")
    assert res_eval.status_code == 200
    eval_data = res_eval.json()

    r2_card = eval_data["linear_regression"]["r2"]
    mae_card = eval_data["linear_regression"]["mae"]
    eval_id = eval_data["evaluation_id"]
    total_test = eval_data["test_sample_count"]

    assert total_test > 0
    assert eval_id.startswith("eval_")

    # 2. Request narrative with empty context_data (should use authoritative active ML evaluation)
    res_narrative = client.post("/llm/generate_insights", json={"goal_type": "ml", "context_data": {}})
    assert res_narrative.status_code == 200
    narrative_resp = res_narrative.json()
    narrative_text = narrative_resp["narrative"]

    # Narrative must reference the exact evaluation ID and exact card metrics
    assert f"{r2_card:.3f}" in narrative_text, f"Expected R² {r2_card:.3f} in narrative, got: {narrative_text}"
    assert f"{mae_card:.2f}" in narrative_text, f"Expected MAE {mae_card:.2f} in narrative, got: {narrative_text}"
    assert eval_id in narrative_text, f"Expected eval_id {eval_id} in narrative, got: {narrative_text}"

    # 3. Request narrative with explicit evaluation object (frontend pass-through)
    res_explicit = client.post("/llm/generate_insights", json={"goal_type": "ml", "context_data": eval_data})
    assert res_explicit.status_code == 200
    explicit_text = res_explicit.json()["narrative"]
    assert f"{r2_card:.3f}" in explicit_text
    assert f"{mae_card:.2f}" in explicit_text
    assert eval_id in explicit_text


