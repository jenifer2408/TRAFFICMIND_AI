"""
Automated tests for ValidationEngine and SelfCorrectingPipeline
"""

from backend.schemas import SignalTimingConstraints, SignalTimingPlan, SimulationResult
from backend.validation_engine import ValidationEngine
from backend.data_generator import generate_benchmark_scenarios
from backend.traffic_optimizer import TrafficOptimizer
from backend.traffic_simulator import TrafficSimulator
from backend.correction_loop import SelfCorrectingPipeline
from backend.analysis_planner import AnalysisPlanner
from backend.data_profiler import DataProfiler


def test_validation_engine_catches_min_green_violation():
    constraints = SignalTimingConstraints(min_green_seconds=15.0)
    validator = ValidationEngine(constraints)

    # Violating timing plan: green time 8s < min 15s
    bad_plan = SignalTimingPlan(
        cycle_length_seconds=60.0,
        phases={"NS": 44.0, "EW": 8.0},
        yellow_seconds=3.0,
        all_red_seconds=1.0,
        lost_time_total_seconds=8.0
    )

    scenario = generate_benchmark_scenarios()["rush_hour"]
    scenario.duration_seconds = 60
    sim = TrafficSimulator(scenario)
    sim_res = sim.run_simulation(bad_plan)

    validation = validator.validate_timings_and_simulation(bad_plan, sim_res)
    assert not validation.is_valid
    assert validation.failure_category == "CONSTRAINT_VIOLATION_MIN_GREEN"


def test_validation_engine_catches_cycle_sum_violation():
    constraints = SignalTimingConstraints()
    validator = ValidationEngine(constraints)

    # Inconsistent cycle: sum of phases (30 + 30) + lost (8) = 68, but cycle claims 90
    inconsistent_plan = SignalTimingPlan(
        cycle_length_seconds=90.0,
        phases={"NS": 30.0, "EW": 30.0},
        yellow_seconds=3.0,
        all_red_seconds=1.0,
        lost_time_total_seconds=8.0
    )

    scenario = generate_benchmark_scenarios()["rush_hour"]
    scenario.duration_seconds = 60
    sim = TrafficSimulator(scenario)
    sim_res = sim.run_simulation(inconsistent_plan)

    validation = validator.validate_timings_and_simulation(inconsistent_plan, sim_res)
    assert not validation.is_valid
    assert validation.failure_category == "CONSTRAINT_VIOLATION_CYCLE_SUM"


def test_self_correcting_pipeline_end_to_end():
    scenario = generate_benchmark_scenarios()["asymmetric"]
    scenario.duration_seconds = 120

    planner = AnalysisPlanner()
    pipeline = SelfCorrectingPipeline(max_retries=3)

    # Create synthetic observation data and plan
    profiler = DataProfiler("test_asymm")
    from backend.data_generator import generate_synthetic_traffic_dataset
    df = generate_synthetic_traffic_dataset(scenario)
    profile = profiler.profile_dataframe(df)

    compiler_out = planner.compiler.compile_prompt(profile)
    plan, tokens, mode = planner.llm_service.plan_analysis(compiler_out)

    trace = pipeline.execute_pipeline(
        scenario=scenario,
        data_profile=profile,
        dynamic_prompt=compiler_out,
        analysis_plan=plan
    )

    assert trace.final_status in ["OPTIMAL_VERIFIED", "SUBOPTIMAL_VERIFIED"]
    assert trace.waiting_time_improvement_pct >= 0.0
    assert len(trace.attempts) >= 1
