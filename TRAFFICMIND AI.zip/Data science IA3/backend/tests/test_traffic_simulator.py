"""
Automated tests for TrafficSimulator
"""

from backend.data_generator import generate_benchmark_scenarios
from backend.traffic_optimizer import TrafficOptimizer
from backend.traffic_simulator import TrafficSimulator


def test_simulator_execution():
    scenario = generate_benchmark_scenarios()["rush_hour"]
    scenario.duration_seconds = 60  # Short test duration

    optimizer = TrafficOptimizer()
    plan = optimizer.optimize_fixed_baseline(60.0)

    simulator = TrafficSimulator(scenario)
    res = simulator.run_simulation(plan, controller_name="Test Fixed Controller")

    assert res.total_vehicles_arrived > 0
    assert res.total_vehicles_served > 0
    assert res.avg_waiting_time_sec >= 0.0
    assert res.throughput_vph > 0.0
    assert "NB" in res.approach_metrics
    assert "EB" in res.approach_metrics
    assert len(res.time_series_sample) > 0


def test_adaptive_improves_asymmetric_over_fixed():
    scenario = generate_benchmark_scenarios()["asymmetric"]
    scenario.duration_seconds = 180

    optimizer = TrafficOptimizer()
    fixed_plan = optimizer.optimize_fixed_baseline(60.0)
    adaptive_plan = optimizer.optimize_webster({
        app: cfg.arrival_rate_vph for app, cfg in scenario.approaches.items()
    })

    sim = TrafficSimulator(scenario)
    fixed_res = sim.run_simulation(fixed_plan, controller_name="Fixed")
    adapt_res = sim.run_simulation(adaptive_plan, controller_name="Adaptive")

    # Adaptive green allocation should achieve lower or equal average waiting time than fixed equal split
    assert adapt_res.avg_waiting_time_sec <= fixed_res.avg_waiting_time_sec
