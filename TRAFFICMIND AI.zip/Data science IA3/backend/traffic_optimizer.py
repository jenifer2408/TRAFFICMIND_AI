"""
TrafficMind AI - Adaptive Signal Optimization Algorithms
Implements:
1. Fixed-time baseline controller.
2. Demand-weighted Webster flow-ratio optimizer.
3. Constrained non-linear SciPy SLSQP delay minimization optimizer.
"""

import time
import numpy as np
from scipy.optimize import minimize
from typing import Dict, Tuple, Optional, Any
from .schemas import SignalTimingConstraints, SignalTimingPlan


class TrafficOptimizer:
    """
    Traffic signal timing optimizer implementing multiple analytical and numerical strategies.
    """

    def __init__(self, constraints: Optional[SignalTimingConstraints] = None):
        self.constraints = constraints or SignalTimingConstraints()

    def get_lost_time(self) -> float:
        """Total lost time for 2-phase dual ring (2 transitions)."""
        return 2.0 * (self.constraints.yellow_seconds + self.constraints.all_red_seconds)

    def optimize_fixed_baseline(
        self,
        cycle_length: float = 60.0,
        constraints: Optional[SignalTimingConstraints] = None
    ) -> SignalTimingPlan:
        """Fixed-time signal control baseline (equal 50/50 green splits)."""
        active_constraints = constraints or self.constraints
        lost_time = 2.0 * (active_constraints.yellow_seconds + active_constraints.all_red_seconds)
        usable_green = max(2.0 * active_constraints.min_green_seconds, cycle_length - lost_time)
        g_ns = usable_green / 2.0
        g_ew = usable_green / 2.0

        return SignalTimingPlan(
            cycle_length_seconds=float(cycle_length),
            phases={"NS": float(g_ns), "EW": float(g_ew)},
            yellow_seconds=active_constraints.yellow_seconds,
            all_red_seconds=active_constraints.all_red_seconds,
            lost_time_total_seconds=lost_time,
            degree_of_saturation={"NS": 0.5, "EW": 0.5},
            optimization_method="fixed_baseline",
            computation_time_ms=0.1
        )

    def optimize_webster(
        self,
        approach_demands_vph: Dict[str, float],
        saturation_flow_vph: float = 1800.0,
        constraints: Optional[SignalTimingConstraints] = None
    ) -> SignalTimingPlan:
        """
        Calculates optimal cycle length and green splits via Webster's formula.
        Flow ratio y = q / s.
        Optimal Cycle C* = (1.5 * L + 5) / (1 - Y)
        """
        start_t = time.perf_counter()
        active_constraints = constraints or self.constraints
        lost_time = 2.0 * (active_constraints.yellow_seconds + active_constraints.all_red_seconds)

        # Phase critical flows
        q_ns = max(approach_demands_vph.get("NB", 0.0), approach_demands_vph.get("SB", 0.0), 10.0)
        q_ew = max(approach_demands_vph.get("EB", 0.0), approach_demands_vph.get("WB", 0.0), 10.0)

        y_ns = q_ns / saturation_flow_vph
        y_ew = q_ew / saturation_flow_vph
        y_total = min(0.92, y_ns + y_ew)

        # Webster formula
        c_opt = (1.5 * lost_time + 5.0) / (1.0 - y_total)
        c_clamped = float(np.clip(c_opt, active_constraints.min_cycle_seconds, active_constraints.max_cycle_seconds))

        usable_green = c_clamped - lost_time
        split_ns = y_ns / y_total
        split_ew = y_ew / y_total

        g_ns = usable_green * split_ns
        g_ew = usable_green * split_ew

        # Enforce min/max green constraints and cycle conservation
        g_ns = float(np.clip(g_ns, active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        g_ew = float(np.clip(g_ew, active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        c_clamped = float(g_ns + g_ew + lost_time)

        x_ns = (q_ns * c_clamped) / (saturation_flow_vph * max(1.0, g_ns))
        x_ew = (q_ew * c_clamped) / (saturation_flow_vph * max(1.0, g_ew))

        comp_ms = (time.perf_counter() - start_t) * 1000.0

        return SignalTimingPlan(
            cycle_length_seconds=round(c_clamped, 2),
            phases={"NS": round(g_ns, 2), "EW": round(g_ew, 2)},
            yellow_seconds=active_constraints.yellow_seconds,
            all_red_seconds=active_constraints.all_red_seconds,
            lost_time_total_seconds=lost_time,
            degree_of_saturation={"NS": round(float(x_ns), 3), "EW": round(float(x_ew), 3)},
            optimization_method="webster_flow_ratio",
            computation_time_ms=round(comp_ms, 2)
        )

    def optimize_scipy_slsqp(
        self,
        approach_demands_vph: Dict[str, float],
        queues: Optional[Dict[str, int]] = None,
        saturation_flow_vph: float = 1800.0,
        hyperparameters: Optional[Dict[str, Any]] = None,
        remedial_adjustments: Optional[Dict[str, Any]] = None,
        constraints: Optional[SignalTimingConstraints] = None
    ) -> SignalTimingPlan:
        """
        Constrained non-linear optimization using SciPy SLSQP.
        Implements 4 distinct analytical objectives:
        1. Reduce Average Waiting Time (minimize_waiting_time)
        2. Help Busy Roads Without Ignoring Others (prioritize_dominant / help_busy_roads)
        3. Move More Vehicles, Reduce Queues (maximize_throughput / move_more_vehicles)
        4. Prevent Long Waits on Less-Busy Roads (prevent_starvation / prevent_long_waits)
        Strictly enforces min/max green bounds, clearance intervals, and cycle conservation.
        """
        start_t = time.perf_counter()
        active_constraints = constraints or self.constraints
        lost_time = 2.0 * (active_constraints.yellow_seconds + active_constraints.all_red_seconds)
        params = hyperparameters or {}
        remedies = remedial_adjustments or {}

        # Read objective configuration and goal
        obj_cfg = params.get("objective_config") or {}
        primary_obj = (
            obj_cfg.get("primary_objective")
            or params.get("primary_objective")
            or "minimize_waiting_time"
        )
        if primary_obj in ["help_busy_roads", "prioritize_dominant"]:
            goal = "prioritize_dominant"
        elif primary_obj in ["move_more_vehicles", "maximize_throughput", "minimize_queue_length"]:
            goal = "maximize_throughput"
        elif primary_obj in ["prevent_long_waits", "prevent_starvation"]:
            goal = "prevent_starvation"
        else:
            goal = "minimize_waiting_time"

        # Configurable optimization weights
        w_delay = float(obj_cfg.get("weight_waiting_time", params.get("delay_weight", 1.0))) * remedies.get("delay_weight_mult", 1.0)
        w_queue = float(obj_cfg.get("weight_queue_length", params.get("queue_weight", 1.4))) * remedies.get("queue_weight_mult", 1.0)
        w_thru = float(obj_cfg.get("weight_throughput", 0.5))
        w_sat = float(params.get("saturation_penalty_weight", 2.5))

        q_ns = max(approach_demands_vph.get("NB", 0.0), approach_demands_vph.get("SB", 0.0), 10.0)
        q_ew = max(approach_demands_vph.get("EB", 0.0), approach_demands_vph.get("WB", 0.0), 10.0)

        # Queues
        queues = queues or {}
        queue_ns = max(queues.get("NB", 0), queues.get("SB", 0), 2)
        queue_ew = max(queues.get("EB", 0), queues.get("WB", 0), 2)

        # If a phase was starved in a previous attempt, increase its priority
        starved_phase = remedies.get("boost_phase")
        if starved_phase == "EW":
            queue_ew *= 2.5
        elif starved_phase == "NS":
            queue_ns *= 2.5

        # Decision variables: [g_ns, g_ew, C]
        c_init = float(np.clip(65.0, active_constraints.min_cycle_seconds, active_constraints.max_cycle_seconds))
        usable_init = max(20.0, c_init - lost_time)
        g_ns_init = float(np.clip(usable_init * (q_ns / max(1.0, q_ns + q_ew)), active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        g_ew_init = float(np.clip(usable_init - g_ns_init, active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        c_init = g_ns_init + g_ew_init + lost_time
        x0 = [g_ns_init, g_ew_init, c_init]

        def objective(vars_vec):
            g_1, g_2, c = vars_vec
            c = max(c, active_constraints.min_cycle_seconds)
            g_1 = max(g_1, active_constraints.min_green_seconds)
            g_2 = max(g_2, active_constraints.min_green_seconds)

            lam_ns = g_1 / c
            lam_ew = g_2 / c

            sat_ns = (q_ns / 3600.0) / ((saturation_flow_vph / 3600.0) * max(lam_ns, 0.01))
            sat_ew = (q_ew / 3600.0) / ((saturation_flow_vph / 3600.0) * max(lam_ew, 0.01))

            # Webster delay approximation per corridor
            delay_ns = (c * (1.0 - lam_ns)**2) / (2.0 * (1.0 - min(0.98, lam_ns * sat_ns)))
            delay_ew = (c * (1.0 - lam_ew)**2) / (2.0 * (1.0 - min(0.98, lam_ew * sat_ew)))

            # Queue penalty
            queue_penalty = queue_ns * ((c - g_1) / c) + queue_ew * ((c - g_2) / c)

            # Degree of saturation penalty if > 0.85
            sat_penalty = (max(0.0, sat_ns - 0.85)**2 + max(0.0, sat_ew - 0.85)**2) * 50.0

            # Green ratio
            green_ratio = (g_1 + g_2) / c

            # System volume-weighted average delay
            weighted_delay = (q_ns * delay_ns + q_ew * delay_ew) / max(1.0, q_ns + q_ew)

            if goal == "prioritize_dominant":
                # Goal 2: Help Busy Roads Without Ignoring Others
                # Prioritizes dominant corridor while strictly preventing opposing starvation
                if q_ns >= q_ew:
                    dom_delay = delay_ns
                    minor_delay = delay_ew
                    dom_queue = queue_ns * ((c - g_1) / c)
                    minor_queue = queue_ew * ((c - g_2) / c)
                else:
                    dom_delay = delay_ew
                    minor_delay = delay_ns
                    dom_queue = queue_ew * ((c - g_2) / c)
                    minor_queue = queue_ns * ((c - g_1) / c)

                loss = (
                    2.8 * w_delay * dom_delay +
                    0.8 * w_delay * minor_delay +
                    2.5 * w_queue * dom_queue +
                    0.8 * w_queue * minor_queue +
                    1.2 * max(delay_ns, delay_ew) +
                    w_sat * sat_penalty
                )
            elif goal == "maximize_throughput":
                # Goal 3: Move More Vehicles, Reduce Queues
                # Maximizes green throughput ratio, strongly penalizes standing queues and saturation
                loss = (
                    -50.0 * w_thru * green_ratio +
                    3.0 * w_queue * queue_penalty +
                    0.5 * w_delay * weighted_delay +
                    2.0 * w_sat * sat_penalty
                )
            elif goal == "prevent_starvation":
                # Goal 4: Prevent Long Waits on Less-Busy Roads
                # Heavily penalizes red-time waiting duration on less-busy roads and rewards minor green ratio
                if q_ns <= q_ew:
                    minor_g = g_1
                    dom_g = g_2
                else:
                    minor_g = g_2
                    dom_g = g_1
                minor_red_wait = c - minor_g  # Maximum waiting time on less-busy road
                minor_green_ratio = minor_g / c
                loss = (
                    3.5 * w_delay * minor_red_wait -
                    35.0 * minor_green_ratio +
                    1.5 * abs(delay_ns - delay_ew) +
                    0.5 * w_delay * weighted_delay +
                    w_sat * sat_penalty
                )
            else:
                # Goal 1: Reduce Average Waiting Time (Default)
                loss = (
                    1.5 * w_delay * weighted_delay +
                    0.8 * w_queue * queue_penalty +
                    w_sat * sat_penalty -
                    10.0 * w_thru * green_ratio
                )

            return loss

        # Bounds: [g_min, g_max] for greens, [c_min, c_max] for cycle
        bounds = [
            (active_constraints.min_green_seconds, active_constraints.max_green_seconds),
            (active_constraints.min_green_seconds, active_constraints.max_green_seconds),
            (active_constraints.min_cycle_seconds, active_constraints.max_cycle_seconds)
        ]

        # Equality constraint: g_1 + g_2 + lost_time - c = 0
        constraints_list = [
            {"type": "eq", "fun": lambda v: v[0] + v[1] + lost_time - v[2]}
        ]

        res = minimize(
            objective,
            x0,
            method="SLSQP",
            bounds=bounds,
            constraints=constraints_list,
            options={"maxiter": int(params.get("max_iter", 100)), "ftol": float(params.get("ftol", 1e-4))}
        )

        if res.success:
            g_ns_opt, g_ew_opt, c_opt = res.x
        else:
            # Fallback if optimization struggled
            g_ns_opt, g_ew_opt, c_opt = x0

        # Exact projection onto constraints to guarantee cycle conservation and bounds
        g_ns_opt = float(np.clip(g_ns_opt, active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        g_ew_opt = float(np.clip(g_ew_opt, active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        c_opt = float(g_ns_opt + g_ew_opt + lost_time)

        # Degree of saturation
        sat_ns = (q_ns * c_opt) / (saturation_flow_vph * max(1.0, g_ns_opt))
        sat_ew = (q_ew * c_opt) / (saturation_flow_vph * max(1.0, g_ew_opt))

        comp_ms = (time.perf_counter() - start_t) * 1000.0

        return SignalTimingPlan(
            cycle_length_seconds=round(c_opt, 2),
            phases={"NS": round(g_ns_opt, 2), "EW": round(g_ew_opt, 2)},
            yellow_seconds=active_constraints.yellow_seconds,
            all_red_seconds=active_constraints.all_red_seconds,
            lost_time_total_seconds=lost_time,
            degree_of_saturation={"NS": round(float(sat_ns), 3), "EW": round(float(sat_ew), 3)},
            optimization_method="scipy_slsqp_delay_minimization",
            computation_time_ms=round(comp_ms, 2)
        )

    def optimize_queue_proportional_greedy(
        self,
        approach_demands_vph: Dict[str, float],
        queues: Optional[Dict[str, int]] = None,
        cycle_length: float = 65.0,
        constraints: Optional[SignalTimingConstraints] = None
    ) -> SignalTimingPlan:
        """
        Greedy queue-proportional adaptive controller.
        Allocates usable green time in direct proportion to real-time approach queues.
        """
        start_t = time.perf_counter()
        active_constraints = constraints or self.constraints
        lost_time = 2.0 * (active_constraints.yellow_seconds + active_constraints.all_red_seconds)
        c_clamped = float(np.clip(cycle_length, active_constraints.min_cycle_seconds, active_constraints.max_cycle_seconds))
        usable = c_clamped - lost_time

        queues = queues or {}
        q_ns = max(1, queues.get("NB", 0) + queues.get("SB", 0))
        q_ew = max(1, queues.get("EB", 0) + queues.get("WB", 0))
        total_q = q_ns + q_ew

        g_ns = usable * (q_ns / total_q)
        g_ns = float(np.clip(g_ns, active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        g_ew = float(np.clip(usable - g_ns, active_constraints.min_green_seconds, active_constraints.max_green_seconds))
        c_clamped = float(g_ns + g_ew + lost_time)

        comp_ms = (time.perf_counter() - start_t) * 1000.0
        return SignalTimingPlan(
            cycle_length_seconds=round(c_clamped, 2),
            phases={"NS": round(g_ns, 2), "EW": round(g_ew, 2)},
            yellow_seconds=active_constraints.yellow_seconds,
            all_red_seconds=active_constraints.all_red_seconds,
            lost_time_total_seconds=lost_time,
            degree_of_saturation={"NS": 0.65, "EW": 0.65},
            optimization_method="queue_proportional_greedy",
            computation_time_ms=round(comp_ms, 2)
        )

    def optimize_prediction_informed(
        self,
        approach_demands_vph: Dict[str, float],
        queues: Optional[Dict[str, int]] = None,
        predicted_growth_rate: float = 1.15,
        horizon_seconds: float = 60.0
    ) -> SignalTimingPlan:
        """
        Prediction-Informed Adaptive Controller:
        Integrates ML queue forecasts and upstream arrival velocity to pre-emptively
        expand green splits for corridors before congestion breakdown occurs.
        """
        start_t = time.perf_counter()
        lost_time = self.get_lost_time()
        queues = queues or {}

        # 1. Calculate base critical flows
        q_ns = max(approach_demands_vph.get("NB", 0.0), approach_demands_vph.get("SB", 0.0), 10.0)
        q_ew = max(approach_demands_vph.get("EB", 0.0), approach_demands_vph.get("WB", 0.0), 10.0)
        sat_flow = 1800.0

        # 2. Predictive queue accumulation over lookahead horizon
        curr_q_ns = max(0, queues.get("NB", 0) + queues.get("SB", 0))
        curr_q_ew = max(0, queues.get("EB", 0) + queues.get("WB", 0))

        pred_q_ns = curr_q_ns + (q_ns / 3600.0) * horizon_seconds * predicted_growth_rate
        pred_q_ew = curr_q_ew + (q_ew / 3600.0) * horizon_seconds * predicted_growth_rate
        tot_pred_q = max(1.0, pred_q_ns + pred_q_ew)

        # 3. Dynamic predictive pressure combining flow ratio and queue forecast
        y_ns = q_ns / sat_flow
        y_ew = q_ew / sat_flow
        y_tot = min(0.92, y_ns + y_ew)

        # Pre-emptive dynamic cycle determination
        c_pred = (1.5 * lost_time + 5.0) / (1.0 - y_tot)
        c_clamped = float(np.clip(c_pred, self.constraints.min_cycle_seconds, self.constraints.max_cycle_seconds))
        usable = c_clamped - lost_time

        # Blend flow ratio (60%) and predictive queue pressure (40%)
        weight_flow = 0.60
        weight_pred = 0.40

        ratio_ns = weight_flow * (y_ns / max(0.01, y_tot)) + weight_pred * (pred_q_ns / tot_pred_q)
        ratio_ew = weight_flow * (y_ew / max(0.01, y_tot)) + weight_pred * (pred_q_ew / tot_pred_q)
        tot_ratio = ratio_ns + ratio_ew

        g_ns = usable * (ratio_ns / tot_ratio)
        g_ns = float(np.clip(g_ns, self.constraints.min_green_seconds, self.constraints.max_green_seconds))
        g_ew = float(np.clip(usable - g_ns, self.constraints.min_green_seconds, self.constraints.max_green_seconds))
        c_clamped = float(g_ns + g_ew + lost_time)

        sat_ns = (q_ns * c_clamped) / (sat_flow * max(1.0, g_ns))
        sat_ew = (q_ew * c_clamped) / (sat_flow * max(1.0, g_ew))

        comp_ms = (time.perf_counter() - start_t) * 1000.0
        return SignalTimingPlan(
            cycle_length_seconds=round(c_clamped, 2),
            phases={"NS": round(g_ns, 2), "EW": round(g_ew, 2)},
            yellow_seconds=self.constraints.yellow_seconds,
            all_red_seconds=self.constraints.all_red_seconds,
            lost_time_total_seconds=lost_time,
            degree_of_saturation={"NS": round(float(sat_ns), 3), "EW": round(float(sat_ew), 3)},
            optimization_method="prediction_informed_adaptive",
            computation_time_ms=round(comp_ms, 2)
        )
