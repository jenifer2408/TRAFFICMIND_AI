"""
TrafficMind AI - CLI Pipeline & Benchmark Runner
Enables direct execution of individual scenario pipelines or full multi-scenario benchmarks from the terminal.
Generates comprehensive evaluation tables and technical markdown reports.
"""

import argparse
import json
import os
import pandas as pd
from backend.schemas import TrafficScenarioConfig
from backend.data_generator import generate_benchmark_scenarios, generate_synthetic_traffic_dataset
from backend.analysis_planner import AnalysisPlanner
from backend.traffic_optimizer import TrafficOptimizer
from backend.validation_engine import ValidationEngine
from backend.correction_loop import SelfCorrectingPipeline
from backend.evaluation import TrafficBenchmarkEvaluator
from backend.report_generator import ReportGenerator


def run_single_scenario(scenario_key: str = "rush_hour"):
    print(f"\n=======================================================")
    print(f"  TrafficMind AI - Running Pipeline for: '{scenario_key.upper()}'")
    print(f"=======================================================\n")

    presets = generate_benchmark_scenarios()
    if scenario_key not in presets:
        print(f"Unknown scenario '{scenario_key}'. Available: {list(presets.keys())}")
        return

    scenario = presets[scenario_key]

    # Ingest / generate observation dataset
    print("[1/5] Ingesting & profiling empirical traffic observations...")
    df = generate_synthetic_traffic_dataset(scenario)
    planner = AnalysisPlanner()
    profile, prompt_spec, plan, tokens, mode = planner.create_plan_from_dataframe(
        df, dataset_name=f"{scenario_key}_observation"
    )

    print(f"      - Ingested {profile.total_records} records.")
    print(f"      - Total Demand: {profile.total_demand_vph:.1f} vph")
    print(f"      - Directional Imbalance: {profile.imbalance_ratio:.2f}:1 (Dominant: {profile.dominant_approach})")
    print(f"      - Classified Regime: {profile.detected_traffic_pattern.upper()}")
    print(f"      - Data Quality Score: {profile.quality_score_pct:.1f}%")

    print("\n[2/5] Programmatically compiling context-aware analytical prompt...")
    print(f"      - Prompt ID: {prompt_spec.prompt_id}")
    print(f"      - Objective: {prompt_spec.analytical_objective}")

    print("\n[3/5] Formulating mathematical optimization model...")
    print(f"      - Method: {plan.chosen_method}")
    print(f"      - Objective: {plan.objective_formulation}")

    print("\n[4/5] Executing self-correcting optimization & micro-simulation...")
    pipeline = SelfCorrectingPipeline(max_retries=3)
    trace = pipeline.execute_pipeline(
        scenario=scenario,
        data_profile=profile,
        dynamic_prompt=prompt_spec,
        analysis_plan=plan,
        tokens_used=tokens,
        llm_mode=mode
    )

    print(f"      - Validation Status: {trace.final_status}")
    print(f"      - Total Retries: {trace.total_retries}")
    print(f"      - Cycle Length: {trace.final_timings.cycle_length_seconds}s (NS: {trace.final_timings.phases.get('NS')}s, EW: {trace.final_timings.phases.get('EW')}s)")

    print("\n[5/5] Comparative Performance Evaluation vs Fixed Baseline:")
    fixed = trace.baseline_fixed_simulation
    prop = trace.final_simulation_proposed

    print(f"      --------------------------------------------------------------")
    print(f"      {'Metric':<25} | {'Fixed-Time':<12} | {'TrafficMind':<12} | {'Change':<10}")
    print(f"      --------------------------------------------------------------")
    print(f"      {'Avg Waiting Time':<25} | {fixed.avg_waiting_time_sec:>10.2f}s | {prop.avg_waiting_time_sec:>10.2f}s | {trace.waiting_time_improvement_pct:>+8.1f}%")
    print(f"      {'Avg Queue Length':<25} | {fixed.avg_queue_length:>10.2f}   | {prop.avg_queue_length:>10.2f}   | {trace.queue_length_improvement_pct:>+8.1f}%")
    print(f"      {'Total Delay':<25} | {fixed.total_delay_sec:>10.1f}s | {prop.total_delay_sec:>10.1f}s | {trace.delay_improvement_pct:>+8.1f}%")
    print(f"      {'Throughput':<25} | {fixed.throughput_vph:>10.1f}   | {prop.throughput_vph:>10.1f}   | {trace.throughput_gain_pct:>+8.1f}%")
    print(f"      --------------------------------------------------------------")

    # Generate Markdown Report
    os.makedirs("docs", exist_ok=True)
    report_text = ReportGenerator.generate_markdown_report(trace)
    report_path = f"docs/report_{scenario_key}.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report_text)
    print(f"\n[OK] Technical Markdown report exported to: {report_path}")


def run_full_benchmark():
    print(f"\n=======================================================")
    print(f"  TrafficMind AI - Executing Controlled Multi-Seed Benchmark")
    print(f"=======================================================\n")

    evaluator = TrafficBenchmarkEvaluator(seeds=[101, 202, 303])
    results = evaluator.run_benchmark()

    summary = results["overall_summary"]
    sc_summaries = results["scenario_summaries"]

    print(f"Total Experimental Runs: {results['total_runs']}\n")
    print(f"---------------------------------------------------------------------------------------------------------")
    print(f"{'Scenario':<15} | {'Fixed Wait':<12} | {'Adaptive Wait':<14} | {'TrafficMind':<12} | {'Wait Red %':<10} | {'Queue Red %':<10}")
    print(f"---------------------------------------------------------------------------------------------------------")
    for s in sc_summaries:
        print(f"{s['scenario_name']:<15} | {s['fixed_time_avg_waiting_sec']:>10.2f}s | {s['adaptive_unassisted_avg_waiting_sec']:>12.2f}s | {s['trafficmind_proposed_avg_waiting_sec']:>10.2f}s | {s['waiting_reduction_pct']:>9.1f}% | {s['queue_reduction_pct']:>9.1f}%")
    print(f"---------------------------------------------------------------------------------------------------------")

    print(f"\n=== OVERALL SUMMARY ===")
    print(f"- Fixed Baseline Mean Waiting Time:     {summary['fixed_time_mean_waiting_sec']:.2f} s")
    print(f"- TrafficMind AI Mean Waiting Time:     {summary['trafficmind_mean_waiting_sec']:.2f} s")
    print(f"- Overall Waiting Time Reduction:       {summary['overall_waiting_reduction_pct']:+.1f}%")
    print(f"- Prompt Compilation Success Rate:      {summary['prompt_success_rate_pct']:.1f}%")
    print(f"- Bounded Correction Success Rate:      {summary['correction_success_rate_pct']:.1f}%")
    print(f"- Safety Constraint Violation Rate:     {summary['constraint_violation_rate_pct']:.1f}%")
    print(f"- Paired t-statistic:                   {summary['paired_t_statistic']:.4f}")
    print(f"- Two-tailed p-value:                   {summary['p_value']:.4e} (Statistically Significant: {summary['statistically_significance_at_99pct'] if 'statistically_significance_at_99pct' in summary else summary.get('statistically_significant_at_99pct')})")

    # Export benchmark records
    os.makedirs("docs", exist_ok=True)
    df_detailed = pd.DataFrame(results["detailed_records"])
    csv_path = "docs/benchmark_results.csv"
    df_detailed.to_csv(csv_path, index=False)
    print(f"\n[OK] Detailed benchmark records saved to: {csv_path}")

    json_path = "docs/benchmark_summary.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"[OK] Summary JSON saved to: {json_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TrafficMind AI Runner")
    parser.add_argument("--mode", choices=["single", "benchmark"], default="benchmark")
    parser.add_argument("--scenario", choices=["normal", "rush_hour", "asymmetric", "incident"], default="asymmetric")
    args = parser.parse_args()

    if args.mode == "benchmark":
        run_full_benchmark()
    else:
        run_single_scenario(args.scenario)
