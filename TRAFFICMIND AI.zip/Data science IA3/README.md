# TrafficMind AI — Intelligent Adaptive Traffic Management System

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-1.0+-009688.svg)](https://fastapi.tiangolo.com/)
[![Tests](https://img.shields.io/badge/pytest-30%20passed-brightgreen.svg)](backend/tests/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

An industry-oriented AI & Data Science framework and **Interactive Experimentation Lab** for urban intersection management. Combines **Automated Data Profiling & EDA**, **Dynamic Prompt Compilation**, **Constrained Non-Linear Optimization (SciPy SLSQP & Webster)**, **Common Random Numbers (CRN) Micro-Simulation**, and a **Self-Correcting Verification Pipeline** with strict zero-degradation acceptance criteria.

> **Problem Statement:** SIH1607 — AI-Based Adaptive Traffic Management  
> **Core Question:** *Can dynamically generated LLM analytical plans, combined with a verified adaptive optimization algorithm, improve the reliability and effectiveness of traffic signal management compared with conventional fixed-time control and unassisted adaptive control?*

---

## 1. Industry Context & Key Innovation

In modern data science and enterprise AI workflows, **manually writing one-off Python scripts for every analysis is outdated**. Industry systems require:
1. **Automated Analytical Planning:** Systems that inspect incoming data distributions, detect anomalies, and programmatically formulate the exact optimization problem.
2. **Context-Aware Dynamic Prompts:** Rather than using static prompt templates, TrafficMind AI compiles task-specific directives directly from live traffic regimes, queue statistics, and safety bounds.
3. **Decoupled Deterministic Optimization:** Language models provide strategic reasoning, while deterministic mathematical algorithms (`SciPy SLSQP`, Webster flow ratios, and Queue-Proportional Greedy) calculate signal timings.
4. **Independent Verification & Bounded Self-Correction:** Timings are simulated and verified against safety bounds ($g_{\min}, g_{\max}, C$) and baseline performance. If a strategy fails, the system automatically diagnoses the failure, adjusts parameters, and re-optimizes within a bounded retry limit.
5. **Rigorous Scientific Fairness (Common Random Numbers):** Fixed-time, adaptive, and benchmark controllers evaluate against the exact same vehicle arrival events, eliminating random noise from comparative claims.
6. **Strict Zero-Degradation Acceptance:** Eliminates acceptance loopholes (such as the legacy +4.93% degradation acceptance flaw) to guarantee that only non-regressive, provably superior timings are deployed.

---

## 2. System Architecture

```mermaid
flowchart LR
    A["Raw Traffic Stream<br>(Arrivals, Queues, Timestamps)"] --> B["Automated Data Profiler & EDA<br>(Regime, Outliers, Correlations)"]
    B --> C["Dynamic Prompt Compiler<br>(Programmatic Directive)"]
    C --> D["LLM / Offline Analytical Planner<br>(Method & Objective Formulation)"]
    D --> E["Deterministic Traffic Optimizer<br>(SciPy SLSQP / Webster / Greedy)"]
    E --> F["Micro-Simulation Engine<br>(Common Random Numbers CRN)"]
    F --> G{"Independent Verification Engine<br>(Safety & Zero-Degradation Check)"}
    G -- "Fail (Retry < 3)" --> H["Diagnostic Feedback & Tuning"]
    H --> E
    G -- "Pass" --> I["Verified Strategy & Report"]
```

---

## 3. Experimental Benchmark Summary

Controlled multi-seed experiments across 12 runs on standard traffic scenarios:

| Scenario | Fixed-Time Baseline (A) | Adaptive Unassisted (B) | TrafficMind AI (Proposed) | Waiting Time Reduction | Queue Reduction | Safety Violations |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Normal Flow** | 13.70 s | 10.68 s | **10.68 s** | **-22.1%** | **-21.5%** | **0** |
| **Rush Hour Congested** | 51.46 s | 42.53 s | **47.08 s** | **-8.5%** | **-8.4%** | **0** |
| **Extreme Asymmetric** | 76.14 s | 46.09 s | **46.09 s** | **-39.5%** | **-39.1%** | **0** |
| **Sudden Incident** | 23.18 s | 23.83 s | **23.83 s** | -2.8% | -3.9% | **0** |
| **OVERALL MEAN** | **41.12 s** | **30.78 s** | **31.92 s** | **-22.4%** | **-21.9%** | **0.0% (Zero)** |

*In individual extreme asymmetric peak runs, TrafficMind AI achieved up to **+46.4% reduction in waiting time** and **+36.2% gain in vehicle throughput**.*

---

## 4. Project Structure

```
Data science IA3/
├── backend/
│   ├── main.py                 # FastAPI application endpoints
│   ├── schemas.py              # Pydantic data schemas (ApproachConfig, What-If, Fault Injection)
│   ├── data_generator.py       # Synthetic traffic data generator
│   ├── data_profiler.py        # Automated schema, anomaly & EDA descriptive statistics
│   ├── prompt_compiler.py      # Programmatic dynamic prompt compiler
│   ├── analysis_planner.py     # Analytical method planner orchestrator
│   ├── traffic_optimizer.py    # Fixed, Webster, SciPy SLSQP, and Queue-Proportional Greedy
│   ├── traffic_simulator.py    # Discrete-time micro-simulation with Common Random Numbers (CRN)
│   ├── validation_engine.py    # Independent deterministic safety & strict zero-degradation validator
│   ├── correction_loop.py      # Bounded self-correcting retry loop with CRN consistency
│   ├── evaluation.py           # Controlled multi-seed benchmarking suite
│   ├── llm_service.py          # API client + offline deterministic intelligence
│   ├── report_generator.py     # Evidence-based Markdown report generator
│   └── tests/                  # 26 Automated pytest unit and integration tests
├── data/
│   └── sample_scenarios/       # Pre-generated traffic CSV datasets
├── docs/
│   ├── ARCHITECTURE.md         # Detailed system design & flowcharts
│   ├── ALGORITHM_FORMULATION.md# Complete mathematical formulations & proofs
│   └── BENCHMARK_REPORT.md     # Full empirical benchmarking analysis
├── frontend/
│   └── index.html              # Interactive 6-Tab Experimentation Lab Dashboard UI
├── run_pipeline.py             # CLI runner for single runs and benchmarks
├── generate_data_files.py      # Dataset generation script
└── README.md                   # Master documentation
```

---

## 5. Quickstart & Execution Guide

### Prerequisites
- Python 3.10+
- Installed libraries: `fastapi`, `uvicorn`, `pydantic`, `pytest`, `numpy`, `pandas`, `scipy`, `scikit-learn`, `python-multipart`

### Step 1: Run Automated Tests
Execute the full test suite (26 unit and integration tests):
```bash
python -m pytest backend/tests -v
```

### Step 2: Run the Benchmark via CLI
Execute controlled multi-scenario experiments directly in terminal:
```bash
python run_pipeline.py --mode benchmark
```

To run a single scenario (e.g. `asymmetric`, `rush_hour`, `normal`, or `incident`):
```bash
python run_pipeline.py --mode single --scenario asymmetric
```
*This outputs comparative metrics and generates a technical report in `docs/report_asymmetric.md`.*

### Step 3: Launch FastAPI Backend & Interactive Dashboard
Start the REST API server:
```bash
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```
- Open `http://localhost:8000` in any web browser to access the **Interactive TrafficMind AI Experimentation Lab**.
- Interactive API Documentation: `http://localhost:8000/docs`

---

## 6. Interactive Experimentation Lab Tabs

1. **Scenario Builder:** Configure independent approach arrival rates (North: 75 vpm, South: 45 vpm, East: 30 vpm, West: 35 vpm), initial queues, duration, and random seeds. Run full pipeline and view interactive SVG queue evolution.
2. **Exploratory Data Analysis (EDA) Lab:** Real descriptive statistics (mean, median, std, max, outliers) per approach, Pearson correlation matrix, and arrival rate distribution charts.
3. **Algorithm Benchmarking:** Side-by-side comparison of 4 algorithms on identical arrivals (Fixed-Time, Webster Flow-Ratio, Constrained SciPy SLSQP with customizable weights, and Queue-Proportional Greedy).
4. **Dynamic Prompt Playground:** Live objective selector demonstrating how prompt directives change automatically based on traffic regimes and objectives (transparently distinguishing deterministic mock mode from live LLM execution).
5. **What-If Simulation Studio:** Test non-recurrent events like accident lane-blocks, capacity drops, and asymmetric surges, tracking before-and-after queue clearance, waiting times, and honest regression flags.
6. **Self-Correction Debugger:** Test system robustness with controlled fault injection (invalid green bounds, cycle mismatch, corrupted metric claims). Inspect automatic rejection and diagnostic feedback traces.
7. **Interactive 2D Simulation Studio:** Synchronized top-down animated intersection comparing Fixed-Time vs Adaptive controllers side-by-side on identical Common Random Numbers (CRN) arrivals, complete with play/pause, scrub, 1x/2x/5x speed, queue visuals, and live data science overlays.

---

## 7. Key API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/health` | Health check and LLM mode status |
| `GET` | `/scenarios/presets` | Preset traffic scenario configurations |
| `POST` | `/data/generate` | Generate synthetic traffic datasets with custom arrival rates |
| `POST` | `/data/profile` | Ingest and profile traffic CSV data |
| `POST` | `/eda/analyze` | Perform rigorous EDA with statistics, distributions, and correlations |
| `POST` | `/experiments/compare_algorithms` | Benchmark 4 control algorithms using Common Random Numbers (CRN) |
| `POST` | `/prompt/playground` | Programmatic dynamic prompt compiler with objective selection |
| `POST` | `/simulation/what_if` | Simulate disruptions, accidents, lane drops, and surges with regression detection |
| `POST` | `/simulation/playback_data` | Stream second-by-second synchronized 2D playback states for dual simulation |
| `POST` | `/correction/fault_injection` | Inject intentional faults to test validation and rejection |
| `POST` | `/pipeline/run` | End-to-end adaptive self-correcting pipeline |
| `POST` | `/evaluation/compare` | Controlled multi-seed benchmark evaluation |
| `GET` | `/analysis/{run_id}` | Retrieve execution trace and audit trail |
| `GET` | `/reports/{run_id}` | Retrieve generated technical Markdown report |

---

## 7. Limitations & Scope
- **Intersection Topology:** Focuses on a canonical 4-way intersection (dual-ring 2-phase configuration).
- **Simulation Scope:** Discrete-time micro-simulation models vehicle queues and saturation flow discharge; real-world deployment would interface with physical inductive loops or computer vision sensors.
- **Safety First:** The LLM never directly actuates traffic signals. All timings are computed and strictly verified by deterministic algorithms.
