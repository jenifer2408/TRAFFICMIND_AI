"""
Generates sample traffic dataset CSV files in data/sample_scenarios/
"""

import os
from backend.data_generator import generate_benchmark_scenarios, generate_synthetic_traffic_dataset
from backend.schemas import TrafficScenarioConfig

os.makedirs("data/sample_scenarios", exist_ok=True)

presets = generate_benchmark_scenarios()

for name, cfg in presets.items():
    output_path = f"data/sample_scenarios/{name}_traffic.csv"
    df = generate_synthetic_traffic_dataset(cfg, output_filepath=output_path, inject_anomalies=False)
    print(f"Generated {output_path} with {len(df)} rows.")

# Also generate one with injected sensor anomalies and missing values
noisy_cfg = presets["rush_hour"]
noisy_path = "data/sample_scenarios/noisy_traffic_with_anomalies.csv"
df_noisy = generate_synthetic_traffic_dataset(noisy_cfg, output_filepath=noisy_path, inject_anomalies=True)
print(f"Generated {noisy_path} with {len(df_noisy)} rows (includes sensor dropouts & spikes).")

print("All sample datasets successfully generated!")
